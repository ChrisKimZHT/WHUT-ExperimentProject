/**
 * ============================================================================
 *
 * Copyright (C) 2018-2020, Hisilicon Technologies Co., Ltd. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   1 Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *
 *   2 Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *
 *   3 Neither the names of the copyright holders nor the names of the
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 * ============================================================================
 */

#ifndef FACE_POST_PROCESS_H_
#define FACE_POST_PROCESS_H_

#include "face_recognition_params.h"

#include <vector>
#include <stdint.h>

#include "acllite/AclLiteThread.h"
#include "acllite/AclLiteApp.h"
#include "acllite/AclLiteImageProc.h"

#include "facial_recognition_message.pb.h"
#include "presenter/agent/presenter_channel.h"
#include "presenter_channels.h"


class FacePostProcess : public AclLiteThread {
public:
    /**
     * @brief: constructor
     * @param [in]: configFile: App config file
     */
    FacePostProcess(const std::string& configFile);

    /**
     * @brief: destruction function
     */    
    ~FacePostProcess();

    /**
     * @brief: Post process thread init function
     * @param [in]: None
     * @return: Init result
     *          ACLLITE_OK: Init success
     *          ACLLITE_ERROR: Init failed. The thread will exit 
     */
    AclLiteError Init();

    /**
     * @brief: The message process entry of face detection thread received 
     * @param [in]: msgId: The received message id  
     * @param [in]: msgData: The received message data
     * @return: Message process result
     *          ACLLITE_OK: process success
     *          ACLLITE_ERROR: process failed, the thread will exit 
     */ 
    AclLiteError Process(int msgId, std::shared_ptr<void> msgData);

private:
    /**
     * @brief: Send face feature in camera frame to presenter server
     * @param [in]: recogInfo:face feature information and origin image
     * @return: ACLLITE_OK: send success
     *          ACLLITE_ERROR: send failed 
     */
    AclLiteError SendFeature(std::shared_ptr<FaceRecognitionInfo> recogInfo);

    /**
     * @brief: Send face feature in face register image to presenter server
     * @param [in]: recogInfo:face feature information and origin image
     * @return: ACLLITE_OK: send success
     *          ACLLITE_ERROR: send failed 
     */
    AclLiteError ReplyFeature(std::shared_ptr<FaceRecognitionInfo> recogInfo);
      
    /**
     * @brief: Process MSG_FACE_RECOGNIZE_DATA message
     * @param [in]: recogInfo: message data 
     * @return: Message process result
     *          ACLLITE_OK: process success
     *          ACLLITE_ERROR: process failed, the thread will exit 
     */     
    AclLiteError FaceRecognitionMsgProcess(
                    std::shared_ptr<FaceRecognitionInfo> recogInfo);

    /**
     * @brief: Fill face feature data to the message that send to 
     *         presenter server
     * @param [out]: message instance that send to presenter server
     * @param [in]: faceImg: message data 
     */ 
    void PrepareFaceBoxData(
        ascend::presenter::facial_recognition::FaceFeature* feature, 
        FaceImage& faceImg);

    /**
     * @brief: Send message to presenter server                                                                                                            
     * @param [in]: recogInfo: message data 
     * @return: Message process result
     *          ACLLITE_OK: process success
     *          ACLLITE_ERROR: process failed, the thread will exit 
     */ 
    AclLiteError SendMessage(google::protobuf::Message& message);

private:
    std::string configFile_;
    AclLiteImageProc dvpp_;
 };
        

#endif
