/**
 * ============================================================================
 *
 * Copyright (C) 2018-2020, Hisilicon Technologies Co., Ltd. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   1 Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *
 *   2 Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *
 *   3 Neither the names of the copyright holders nor the names of the
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 * ============================================================================
 */

#ifndef FACILA_THREAD_BASE_H
#define FACILA_THREAD_BASE_H

#include <iostream>
#include <string>
#include <vector>
#include <stdint.h>
#include <stdio.h>

#include "acllite/AclLiteThread.h"
#include "acllite/AclLiteApp.h"
#include "acllite/AclLiteUtils.h"
#include "face_recognition_params.h"


class FacialThreadBase : public AclLiteThread {
public:
    /**
     * @brief: constructor
     * @param [in]: configFile: App config file
     */
    FacialThreadBase(const std::string& configFile) : 
    configFile_(configFile), 
    modelWidth_(0),
    modelHeight_(0),
    modelPath_(""),
    nextThreadId_(INVALID_INSTANCE_ID) { 
        GetBaseConfig();
    };

    /**
     * @brief: destruction function
    */
    ~FacialThreadBase() {};

    /**
     * @brief: Thread init function, override AclLiteThread init method
     * @param [in]: None
     * @return: Init result
     *          ACLLITE_OK: Init success
     *          ACLLITE_ERROR: Init failed
    */
    virtual AclLiteError Init() { return ACLLITE_OK; }
    
    /**
     * @brief: The message process entry of thread received 
     * @param [in]: msgId: The received message id  
     * @param [in]: msgData: The received message data
     * @return: Message process result
     *          ACLLITE_OK: process success
     *          ACLLITE_ERROR: process failed, the thread will exit 
     */
    virtual AclLiteError Process(int msgId, std::shared_ptr<void> msgData) { 
        return ACLLITE_OK; 
    }

    /**
     * @brief: Send message to next thread 
     * @param [in]: msgId: message id  
     * @param [in]: data: message data
     * @return: Message process result
     *          ACLLITE_OK: process success
     *          ACLLITE_ERROR: process failed, the thread will exit 
     */
    AclLiteError SendMessageToNext(int msgId, std::shared_ptr<void> data) {
        return SendMessage(NextThreadId(), msgId, data);
    }

    /**
     * @brief: Get model width of current thread configuration.The config
     *         is in app config file with format <threadname>.model_width 
     * @return: 0:No model width config or read config failed
     *          > 0: model width            
     */    
    uint32_t ModelWidth() { return modelWidth_; }
    
    /**
     * @brief: Get model height of current thread configuration.The config
     *         is in app config file with format <threadname>.model_height
     * @return: 0:No model height config or read config failed
     *          > 0: model height            
     */ 
    uint32_t ModelHeight() { return modelHeight_; }

    /**
     * @brief: Get model path of current thread configuration.The config
     *         is in app config file with format <threadname>.model_path
     * @return: "":No model path config or read config failed
     *          other: model path            
     */ 
    const std::string& ModelPath() { return modelPath_; }

    /**
     * @brief: Get next thread id of current thread.The next thread
     *         is in app config file with format <threadname>.next_thread            
     * @return: -1:No next thread config or read config failed
     *          >= 1: next thread id            
     */
    int NextThreadId() { 
        if ((nextThreadId_ == INVALID_INSTANCE_ID) && 
            (nextThreadName_.size() > 0)) {
            nextThreadId_ = GetAclLiteThreadIdByName(nextThreadName_);
            ACLLITE_LOG_INFO("%s: next thread name %s, id %d", 
                           SelfInstanceName().c_str(),
                           nextThreadName_.c_str(), nextThreadId_);
        }

        return nextThreadId_; 
    }

    /**
     * @brief: Get thread config, include model_width, model_height, 
     *         model_path, next_thread             
     * @return: ACLLITE_OK:No config or get config success
     *          ACLLITE_ERROR: read config file failed            
     */
    AclLiteError GetBaseConfig() {
        const std::string& selfName = SelfInstanceName();

        std::string modelWidthKey = selfName + ".model_width";
        std::string modelHeightKey = selfName + ".model_height";
        std::string modelPahtKey = selfName + ".model_path";
        std::string nextThreadKey = selfName + ".next_thread";

        std::map<std::string, std::string> config;
        if(!ReadConfig(config, configFile_.c_str())) {
            ACLLITE_LOG_ERROR("Read config %s failed", configFile_.c_str());
            return ACLLITE_ERROR;
        }
        
        std::map<std::string, std::string>::const_iterator mIter = config.begin();
        for (; mIter != config.end(); ++mIter) {
            if (mIter->first == modelWidthKey) {
                modelWidth_ = atoi(mIter->second.c_str());
                ACLLITE_LOG_INFO("%s: model width %d", 
                               SelfInstanceName().c_str(), modelWidth_);
            } else if (mIter->first == modelHeightKey) {
                modelHeight_ = atoi(mIter->second.c_str());
                ACLLITE_LOG_INFO("%s: model height %d", 
                               SelfInstanceName().c_str(), modelHeight_);
            } else if (mIter->first == modelPahtKey) {
                modelPath_.assign(mIter->second.c_str());
                ACLLITE_LOG_INFO("%s: model path: %s", 
                               SelfInstanceName().c_str(), modelPath_.c_str());
            } else if (mIter->first == nextThreadKey) {
                nextThreadName_.assign(mIter->second.c_str());
                ACLLITE_LOG_INFO("%s: next thread name %s", 
                               SelfInstanceName().c_str(), mIter->second.c_str());
            }
        }

        return ACLLITE_OK;
    }

private:    
    const std::string& configFile_;
    std::string nextThreadName_;
    uint32_t modelWidth_;
    uint32_t modelHeight_;
    std::string modelPath_;
    int nextThreadId_;
};

#endif /* MindCamera_H */
