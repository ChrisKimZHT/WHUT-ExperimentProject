/**
 * ============================================================================
 *
 * Copyright (C) 2018-2020, Hisilicon Technologies Co., Ltd. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   1 Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *
 *   2 Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *
 *   3 Neither the names of the copyright holders nor the names of the
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 * ============================================================================
 */

#ifndef MIND_CAMERA_H
#define MIND_CAMERA_H

#include <string>
#include <memory>

#include "acllite/AclLiteVideoProc.h"
#include "face_recognition_params.h"

#include "facial_thread_base.h"

/**
 * @brief: Camera class
 */
class MindCamera : public FacialThreadBase {
public:
    /**
     * @brief: constructor
     * @param [in]: configFile: App config file
     */
    MindCamera(const std::string& configFile);

    /**
     * @brief: destruction function
     */
    ~MindCamera();

    /**
     * @brief: Mind camera thread init function
     * @param [in]: None
     * @return: Init result
     *          ACLLITE_OK: Init success
     *          ACLLITE_ERROR: Init failed, he thread will exit 
     */
    AclLiteError Init();

    /**
     * @brief: The message process entry of mind camera thread received 
     * @param [in]: msgId: The received message id  
     * @param [in]: msgData: The received message data
     * @return: Message process result
     *          ACLLITE_OK: process success
     *          ACLLITE_ERROR: process failed, he thread will exit 
     */   
    AclLiteError Process(int msgId, std::shared_ptr<void> msgData);

private:
     /**
     * @brief: Process MSG_READ_FRAME message
     * @param [in]: None 
     * @return: Message process result
     *          ACLLITE_OK: process success
     *          ACLLITE_ERROR: process failed, he thread will exit 
     */ 
    AclLiteError ReadFrameMsgProcess();

private:
    //Mind camera self thread id
    int selfThreadId_;
    //Camera/video decode instance pointer
    AclLiteVideoProc* cap_;
};

#endif /* MindCamera_H */
