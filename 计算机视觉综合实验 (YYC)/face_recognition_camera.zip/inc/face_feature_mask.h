/**
 * ============================================================================
 *
 * Copyright (C) 2018-2020, Hisilicon Technologies Co., Ltd. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   1 Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *
 *   2 Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *
 *   3 Neither the names of the copyright holders nor the names of the
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 * ============================================================================
 */
#ifndef FACE_FEATURE_MASK_ENGINE_H_
#define FACE_FEATURE_MASK_ENGINE_H_

#include "face_recognition_params.h"
#include <iostream>
#include <string>
#include <dirent.h>
#include <memory>
#include <unistd.h>
#include <vector>
#include <stdint.h>

#include "opencv2/opencv.hpp"
#include "opencv2/imgproc.hpp"
#include "opencv2/core/types_c.h"

#include "acllite/AclLiteModel.h"
#include "acllite/AclLiteImageProc.h"

#include "facial_thread_base.h"

//Define the face feature position
enum FaceFeaturePos {
    kLeftEyeX,
    kLeftEyeY,
    kRightEyeX,
    kRightEyeY,
    kNoseX,
    kNoseY,
    kLeftMouthX,
    kLeftMouthY,
    kRightMouthX,
    kRightMouthY
};

/**
 * @brief: Face feature extract class
 */
class FaceFeatureMask : public FacialThreadBase {
public:
    /**
     * @brief: constructor
     * @param [in]: configFile: App config file
     */
    FaceFeatureMask(const std::string& configFile);

    /**
     * @brief: destruction function
     */    
    ~FaceFeatureMask();

    /**
     * @brief: Face feature mask thread init function
     * @param [in]: None
     * @return: Init result
     *          ACLLITE_OK: Init success
     *          ACLLITE_ERROR: Init failed. The thread will exit 
     */
    AclLiteError Init();

    /**
     * @brief: The message process entry of face feature mask thread received 
     * @param [in]: msgId: The received message id  
     * @param [in]: msgData: The received message data
     * @return: Message process result
     *          ACLLITE_OK: process success
     *          ACLLITE_ERROR: process failed, the thread will exit 
     */ 
    AclLiteError Process(int msgId, std::shared_ptr<void> msgData);

private:
    /**
     * @brief: Init the normlized mean and std value
     * @param [in]: None
     * @return: Whether init success
     */
    AclLiteError InitNormlizedData();

    /**
     * @brief: Crop all faces area from original image 
     * @param [out]: faceImgs: all faces area image data
     * @param [in]: orgImg: the original image data
     * @return: ACLLITE_OK: crop success
     *          ACLLITE_ERROR: crop failed 
     */
    AclLiteError Crop(std::vector<FaceImage> &faceImgs, ImageData &orgImg);

    /**
     * @brief: Resize all cropped image 
     * @param [out]: resizedImgs: all face image after resize
     * @param [in]: faceImgs: all cropped face image
     * @return: ACLLITE_OK: resize success
     *          ACLLITE_ERROR: resize failed 
    */
    AclLiteError Resize(std::vector<ImageData> &resizedImgs,
                      std::vector<FaceImage> &faceImgs);

    /**
     * @brief: Transform the image from resized YUV images by dvpp 
     *         to opencv BGR mat
     * @param [out]: bgrImgs BGR images after transform
     * @param [in]: resizedImgs resized YUV images by dvpp  
     * @return: ACLLITE_OK: transform success
     *          ACLLITE_ERROR: transform failed
    */
    AclLiteError Decode(std::vector<cv::Mat> &bgrImgs, 
                      std::vector<ImageData> &resizedImgs);

    /**
     * @brief: Transform the image from (0,255) to little number,
     *         invoke the opencv's interface to do the normalization,
     *         sub mean and divide std.
     * @param [in/out]: bgrImage The BGR image data
     * @return: ACLLITE_OK: normalize success
     *          ACLLITE_ERROR: normalize failed
    */
    AclLiteError Normalize(std::vector<cv::Mat> &bgrImage);

    /**
     * @brief: Copy one batch preprocessed images to 
     *         device buffer for inference later.
     * @param [out]: buffer: device buffer for store preprocess images
     * @param [in]: bufferSize: device buffer size
     * @param [in]: images: preprocessed images data
     * @param [in]: batchIdx: current batch index 
     * @return: > 0: image number of copped
     *          -1: copy failed
    */
    int CopyOneBatchImages(uint8_t* buffer, uint32_t bufferSize, 
                           std::vector<cv::Mat>& images, int batchIdx);

    /**
     * @brief: Copy one image to device buffer with NCWH.
     * @param [out]: buffer: device buffer for store preprocess images
     * @param [in]: bufferSize: device buffer size
     * @param [in]: image: the preprocessed image to copy
     * @return: > 0: data size of copped
     *          -1: copy failed
    */                                             
    int CopyImageMatData(uint8_t* buffer, uint32_t bufferSize, cv::Mat& image);

    /**
     * @brief: Resize rgb opencv mat image data
     * @param [out]: dest: the image data after resize
     * @param [in]: src: origin imaga data
     * @param [in]: width: resize width
     * @param [in]: height: resize height
     * @return: None
    */                                            
    void BgrResize(cv::Mat& dest, cv::Mat& src, 
                   uint32_t width, uint32_t height);

    /**
     * @brief: Inference the preprocessed face images data
     * @param [in]: normalizedImgs: the preprocessed image data
     * @param [in]: faceImgs: the face images data cropped 
     *              from origin image
     * @return: ACLLITE_OK: normalize success
     *          ACLLITE_ERROR: normalize failed
    */
    AclLiteError Inference(std::vector<cv::Mat> &normalizedImgs,
                         std::vector<FaceImage> &faceImgs);

    /**
     * @brief: Parse face feature point coordinate from model 
     *         inference output data
     * @param [out]: faceFeature: face feature point coordinate
     * @param [in]: facePosition: model inference output data
     * @return: None
    */
    void ParseFacePosition(FaceFeature *faceFeature, int *facePosition);
                            
    /**
     * @brief: Preprocess image for face feature inference, include crop
     *         faces in image, resize the cropped image, transform to bgr,
     *         normalinze, and copy to acl device
     * @param [out]: processedImgs: preprocessed face images data
     * @param [in]: recogInfo: message data from last(face detection) thread
     * @return: None
    */
    AclLiteError PreProcess(std::vector<cv::Mat>& processedImgs,
                          std::shared_ptr<FaceRecognitionInfo> &recogInfo);
    

    /**
    * @brief: Process model inference output of one batch face images
    * @param [in]: inferenceOutput: model inference output
    * @param [in]: startIdx: begin index in the faceImgs
    * @param [in]: faceCnt: inference image number
    * @param [in]: faceImgs: face images
    */
    AclLiteError PostProcess(std::vector<InferenceOutput>& inferenceOutput,
                           int startIdx, int faceCnt,
                           std::vector<FaceImage>& faceImgs); 

    /**
     * @brief: Process MSG_FACE_DETECT_DATA message
     * @param [in]: recogInfo: message data 
     * @return: Message process result
     *          ACLLITE_OK: process success
     *          ACLLITE_ERROR: process failed, the thread will exit 
     */ 
    AclLiteError FaceDetectMsgProcess(
        shared_ptr<FaceRecognitionInfo> recogInfo);
   

private:
    AclLiteModel model_;
    AclLiteImageProc dvpp_;
    int32_t batchSize_;
    // Mean value after trained
    cv::Mat trainMean_;
    // Std value after trained
    cv::Mat trainStd_;
    uint32_t inputSize_;
    uint8_t* inputBuf_;
    int *facePositionBuf_;    
};

#endif
