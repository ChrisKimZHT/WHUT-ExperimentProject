/**
 * ============================================================================
 *
 * Copyright (C) 2018-2020, Hisilicon Technologies Co., Ltd. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   1 Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *
 *   2 Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *
 *   3 Neither the names of the copyright holders nor the names of the
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 * ============================================================================
 */

#ifndef FACE_REGISTER_ENGINE_H_
#define FACE_REGISTER_ENGINE_H_
#include <iostream>
#include <string>
#include <dirent.h>
#include <memory>
#include <unistd.h>
#include <vector>
#include <stdint.h>

#include "acllite/AclLiteImageProc.h"
#include "face_recognition_params.h"
#include "facial_thread_base.h"
#include "presenter_channels.h"


class FaceRegister : public FacialThreadBase {
public:
    /**
     * @brief: constructor
     * @param [in] configFile: App config file
    */
    FaceRegister(const std::string& configFile);

    /**
     * @brief: destruction function
    */
    ~FaceRegister();

    /**
     * @brief: Face register thread init function
     * @param [in]: None
     * @return: Init result
     *          ACLLITE_OK: Init success
     *          ACLLITE_ERROR: Init failed. The thread will exit 
    */
    AclLiteError Init();

    /**
     * @brief: The message process entry of face register thread received 
     * @param [in]: msgId: The received message id  
     * @param [in]: msgData: The received message data
     * @return: Message process result
     *          ACLLITE_OK: process success
     *          ACLLITE_ERROR: process failed, the thread will exit 
     */
    AclLiteError Process(int msgId, std::shared_ptr<void> msgData);

private:
    /**
     * @brief: Receive face register request from presenter server
     * @param [in]: agentChannel: the connection between persenter 
     *                            server and app  
     * @return: face register request data
    */
    ascend::presenter::facial_recognition::FaceInfo* ReceiveFaceRegisterRequest(
        ascend::presenter::Channel* agentChannel, unique_ptr<google::protobuf::Message> &regMsg);

    /**
     * @brief: Copy the face register image to acl device, 
     *         and convert to YUV420SP
     * @param [out]: recogInfo: data with yuv image
     * @param [in]: faceRegReq: face register request
     * @return: ACLLITE_OK: process success
     *          ACLLITE_ERROR: process failed 
    */
    AclLiteError ProcessFaceImage(std::shared_ptr<FaceRecognitionInfo> recogInfo, 
        ascend::presenter::facial_recognition::FaceInfo* faceRegReq);

    /**
     * @brief: Notify face register failed.Send message to post process thread
     *         first, then post process will send message to presenter server
     * @param [in]: recogInfo: notify info
     * @param [in]: errMsg: the reason of failed
     * @return: ACLLITE_OK: process success
     *          ACLLITE_ERROR: process failed 
    */        
    AclLiteError SendErrorReply(std::shared_ptr<FaceRecognitionInfo> recogInfo,
                              const std::string& errMsg);

    /**
     * @brief: Daemon face register request from presenter server and process it
     * @return: ACLLITE_OK: process success
     *          ACLLITE_ERROR: process failed 
    */ 
    AclLiteError FaceRegisterDaemon();

    /**
     * @brief: Create message connection between presenter server and app
     * @return: ACLLITE_OK: create success
     *          ACLLITE_ERROR: create failed 
    */     
    AclLiteError OpenPresenterChannel();

private:
    AclLiteImageProc dvpp_;
    std::string configFile_;
};

#endif
