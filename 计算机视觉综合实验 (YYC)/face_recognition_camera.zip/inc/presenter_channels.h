/**
 * ============================================================================
 *
 * Copyright (C) 2018-2020, Hisilicon Technologies Co., Ltd. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   1 Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *
 *   2 Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *
 *   3 Neither the names of the copyright holders nor the names of the
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 * ============================================================================
 */

#ifndef PRESENTER_CHANNELS_H
#define PRESENTER_CHANNELS_H

#include "facial_recognition_message.pb.h"

#include <mutex>
#include <string>
#include <cstdint>
#include <fstream>
#include <iostream>

#include "presenter/agent/presenter_types.h"
#include "presenter/agent/channel.h"
#include "presenter/agent/presenter_channel.h"

#define COMMENT_CHAR '#'
#define EQUALS_CHAR  '='
#define BLANK_SPACE_CHAR ' '
#define TABLE_CHAR '\t'

struct PresenterServerParams {
    // ip of presenter server
    std::string hostIp;
    // port of presenter server
    std::uint16_t port;
    // name of registered app
    std::string appId;
    // type of registered app
    std::string appType;
};

class PresenterChannels {
public:
    /**
     * @brief: Get global unique PresenterChannels instance
     * @return: PresenterChannels instance
     */
    static PresenterChannels& GetInstance() {
        static PresenterChannels instance;
        return instance;
    }
    
    /**
     * @brief: Init presenter server connection parameters 
     * @param [in]: connection parameters   
     * @return: None
     */
    void Init(const PresenterServerParams& param) {
        param_ = param;
    }

    /**
     * @brief: Get face register channel handle, if the channel is 
     *         not exist, create it 
     * @return: face register channel between app and presenter server
     */
    ascend::presenter::Channel* GetChannel() {
        if (intfChannel_ != nullptr) {
            return intfChannel_.get();
        }

        // create agent channel by hostIp and port
        ascend::presenter::ChannelFactory channelFactory;
        ascend::presenter::Channel *agentChannel = channelFactory.NewChannel(
            param_.hostIp, param_.port);

        //open present channel
        ascend::presenter::PresenterErrorCode presentOpenErr =
            agentChannel->Open();
        if (presentOpenErr != ascend::presenter::PresenterErrorCode::kNone) {
            return nullptr;
        }

        // register app to presenter server
        ascend::presenter::facial_recognition::RegisterApp appRegister;
        appRegister.set_id(param_.appId);
        appRegister.set_type(param_.appType);

        // construct responded protobuf Message
        std::unique_ptr < google::protobuf::Message > response;

        // send registered request to server
        ascend::presenter::PresenterErrorCode presentRegisterErr = agentChannel
            ->SendMessage(appRegister, response);
        if (presentRegisterErr != ascend::presenter::PresenterErrorCode::kNone) {
            return nullptr;
        }

        // get responded Message and judge result
        ascend::presenter::facial_recognition::CommonResponse* registerResponse =
            dynamic_cast<ascend::presenter::facial_recognition::CommonResponse*>(response
                .get());
        if (registerResponse == nullptr) {
            return nullptr;
        }
        ascend::presenter::facial_recognition::ErrorCode registerErr =
            registerResponse->ret();
        if (registerErr != ascend::presenter::facial_recognition::kErrorNone) {
            return nullptr;
        }

        intfChannel_.reset(agentChannel);

        return intfChannel_.get();
    }

    /**
     * @brief: Get connection channel between presenter server and post process
     *         thread, ifnot exist, create it 
     * @return: presenter server channel
     */
    ascend::presenter::Channel* GetPresenterChannel() {
        // channel already exist, return it
        if (presenterChannel_ != nullptr) {
        return presenterChannel_.get();
        }

        // channel not exist, open it
        ascend::presenter::Channel *ch = nullptr;
        ascend::presenter::OpenChannelParam param;
        param.host_ip = param_.hostIp;
        param.port = param_.port;
        param.channel_name = param_.appId;
        param.content_type = ascend::presenter::ContentType::kVideo;

        ascend::presenter::PresenterErrorCode error_code =
        ascend::presenter::OpenChannel(ch, param);

        // open channel failed
        if (error_code != ascend::presenter::PresenterErrorCode::kNone) {
        //ERROR_LOG("Open channel failed! %d",
        //               error_code);
        return nullptr;
        }

        // open channel successfully, set it to private parameter
        presenterChannel_.reset(ch);
        return presenterChannel_.get();
    }

private:

  // intf channel for face register
  std::unique_ptr<ascend::presenter::Channel> intfChannel_;

  // presenter channel for camera data
  std::unique_ptr<ascend::presenter::Channel> presenterChannel_;

  // channel params
  PresenterServerParams param_;
};

#endif
