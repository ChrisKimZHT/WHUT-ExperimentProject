/**
 * ============================================================================
 *
 * Copyright (C) 2018-2020, Hisilicon Technologies Co., Ltd. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   1 Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *
 *   2 Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *
 *   3 Neither the names of the copyright holders nor the names of the
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 * ============================================================================
 */

#ifndef FACE_RECOGNITION_PARAMS_H_
#define FACE_RECOGNITION_PARAMS_H_

#include <iostream>
#include <mutex>
#include <unistd.h>

#include "face_feature_train_mean.h"
#include "face_feature_train_std.h"
#include "acllite/AclLiteUtils.h"
#include "opencv2/opencv.hpp"

#include "opencv2/opencv.hpp"
#include "opencv2/imgproc.hpp"
#include "opencv2/core/types_c.h"
#include "opencv2/imgproc/types_c.h"
#include<opencv2/core/core.hpp>


using namespace std;
#define CHECK_MEM_OPERATOR_RESULTS(ret) \
if (ret != SUCCESS) { \
    ACLLITE_LOG_ERROR("memory operation failed, error=%d", ret); \
    return ACLLITE_ERROR; \
}

#define MSG_READ_FRAME            1
#define MSG_FRAME_DATA            2
#define MSG_FACE_DETECT_DATA      3
#define MSG_FACE_FEATURE_MASK     4
#define MSG_FACE_RECOGNIZE_DATA   5
#define MSG_FACE_REGISTER_DAEMON  6
#define MSG_FACE_REG_IMAGE        7
#define MSG_FACE_REG_INVALID      8

const string kCameraThreadName = "mind_camera";
const string kDetectThreadName = "face_detect";
const string kFeatureMaskThreadName = "face_feature_mask";
const string kRecognitionThreadName = "face_recognition";
const string kPostProcessThreadName = "face_post_process";
const string kRegisterThreadName = "face_register";

/**
 * @brief: frame information
 */
struct FrameInfo {
    uint32_t imageSource = 0;  // 0:Camera 1:Register
    std::string faceId = "";  // registered face id
    ImageData image; 
};

/**
 * @brief: face recognition APP error code definition
 */
enum class AppErrorCode {
    // Success, no error
    kNone = 0,

    // register engine failed
    kRegister,

    // detection engine failed
    kDetection,

    // feature mask engine failed
    kFeatureMask,

    // recognition engine failed 
    kRecognition
};

struct ErrorInfo {
    AppErrorCode errCode = AppErrorCode::kNone;
    std::string errMsg = "";
};

/**
 * @brief: face rectangle
 */
struct FaceRectangle {
    cv::Point lt;  // left top
    cv::Point rb;  // right bottom
};


/**
 * @brief: face feature
 */
struct FaceFeature {
    cv::Point leftEye;  // left eye
    cv::Point rightEye;  // right eye
    cv::Point nose;  // nose
    cv::Point leftMouth;  // left mouth
    cv::Point rightMouth;  // right mouth
};

/**
 * @brief: face image
 */
struct FaceImage {
    ImageData image;  // cropped image from original image
    FaceRectangle rectangle;  // face rectangle
    FaceFeature featureMask;  // face feature mask
    std::vector<float> featureVector;  // face feature vector
};

/**
 * @brief: information for face recognition
 */
struct FaceRecognitionInfo {
    ErrorInfo errInfo;
    FrameInfo frame;  // frame information
    ImageData orgImg;  // original image
    std::vector<FaceImage> faceImgs;  // cropped image
};

#endif /* FACE_RECOGNITION_PARAMS_H_ */
