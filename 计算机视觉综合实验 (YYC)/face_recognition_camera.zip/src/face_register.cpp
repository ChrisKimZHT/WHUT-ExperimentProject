/**
 * ============================================================================
 *
 * Copyright (C) 2018-2020, Hisilicon Technologies Co., Ltd. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   1 Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *
 *   2 Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *
 *   3 Neither the names of the copyright holders nor the names of the
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 * ============================================================================
 */

#include "face_register.h"
#include <memory>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <string.h>
#include <cmath>
#include <regex>

#include<iostream>
#include "opencv2/opencv.hpp"
#include "opencv2/imgproc.hpp"
#include "opencv2/core/types_c.h"
#include "opencv2/imgproc/types_c.h"
#include<opencv2/core/core.hpp>

#include "face_recognition_params.h"

using namespace cv;
using namespace std;
using namespace google::protobuf;
using namespace ascend::presenter;
using namespace ascend::presenter::facial_recognition;


namespace {
    const int32_t kMaxFaceIdLength = 50;
    const __useconds_t kSleepInterval = 200000;
    const string kJpegDFailedStr = "fail to convert jpg to yuv";
    const string kFaceIdInvalidStr = "length of face_id beyond range";
}

FaceRegister::FaceRegister(const std::string& configFile) :
FacialThreadBase(configFile), configFile_(configFile) {                         
}

FaceRegister::~FaceRegister() {
    dvpp_.DestroyResource();
}

AclLiteError FaceRegister::Init() {
    if (GetBaseConfig()) {
        ACLLITE_LOG_ERROR("Face register thread init failed "
                        "for get config error"); 
        return ACLLITE_ERROR;
    }

    AclLiteError ret = dvpp_.Init();
    if (ret) {
        ACLLITE_LOG_ERROR("Face detection thread init failed "
                        "for init dvpp error: %d", ret);
        return ACLLITE_ERROR;
    }   

    return OpenPresenterChannel();
}


AclLiteError FaceRegister::OpenPresenterChannel() {
    std::map<std::string, std::string> config;
    if(!ReadConfig(config, configFile_.c_str())) {
        ACLLITE_LOG_ERROR("Read config %s failed", configFile_.c_str());
        return ACLLITE_ERROR;
    }        
       
    PresenterServerParams param;
    map<string, string>::const_iterator mIter = config.begin();
    for (; mIter != config.end(); ++mIter) {
        if (mIter->first == "presenter_server_ip") {
            param.hostIp = mIter->second;
        }
        else if (mIter->first == "presenter_server_port") {
            param.port = std::stoi(mIter->second);
        }
        else if (mIter->first == "channel_name") {
            param.appId = mIter->second;
        }
    }
    param.appType = "facial_recognition";

    ACLLITE_LOG_INFO("Init Presenter Channel: host ip %s, port %d, "
                   "app name %s,app type %s",
                   param.hostIp.c_str(), param.port,
                   param.appId.c_str(), param.appType.c_str());

    PresenterChannels::GetInstance().Init(param);
    // create agent channel and register app
    Channel *channel= PresenterChannels::GetInstance().GetChannel();
    if (channel == nullptr) {
        ACLLITE_LOG_ERROR("Register app to presenter server failed");
        return ACLLITE_ERROR;
    }

    return ACLLITE_OK;
}


AclLiteError FaceRegister::FaceRegisterDaemon() {
    
    Channel* agentChannel = PresenterChannels::GetInstance().GetChannel();
    if (agentChannel == nullptr) {
        ACLLITE_LOG_ERROR("Get agent channel failed.");
        return ACLLITE_ERROR;
    }

    while (1) {
        unique_ptr<Message> regMsg = nullptr;
        FaceInfo* faceRegReq = ReceiveFaceRegisterRequest(agentChannel, regMsg);
        if (faceRegReq == nullptr) {
            usleep(kSleepInterval);
            continue;
        }
           
        shared_ptr< FaceRecognitionInfo> info = make_shared<FaceRecognitionInfo>();
        int faceIdSize = faceRegReq->id().size();
        if (faceIdSize > kMaxFaceIdLength) {
            ACLLITE_LOG_ERROR("Length of face %d id beyond range", faceIdSize);
            SendErrorReply(info, kFaceIdInvalidStr);
            continue;
        }

        if (ProcessFaceImage(info, faceRegReq)) {
            continue;
        }

        info->frame.imageSource = 1;
        info->frame.faceId = faceRegReq->id();
        info->errInfo.errCode = AppErrorCode::kNone;
        SendMessageToNext(MSG_FACE_REG_IMAGE, info);
    }
}

FaceInfo* FaceRegister::ReceiveFaceRegisterRequest(Channel* agentChannel, unique_ptr<Message> &regMsg) {
    
    PresenterErrorCode agentRet = agentChannel->ReceiveMessage(regMsg);
    if (agentRet != PresenterErrorCode::kNone) {
        return nullptr;
    }

    if (regMsg == nullptr) {
        ACLLITE_LOG_ERROR("Receive empty face register request message");
        return nullptr;
    }

    return (FaceInfo*)(regMsg.get());
}

AclLiteError FaceRegister::ProcessFaceImage(shared_ptr<FaceRecognitionInfo> info, 
                                          FaceInfo* faceRegReq) {
    uint32_t imageSize = faceRegReq->image().size();
    const char* imageBuf = faceRegReq->image().c_str();

    ImageData jpgImage;
    int32_t ch = 0;
    acldvppJpegGetImageInfo(imageBuf, imageSize,
            &(jpgImage.width), &(jpgImage.height), &ch);

    void * buffer = CopyDataToDevice(imageBuf, imageSize, 
                                     GetRunMode(), MEMORY_DVPP);
    if (buffer == nullptr) {
        ACLLITE_LOG_ERROR("Copy face register request image to dvpp failed");
        return ACLLITE_ERROR;
    }
    jpgImage.data = SHARED_PTR_DVPP_BUF(buffer);
    jpgImage.size = imageSize;

    AclLiteError ret = dvpp_.JpegD(info->orgImg, jpgImage);
    if(ret) {
        ACLLITE_LOG_ERROR("Convert face register image "
                        "to yuv failed, error %d", ret);
        SendErrorReply(info, kJpegDFailedStr);
    }

    return ACLLITE_OK;    
}

AclLiteError FaceRegister::SendErrorReply(shared_ptr<FaceRecognitionInfo> info,
                                        const string& errMsg) {
    int postProcessThreadId = GetAclLiteThreadIdByName(kPostProcessThreadName);
    if (postProcessThreadId == INVALID_INSTANCE_ID) {
        ACLLITE_LOG_ERROR("Get post process thread id failed");
        return ACLLITE_ERROR;
    }

    info->errInfo.errCode = AppErrorCode::kRegister;
    info->errInfo.errMsg.assign(errMsg);

    return SendMessage(postProcessThreadId, MSG_FACE_REG_INVALID, info);
} 

AclLiteError FaceRegister::Process(int msgId, shared_ptr<void> msgData) {
    AclLiteError ret = ACLLITE_OK;
    switch(msgId) {
        case MSG_FACE_REGISTER_DAEMON:
            ret = FaceRegisterDaemon();
            break;
        default:
            ACLLITE_LOG_ERROR("Face detect thread receive unknow msg %d", msgId);
            break;
    }

    return ret;
 }
