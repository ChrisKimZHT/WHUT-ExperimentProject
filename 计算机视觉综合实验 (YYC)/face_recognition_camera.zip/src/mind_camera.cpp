/**
 * ============================================================================
 *
 * Copyright (C) 2018-2020, Hisilicon Technologies Co., Ltd. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   1 Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *
 *   2 Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *
 *   3 Neither the names of the copyright holders nor the names of the
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 * ============================================================================
 */

#include "mind_camera.h"

#include <memory>
#include <iostream>
#include <fstream>
#include <sstream>
#include <cstdio>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <cstring>
#include <chrono>

#include "acllite/AclLiteApp.h"
#include "acllite/AclLiteVideoProc.h"

extern "C" {
#include "peripheral_api.h"
}

using namespace std;

MindCamera::MindCamera(const string& configFile) : 
FacialThreadBase(configFile), 
selfThreadId_(INVALID_INSTANCE_ID),
cap_(nullptr) {   
}

MindCamera::~MindCamera() {
    if (cap_) {
        delete cap_;
        cap_ = nullptr;
    }
}

AclLiteError MindCamera::Init() {
    if (GetBaseConfig()) {
        ACLLITE_LOG_ERROR("Face detection thread init failed "
                        "for get config error"); 
        return ACLLITE_ERROR;
    }

    selfThreadId_ = SelfInstanceId();
    if (selfThreadId_ == INVALID_INSTANCE_ID) {
        ACLLITE_LOG_ERROR("Mind camera init failed for "
                        "get self thread id failed");
        return ACLLITE_ERROR;
    }    

    cap_ = new AclLiteVideoProc(); 
    if (!cap_->IsOpened()) {
        ACLLITE_LOG_ERROR("Mind camera init failed for open camera failed");
        return ACLLITE_ERROR;
    } 

    return ACLLITE_OK;
}

AclLiteError MindCamera::ReadFrameMsgProcess() {
    shared_ptr<FaceRecognitionInfo> recogInfo =
        make_shared<FaceRecognitionInfo>();
    //Read one frame
    AclLiteError ret = cap_->Read(recogInfo->orgImg);
    if (ret) {
        //If read from video file, return ACLLITE_ERROR_DECODE_FINISH
        //when read last frame, is not error
        if (ret == ACLLITE_ERROR_DECODE_FINISH) {
            ACLLITE_LOG_INFO("Read all frame finish");
            return ACLLITE_OK;
        } else {
            //Read frame failed, return ACLLITE_ERROR will cause thread exit 
            ACLLITE_LOG_ERROR("Read frame frome camera failed, error:%d", ret);
            return ACLLITE_ERROR;
        }
    }
    //Send frame to next(face detection) thread
    ret = SendMessageToNext(MSG_FRAME_DATA, recogInfo);
    if (ret != ACLLITE_OK) {
        ACLLITE_LOG_ERROR("Send preprocess data failed, error %d", ret);
        return ret;
    }   
    //Send MSG_READ_FRAME to self cause read next frame
    ret = SendMessage(selfThreadId_, MSG_READ_FRAME, nullptr); 
    if (ret) {
        ACLLITE_LOG_ERROR("Send MSG_READ_FRAME error: %d", ret);
        return ACLLITE_ERROR;                
    }

    return ACLLITE_OK;
}

AclLiteError MindCamera::Process(int msgId, shared_ptr<void> msgData) {
    AclLiteError ret = ACLLITE_OK;
    switch(msgId) {
        case MSG_READ_FRAME:
            ret = ReadFrameMsgProcess();
            break;
        default:
            ACLLITE_LOG_ERROR("Mind camera thread receive unknow msg %d", msgId);
            break;
    }

    return ret;
}


