/**
* Copyright 2020 Huawei Technologies Co., Ltd
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at

* http://www.apache.org/licenses/LICENSE-2.0

* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.

* File main.cpp
* Description: dvpp sample main func
*/

#include <iostream>
#include <stdlib.h>
#include <dirent.h>
#include <thread>
#include <time.h>
#include <fstream>

#include "acllite/AclLiteResource.h"
#include "acllite/AclLiteApp.h"
#include "acllite/AclLiteThread.h"
#include "acllite/AclLiteType.h"
#include "acllite/AclLiteError.h"

#include "face_detection.h"
#include "face_feature_mask.h"
#include "face_recognition.h"
#include "face_post_process.h"
#include "face_register.h"
#include "mind_camera.h"

using namespace std;

namespace {
    const string kConfigFile = "../scripts/param.conf";
}

void ExitApp(AclLiteApp& app, vector<AclLiteThreadParam>& threadTbl) {
    //When app exit, delete all thread instance
    for (int i = 0; i < threadTbl.size(); i++) {
        delete threadTbl[i].threadInst;
    }  

    app.Exit();
}

void CreateThreadInstance(vector<AclLiteThreadParam>& threadTbl, 
                          AclLiteResource& aclDev) {
    //set camera thread creation parameters
    AclLiteThreadParam cameraThreadParam;
    cameraThreadParam.threadInst = new MindCamera(kConfigFile);
    cameraThreadParam.threadInstName.assign(kCameraThreadName);    
    threadTbl.push_back(cameraThreadParam);

    //set face register thread creation parameters 
    AclLiteThreadParam registerThreadParam;
    registerThreadParam.threadInst = new FaceRegister(kConfigFile);
    registerThreadParam.threadInstName.assign(kRegisterThreadName);    
    threadTbl.push_back(registerThreadParam);

    //set face detection thread creation parameters 
    AclLiteThreadParam detectThreadParam;
    detectThreadParam.threadInst = new FaceDetection(kConfigFile);
    detectThreadParam.threadInstName.assign(kDetectThreadName);    
    threadTbl.push_back(detectThreadParam);

    //set face feature mask thread creation parameters 
    AclLiteThreadParam featureMaskThreadParam;
    featureMaskThreadParam.threadInst = new FaceFeatureMask(kConfigFile);
    featureMaskThreadParam.threadInstName.assign(kFeatureMaskThreadName);    
    threadTbl.push_back(featureMaskThreadParam);

    //set face recognition thread creation parameters
    AclLiteThreadParam recognitionThreadParam;
    recognitionThreadParam.threadInst = new FaceRecognition(kConfigFile);
    recognitionThreadParam.threadInstName.assign(kRecognitionThreadName);    
    threadTbl.push_back(recognitionThreadParam);

    //set face post process thread creation parameters
    AclLiteThreadParam postProcessThreadParam;
    postProcessThreadParam.threadInst = new FacePostProcess(kConfigFile);
    postProcessThreadParam.threadInstName.assign(kPostProcessThreadName);    
    threadTbl.push_back(postProcessThreadParam);
    
    //set all thread acl context and run mode
    for (int i = 0; i < threadTbl.size(); i++) {
        threadTbl[i].context = aclDev.GetContext();
        threadTbl[i].runMode = aclDev.GetRunMode();
    }
}

void StartApp(AclLiteResource& aclDev) {
    //Create app instance
    AclLiteApp& app = CreateAclLiteAppInstance(); 
    
    //Create thread instance and set thread creation parameters
    vector<AclLiteThreadParam> threadTbl;
    CreateThreadInstance(threadTbl, aclDev);
    
    //Startup all thread
    AclLiteError ret = app.Start(threadTbl);
    if (ret != ACLLITE_OK) {
        ACLLITE_LOG_ERROR("Start app failed, error %d", ret);
        ExitApp(app, threadTbl);
        return;
    }
    
    //Notify camera thread start get frame
    ret = SendMessage(threadTbl[0].threadInstId, MSG_READ_FRAME, nullptr); 
    if (ret) {
        ACLLITE_LOG_ERROR("Send MSG_READ_FRAME to camear thread error: %d", ret);
        return;                
    }
    
    //Notify face register thread daemon register request from presenter server
    ret = SendMessage(threadTbl[1].threadInstId, 
                      MSG_FACE_REGISTER_DAEMON, nullptr); 
    if (ret) {
        ACLLITE_LOG_ERROR("Send MSG_READ_FRAME to camear thread error: %d", ret);
        return;                
    }

    //Block wait when all thread running
    app.Wait();
    //Release all resource when app exit
    ExitApp(app, threadTbl);

    return;
}

int main(int argc, char *argv[]) {
    //Init acl resource
    AclLiteResource aclDev = AclLiteResource();
    AclLiteError ret = aclDev.Init();
    if (ret != ACLLITE_OK) {
        ACLLITE_LOG_ERROR("Init app failed");
        return ACLLITE_ERROR;
    }    
    //Start run app
    StartApp(aclDev);
    return ACLLITE_OK;
}
