/**
 * ============================================================================
 *
 * Copyright (C) 2018-2020, Hisilicon Technologies Co., Ltd. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   1 Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *
 *   2 Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *
 *   3 Neither the names of the copyright holders nor the names of the
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 * ============================================================================
 */

#include "face_recognition.h"

#include <cstdint>
#include <unistd.h>
#include <memory>
#include <sstream>

#include "opencv2/opencv.hpp"
#include "opencv2/imgproc.hpp"
#include "opencv2/video.hpp"
#include "opencv2/video/tracking.hpp"
#include "opencv2/core/types_c.h"
#include "opencv2/imgproc/types_c.h"

using namespace cv;
using namespace std;

namespace {
// destination points for aligned face
const float kLeftEyeX = 30.2946;
const float kLeftEyeY = 51.6963;
const float kRightEyeX = 65.5318;
const float kRightEyeY = 51.5014;
const float kNoseX = 48.0252;
const float kNoseY = 71.7366;
const float kLeftMouthCornerX = 33.5493;
const float kLeftMouthCornerY = 92.3655;
const float kRightMouthCornerX = 62.7299;
const float kRightMouthCornerY = 92.2041;

// wapAffine estimate check cols(=2) and rows(=3)
const int32_t kEstimateRows = 2;
const int32_t kEstimateCols = 3;

// flip face
// Horizontally flip for OpenCV
const int32_t kHorizontallyFlip = 1;
// Vertically and Horizontally flip for OpenCV
const int32_t kVerticallyAndHorizontallyFlip = -1;
const uint32_t kBgrChannels = 3;
// inference batch
const int32_t kBatchSize = 4;
// every batch has one aligned face and one flip face, total 2
const int32_t kPerGroupImgCount = 2;
// every face inference result should contains 1024 vector (float)
const int32_t kEveryFaceResVecCount = 1024;
}

FaceRecognition::FaceRecognition(const std::string& configFile) : 
FacialThreadBase(configFile),
inputBuf_(nullptr),
inputSize_(0),
inputPad_(nullptr){
}

FaceRecognition::~FaceRecognition() {
    model_.DestroyResource();
    dvpp_.DestroyResource();

    if (inputBuf_) {
        aclrtFree(inputBuf_);
        inputBuf_ = nullptr;
    } 

    if (inputPad_) {
        delete[] inputPad_;
        inputPad_ = nullptr;
    }
}

AclLiteError FaceRecognition::Init() {
    if (GetBaseConfig()) {
        ACLLITE_LOG_ERROR("Face recognition thread init failed "
                        "for get config error"); 
        return ACLLITE_ERROR;
    }

    AclLiteError ret = model_.Init(ModelPath());
    if (ret) {
        ACLLITE_LOG_ERROR("Init model failed, error:%d", ret);
        return ACLLITE_ERROR;       
    }

    ret = dvpp_.Init();
    if (ret) {
        ACLLITE_LOG_ERROR("Init model failed, error:%d", ret);
        return ACLLITE_ERROR;       
    }

    CreateFaceAffineDestTemplate();

    inputSize_ = RGBU8_IMAGE_SIZE(ModelWidth(), ModelHeight()) * 
                 kPerGroupImgCount * kBatchSize;
    void* buf = nullptr;
    aclError aclRet = aclrtMalloc(&buf, inputSize_, 
                                  ACL_MEM_MALLOC_HUGE_FIRST);
    if ((buf == nullptr) || (aclRet != ACL_ERROR_NONE)) {
        ACLLITE_LOG_ERROR("Malloc inference input buffer failed, "
                        "error %d", aclRet);
        return ACLLITE_ERROR;
    }
    inputBuf_ = (uint8_t*)buf;

    inputPad_ = new uint8_t[inputSize_];
    memset(inputPad_, 0, inputSize_);
 
    return ACLLITE_OK;
}

void FaceRecognition::CreateFaceAffineDestTemplate() {
    faceAffineDest_.emplace_back(cv::Point2f(kLeftEyeX, kLeftEyeY));
    faceAffineDest_.emplace_back(cv::Point2f(kRightEyeX, kRightEyeY));
    faceAffineDest_.emplace_back(cv::Point2f(kNoseX, kNoseY));
    faceAffineDest_.emplace_back(cv::Point2f(kLeftMouthCornerX, kLeftMouthCornerY));
    faceAffineDest_.emplace_back(cv::Point2f(kRightMouthCornerX, kRightMouthCornerY));
}

AclLiteError FaceRecognition::AlignedAndFlipFace(
    vector<AlignedFace>& alignedImgs, FaceImage& faceImg, 
    ImageData& resizedImage, int32_t index) {    
    Mat alignedImg;
    AclLiteError ret = FaceFeatureMaskAffine(alignedImg, resizedImage, faceImg);
    if (ret) {
        ACLLITE_LOG_ERROR("Face feature affine failed");
        return ACLLITE_ERROR;
    }

    Mat hFlip;
    flip(alignedImg, hFlip, kHorizontallyFlip);

    Mat hvFlip;
    flip(hFlip, hvFlip, kVerticallyAndHorizontallyFlip);

    cvtColor(alignedImg, alignedImg, cv::COLOR_BGR2RGB);
    cvtColor(hvFlip, hvFlip, cv::COLOR_BGR2RGB);

    AlignedFace result;
    result.faceIndex = index;
    result.alignedFace = alignedImg;
    result.alignedFlipFace = hvFlip;
    alignedImgs.emplace_back(result);

    return ACLLITE_OK;
}

AclLiteError FaceRecognition::FaceFeatureMaskAffine(Mat& affinedImg, 
                                                  ImageData &resizedImage,
                                                  FaceImage &faceImg) {
    Mat affineMat;
    if (FaceFeatureMaskEstimateAffine(affineMat, faceImg)) {
        ACLLITE_LOG_ERROR("Calculate face feature mask affine failed");
        return ACLLITE_ERROR;        
    } 

    Mat src(YUV420SP_CV_MAT_HEIGHT(resizedImage.height), 
            resizedImage.width, CV_8UC1);
    memcpy(src.data, resizedImage.data.get(), 
           YUV420SP_SIZE(resizedImage.width, resizedImage.height));
    Mat bgr;
    cvtColor(src, bgr, CV_YUV2BGR_NV12);
    cv::Size imgSize(ModelWidth(), ModelHeight());
    warpAffine(bgr, affinedImg, affineMat, imgSize);

    return ACLLITE_OK;
}

AclLiteError FaceRecognition::FaceFeatureMaskEstimateAffine(Mat& affineMat, 
                                                          FaceImage &faceImg) {
    // Origin face feature point should be changed to resized image point
    vector<cv::Point2f> srcPoints;
    FaceFeatureMaskResize(srcPoints, faceImg);

    // first set partialAffine, limited to combinations of translation,
    // rotation, and uniform scaling (4 degrees of freedom)
    affineMat = estimateAffinePartial2D(srcPoints, faceAffineDest_);

    // If transform matrix not match warpAffine, set fullAffine
    if (!CheckTransfromMat(affineMat)) {
        ACLLITE_LOG_INFO("estimateRigidTransform using partialAffine failed,"
                       "try to using fullAffine");
        affineMat = estimateAffine2D(srcPoints, faceAffineDest_);
    }

    // check again, if not match, return ACLLITE_ERROR
    if (!CheckTransfromMat(affineMat)) {
        ACLLITE_LOG_INFO("Calculate partialAffine and fullAffine all failed."
                       "skip this image.");
        return ACLLITE_ERROR;
    }

    return ACLLITE_OK;
}

AclLiteError FaceRecognition::FaceFeatureMaskResize(vector<Point2f>& destPoints, 
                                                  FaceImage &faceImg) {
    float srcWidth = (float)faceImg.image.width;
    float srcHeight = (float)faceImg.image.height;

    // left eye
    float leftEyeX = faceImg.featureMask.leftEye.x / srcWidth
        * ModelWidth();
    float leftEyeY = faceImg.featureMask.leftEye.y / srcHeight
        * ModelHeight();
    destPoints.emplace_back(leftEyeX, leftEyeY);
    // right eye
    float rightEyeX = faceImg.featureMask.rightEye.x / srcWidth
        * ModelWidth();
    float rightEyeY = faceImg.featureMask.rightEye.y / srcHeight
        * ModelHeight();
    destPoints.emplace_back(rightEyeX, rightEyeY);
    // nose
    float noseX = faceImg.featureMask.nose.x / srcWidth * ModelWidth();
    float noseY = faceImg.featureMask.nose.y / srcHeight * ModelHeight();
    destPoints.emplace_back(noseX, noseY);
    // left mouth corner
    float leftMouthX = faceImg.featureMask.leftMouth.x / srcWidth
        * ModelWidth();
    float leftMouthY = faceImg.featureMask.leftMouth.y / srcHeight
        * ModelHeight();
    destPoints.emplace_back(leftMouthX, leftMouthY);
    // right mouth corner
    float rightMouthX = faceImg.featureMask.rightMouth.x / srcWidth
        * ModelWidth();
    float rightMouthY = faceImg.featureMask.rightMouth.y / srcHeight
        * ModelHeight();
    destPoints.emplace_back(rightMouthX, rightMouthY);
}

bool FaceRecognition::CheckTransfromMat(Mat &mat) {
    // openCV warpAffine need transformation matrix match:
    // 1. type need CV_32F
    // 2. rows must be 2
    // 3. cols must be 3
    if ((mat.type() == CV_32F || mat.type() == CV_64F) && 
        (mat.rows == kEstimateRows) && 
        (mat.cols == kEstimateCols)) {
        return true;
    }
    ACLLITE_LOG_ERROR("transformation matrix not match, "
                    "real type %d, rows %d, cols %d",
                    mat.type(), mat.rows, mat.cols);
    return false;
}

void FaceRecognition::PreProcess(vector<AlignedFace> &alignedImgs,
                                 vector<FaceImage> &faceImgs) {
    for (int32_t index = 0; index < faceImgs.size(); ++index) {
        // resize image, if failed, skip it
        ImageData resizedImage;
        AclLiteError ret = dvpp_.Resize(resizedImage, faceImgs[index].image, 
                                      ModelWidth(), ModelHeight());
        if (ret) {
            ACLLITE_LOG_ERROR("Resize image failed, error:%d", ret);
            continue;
        }

        // aligned and flip face, if failed, skip it
        ret = AlignedAndFlipFace(alignedImgs, faceImgs[index], 
                                 resizedImage, index);
        if (ret) {
            continue;
        }
    }
}

AclLiteError FaceRecognition::CopyOneBatchImage(uint8_t* dataBuffer,
                                              uint32_t bufferSize,
                                              uint32_t eachImgSize,                                    
                                              vector<AlignedFace> &alignedImgs, 
                                              int32_t startIdx) {
    uint32_t lastSize = 0;
    uint32_t remainder = alignedImgs.size() - startIdx;
    uint32_t copyNum = (remainder >= kBatchSize)?kBatchSize:remainder;
    AclLiteError ret = ACLLITE_OK;

    for (int i = 0; i < copyNum; ++i) {
        AlignedFace faceImg = alignedImgs[startIdx + i];
        // copy aligned face image
        ret = CopyDataToDeviceEx(dataBuffer + lastSize, bufferSize - lastSize,      
                                 faceImg.alignedFace.ptr<uint8_t>(), 
                                 eachImgSize, GetRunMode());
        if (ret) {
            ACLLITE_LOG_ERROR("Copy aligned image to device failed");
            return ACLLITE_ERROR;
        }
        lastSize += eachImgSize;

        // copy aligned flip face image
        ret = CopyDataToDeviceEx(dataBuffer + lastSize, bufferSize - lastSize,                                    
                                 faceImg.alignedFlipFace.ptr<uint8_t>(), 
                                 eachImgSize, GetRunMode());
        if (ret) {
            ACLLITE_LOG_ERROR("Copy aligned flip image to device failed");
            return ACLLITE_ERROR;
        }
        lastSize += eachImgSize;
    }
    //If image number in current batch less than batch size, pad remainder
    //memory with zero
    if (copyNum < kBatchSize) {
        ret = CopyDataToDeviceEx(dataBuffer + lastSize, bufferSize - lastSize, 
                                 inputPad_,                                     
                                 eachImgSize * 2 * (kBatchSize - copyNum),
                                 GetRunMode());
        if (ret) {
            ACLLITE_LOG_ERROR("Pad input buffer failed");
            return ACLLITE_ERROR;
        }
    }

    return ACLLITE_OK;
}

AclLiteError FaceRecognition::Inference(vector<FaceImage> &faceImgs,
                                      vector<AlignedFace> &alignedImgs) {
    AclLiteError ret = ACLLITE_ERROR;                                      
    uint32_t eachImgSize = alignedImgs[0].alignedFace.total() *
                           alignedImgs[0].alignedFace.channels();
    printf("each image size %d, width %d, height %d \n", eachImgSize, alignedImgs[0].alignedFace.rows,
    alignedImgs[0].alignedFace.cols);
    for (int32_t i = 0; i < alignedImgs.size(); i += kBatchSize) {
        //copy one batch data to device
        if (CopyOneBatchImage(inputBuf_, inputSize_, 
                              eachImgSize, alignedImgs, i)) {
            ACLLITE_LOG_INFO("Copy face recognition inference data failed, "
                           "batch index %d, batch size %d", i, kBatchSize);                           
            continue;
        }
        //inference one batch data
        vector<InferenceOutput> inferenceOutput;
        if (model_.Execute(inferenceOutput, inputBuf_, inputSize_)) {
            ACLLITE_LOG_ERROR("Execute face recognition model inference failed");
            continue;
        }
        //process inference result
        if (PostProcess(faceImgs, inferenceOutput, alignedImgs, i)) {
            ACLLITE_LOG_ERROR("Face recognition post process failed, "
                            "startIdx %d, batch_size %d", i, kBatchSize);                      
            continue;
        }

        ret = ACLLITE_OK;
    }
    
    return ret;
}

AclLiteError FaceRecognition::PostProcess(
    vector<FaceImage> &faceImgs,    
    vector<InferenceOutput>& inferenceOutput,
    vector<AlignedFace> &alignedImgs,
    int32_t startIdx) {
    // get real image number in current batch
    int32_t itemNum = kBatchSize;
    if (alignedImgs.size() - startIdx < kBatchSize) {
        itemNum = alignedImgs.size() - startIdx;
    }

    // every image need 1024 float vector
    float* result = (float *)inferenceOutput[0].data.get();
    uint32_t inferenceSize = inferenceOutput[0].size/sizeof(float);
    int32_t checkSize = itemNum * kEveryFaceResVecCount;
    if (checkSize > inferenceSize) {
        ACLLITE_LOG_INFO("inference result size not correct. start idx %d, "
                       "total face %lu, result size %u, need size %d",
                       startIdx, alignedImgs.size(), inferenceSize, checkSize);
        return ACLLITE_ERROR;
    }

    // set every face inference result
    for (int i = 0; i < itemNum; ++i) {
        // set to faceImgs according to index
        int faceIdx = alignedImgs[startIdx + i].faceIndex;
        int baseIdx = i * kEveryFaceResVecCount;
        for (int j = 0; j < kEveryFaceResVecCount; ++j) {
            faceImgs[faceIdx].featureVector.emplace_back(result[baseIdx + j]);                
        }
    }

    return ACLLITE_OK;
}

void FaceRecognition::FaceFeatureMaskMsgProcess(
    shared_ptr<FaceRecognitionInfo> faceFeature) {
    //No face detect in origin image
    if (faceFeature->faceImgs.size() == 0) {
        SendMessageToNext(MSG_FACE_RECOGNIZE_DATA, faceFeature);
        return;
    }

    vector<AlignedFace> alignedImgs;
    PreProcess(alignedImgs, faceFeature->faceImgs);
    if (alignedImgs.empty()) {
        SendMessageToNext(MSG_FACE_RECOGNIZE_DATA, faceFeature);
        return;
    }

    // inference and set results
    if (Inference(faceFeature->faceImgs, alignedImgs)) {
        ACLLITE_LOG_ERROR("Face recognize inference failed");
    }

    // send result
    SendMessageToNext(MSG_FACE_RECOGNIZE_DATA, faceFeature);
}


AclLiteError FaceRecognition::Process(int msgId, shared_ptr<void> msgData) {
    switch(msgId) {
        case MSG_FACE_FEATURE_MASK:
            FaceFeatureMaskMsgProcess(
                      static_pointer_cast<FaceRecognitionInfo>(msgData));
            break;
        default:
            ACLLITE_LOG_ERROR("Face recognition thread receive "
                            "unknow msg %d", msgId);
            break;
    }

    return ACLLITE_OK;
}