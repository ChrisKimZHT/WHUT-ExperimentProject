/**
 * ============================================================================
 *
 * Copyright (C) 2018-2020, Hisilicon Technologies Co., Ltd. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   1 Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *
 *   2 Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *
 *   3 Neither the names of the copyright holders nor the names of the
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 * ============================================================================
 */
#include <memory>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <string.h>
#include <cstring>

#include "opencv2/opencv.hpp"
#include "opencv2/imgproc.hpp"
#include "opencv2/core/types_c.h"
#include "opencv2/imgproc/types_c.h"

#include "face_feature_mask.h"
#include "face_feature_train_mean.h"
#include "face_feature_train_std.h"

using namespace std;
using namespace cv;

namespace {
// For each input, the result should be one tensor
const int32_t kEachResultTensorNum = 10;
// The center's size for the inference result
const float kNormalizedCenterData = 0.5;
const int32_t kBatch = 4;
const int kInvalidSize = -1;
}

FaceFeatureMask::FaceFeatureMask(const string& configFile) : 
FacialThreadBase(configFile),
batchSize_(kBatch) {
}

FaceFeatureMask::~FaceFeatureMask() {
    model_.DestroyResource();
    dvpp_.DestroyResource();

    if (inputBuf_) {
        aclrtFree(inputBuf_);
        inputBuf_ = nullptr;
    }

    if (facePositionBuf_) {
        delete facePositionBuf_;
        facePositionBuf_ = nullptr;
    }
}

AclLiteError FaceFeatureMask::Init() {
    if (GetBaseConfig()) {
        ACLLITE_LOG_ERROR("Face Feature mask thread init failed "
                        "for get config error"); 
        return ACLLITE_ERROR;
    }

    AclLiteError ret = model_.Init(ModelPath());
    if (ret) {
        ACLLITE_LOG_ERROR("Init model failed, error:%d", ret);
        return ACLLITE_ERROR;       
    }

    ret = dvpp_.Init();
    if (ret) {
        ACLLITE_LOG_ERROR("Init dvpp failed, error:%d", ret);
        return ACLLITE_ERROR;       
    }

    if (InitNormlizedData()) {
        return ACLLITE_ERROR;
    }

    inputSize_ = RGBF32_IMAGE_SIZE(ModelWidth(), ModelHeight()) * batchSize_;
    void* buf = nullptr;
    aclError aclRet = aclrtMalloc(&buf, inputSize_, 
                                  ACL_MEM_MALLOC_HUGE_FIRST);
    if ((buf == nullptr) || (aclRet != ACL_ERROR_NONE)) {
        ACLLITE_LOG_ERROR("Malloc inference input buffer failed, "
                        "error %d", aclRet);
        return ACLLITE_ERROR;
    }
    inputBuf_ = (uint8_t *)buf;

    facePositionBuf_ = new int[kEachResultTensorNum];

    return ACLLITE_OK;
}

AclLiteError FaceFeatureMask::InitNormlizedData() {
    // Load the mean data
    Mat trainMeanValue(ModelWidth(), ModelHeight(), 
                       CV_32FC3, (void *)kTrainMean);
    trainMean_ = trainMeanValue;
    if (trainMean_.empty()) {
        ACLLITE_LOG_ERROR("Load mean failed!");
        return ACLLITE_ERROR;
    }

    // Load the STD data
    Mat trainStdValue(ModelWidth(), ModelHeight(), 
                      CV_32FC3, (void *)kTrainStd);
    trainStd_ = trainStdValue;
    if (trainStd_.empty()) {
        ACLLITE_LOG_ERROR("Load std failed!");
        return ACLLITE_ERROR;
    }

    return ACLLITE_OK;
}

AclLiteError FaceFeatureMask::Crop(vector<FaceImage> &faceImgs, 
                                 ImageData &orgImg) {
    static int cnt = 0;
    AclLiteError ret = ACLLITE_OK;
    for (int i = 0; i < faceImgs.size(); i++) {
        ret = dvpp_.Crop(faceImgs[i].image, orgImg,
                         faceImgs[i].rectangle.lt.x, faceImgs[i].rectangle.lt.y,
                         faceImgs[i].rectangle.rb.x, faceImgs[i].rectangle.rb.y);                                    
        if (ret) {
            ACLLITE_LOG_ERROR("Crop image failed, error: %d, image width %d, "
                            "height %d, size %d, crop area (%d, %d) (%d, %d)", 
                            ret, faceImgs[i].image.width, faceImgs[i].image.height,                            
                            faceImgs[i].image.size, faceImgs[i].rectangle.lt.x, 
                            faceImgs[i].rectangle.lt.y, faceImgs[i].rectangle.rb.x, 
                            faceImgs[i].rectangle.rb.y);
            return ACLLITE_ERROR;
        }
    }

    return ret;
}

AclLiteError FaceFeatureMask::Resize(vector<ImageData> &resizedImgs,
                                   vector<FaceImage> &faceImgs) {
    AclLiteError ret = ACLLITE_OK;
    for (size_t i = 0; i < faceImgs.size(); i++) {
        ImageData resizedImage;
        AclLiteError ret = dvpp_.Resize(resizedImage, faceImgs[i].image, 
                                      ModelWidth() * 2, ModelHeight() * 2);
        if (ret) {
            ACLLITE_LOG_ERROR("Resize image failed");
            return ACLLITE_ERROR;
        }
        resizedImgs.push_back(resizedImage);
    }
    
    return ret;
}

void FaceFeatureMask::BgrResize(Mat& dest, Mat& src, 
                                uint32_t width, uint32_t height) {
    Size dsize = Size(width, height);
    Mat dest32s = Mat(dsize, CV_32S);
    resize(src, dest32s, dsize);

    dest32s.convertTo(dest, CV_32FC3);
}

AclLiteError FaceFeatureMask::Decode(vector<Mat> &bgrImgs, 
                                   vector<ImageData> &resizedImgs) {
    for (size_t i = 0; i < resizedImgs.size(); i++) {
        Mat src(YUV420SP_CV_MAT_HEIGHT(resizedImgs[i].height), 
            resizedImgs[i].width, CV_8UC1);
        memcpy(src.data, resizedImgs[i].data.get(), 
            YUV420SP_SIZE(resizedImgs[i].width, resizedImgs[i].height));
        Mat bgr;
        cvtColor(src, bgr, CV_YUV2BGR_NV12);

        Mat resizedMat;
        BgrResize(resizedMat, bgr, ModelWidth(), ModelHeight());

        bgrImgs.push_back(resizedMat);
    }

    return ACLLITE_OK;
}

AclLiteError FaceFeatureMask::Normalize(vector<Mat> &bgrImage) {    
    bool failed = true;
    for (size_t i = 0; i < bgrImage.size(); i++) {
        // Sub the mean and divide the std
        bgrImage[i] = bgrImage[i] - trainMean_;
        bgrImage[i] = bgrImage[i] / trainStd_;
        // Record that whether all the data is empty
        if (failed && !bgrImage[i].empty()) {
            failed = false;
        }
    }

    return failed?ACLLITE_ERROR:ACLLITE_OK;
}

int FaceFeatureMask::CopyOneBatchImages(uint8_t* buffer, 
                                        uint32_t bufferSize, 
                                        vector<Mat>& images, 
                                        int batchIdx) {
    uint32_t j = 0;
    int dataLen = 0;
    int totalSize = 0;

    for (uint32_t i = batchIdx * batchSize_; 
         i < images.size() && j < batchSize_ && bufferSize > totalSize; 
         i++, j++) {
        dataLen = CopyImageMatData(buffer + totalSize, 
                                   bufferSize - totalSize, images[i]);
        if (dataLen == kInvalidSize) {
            return kInvalidSize;
        }
        totalSize += dataLen;
    }
    
    if (j < batchSize_) {
        for (uint32_t k = 0; 
             k < batchSize_ - j && bufferSize > totalSize; 
             k++) {
            dataLen = CopyImageMatData(buffer + totalSize, 
                                       bufferSize - totalSize, 
                                       images[images.size() - 1]); 
            if (dataLen == kInvalidSize) {
                return kInvalidSize;
            }
            totalSize += dataLen;
        }
    }

    return j;
}

int FaceFeatureMask::CopyImageMatData(uint8_t *buffer, 
                                      uint32_t bufferSize, Mat& image) {
    vector<Mat> imageChannels;
    split(image, imageChannels);
     
    uint32_t copySize = 0;
    AclLiteError ret = ACLLITE_OK;
    //copy data to device by channel as RRR...GGG...BBB
    for (size_t i = 0; i < imageChannels.size(); i++) {
        imageChannels[i].convertTo(imageChannels[i], CV_32FC3);
        uint32_t dataSize = imageChannels[i].rows * 
                            imageChannels[i].cols * sizeof(float);
        ret = CopyDataToDeviceEx(buffer + copySize, bufferSize - copySize, 
                                 imageChannels[i].ptr<uint8_t>(0), dataSize, 
                                 GetRunMode());
        if (ret) {
            ACLLITE_LOG_ERROR("Copy face data to device failed");
            return kInvalidSize;
        }
        copySize += dataSize;
    }

    return copySize;
}

AclLiteError FaceFeatureMask::Inference(vector<Mat> &normalizedImage,
                                      vector<FaceImage> &faceImgs) {
    int batchNum = ALIGN_UP(normalizedImage.size(), batchSize_) / batchSize_;
    for (int i = 0; i < batchNum; i++) { 
        //Copy one batch preprocessed image data to device     
        int faceNum = CopyOneBatchImages(inputBuf_, inputSize_, 
                                         normalizedImage, i);
        if (faceNum < 0) {
            ACLLITE_LOG_ERROR("Copy the %dth batch images failed", i);
            break;
        }
        //Inference one batch data
        vector<InferenceOutput> inferenceOutput;
        AclLiteError ret = model_.Execute(inferenceOutput, 
                                        inputBuf_, inputSize_);
        if (ret != ACLLITE_OK) {
            ACLLITE_LOG_ERROR("Execute model inference failed\n");
            break;
        }

        //Process the inference result.
        if (PostProcess(inferenceOutput, batchNum * i, faceNum, faceImgs)) {
            break;
        }
    }

    return ACLLITE_OK;
}

AclLiteError FaceFeatureMask::PostProcess(
    vector<InferenceOutput>& inferenceOutput,
    int startIdx, 
    int faceCnt,
    vector<FaceImage>& faceImgs) {  

    float* inferenceResult = (float *)inferenceOutput[0].data.get();
    for (int i = startIdx; i < startIdx + faceCnt; ++i ) {
        FaceImage* faceImage = &(faceImgs[i]);
        for (int j = 0; j < kEachResultTensorNum; j++) {
            int index = (i - startIdx) * kEachResultTensorNum + j;

            if (index % 2 == 0) {
                facePositionBuf_[j] = (int)((inferenceResult[index] + 
                                             kNormalizedCenterData) * 
                                             faceImage->image.width);
            } else {
                facePositionBuf_[j] = (int)((inferenceResult[index] + 
                                             kNormalizedCenterData) * 
                                             faceImage->image.height);
            }
        }
    
        ParseFacePosition(&(faceImage->featureMask), facePositionBuf_);
    }

    return ACLLITE_OK;
}

void FaceFeatureMask::ParseFacePosition(FaceFeature *faceFeature, 
                                         int *facePosition) {
    faceFeature->leftEye.x = facePosition[FaceFeaturePos::kLeftEyeX];
    faceFeature->leftEye.y = facePosition[FaceFeaturePos::kLeftEyeY];
    faceFeature->rightEye.x = facePosition[FaceFeaturePos::kRightEyeX];
    faceFeature->rightEye.y = facePosition[FaceFeaturePos::kRightEyeY];
    faceFeature->nose.x = facePosition[FaceFeaturePos::kNoseX];
    faceFeature->nose.y = facePosition[FaceFeaturePos::kNoseY];
    faceFeature->leftMouth.x = facePosition[FaceFeaturePos::kLeftMouthX];
    faceFeature->leftMouth.y = facePosition[FaceFeaturePos::kLeftMouthY];
    faceFeature->rightMouth.x = facePosition[FaceFeaturePos::kRightMouthX];
    faceFeature->rightMouth.y = facePosition[FaceFeaturePos::kRightMouthY];
}

AclLiteError FaceFeatureMask::PreProcess(
    vector<Mat>& processedImgs,
    shared_ptr<FaceRecognitionInfo> &recogInfo) {

    AclLiteError ret = Crop(recogInfo->faceImgs, recogInfo->orgImg);
    if (ret) {
        ACLLITE_LOG_ERROR("Crop all the data failed, all the data failed");
        return ACLLITE_ERROR;
    }

    vector<ImageData> resizedImgs;
    ret = Resize(resizedImgs, recogInfo->faceImgs);
    if (ret) {
        ACLLITE_LOG_ERROR("Resize all the data failed, all the data failed");
        return ACLLITE_ERROR;              
    }

    ret = Decode(processedImgs, resizedImgs);
    if (ret) {
        ACLLITE_LOG_ERROR("Convert all the data failed, all the data failed");
        return ACLLITE_ERROR;              
    }

    ret = Normalize(processedImgs);
    if (ret) {
        ACLLITE_LOG_ERROR("Normalize all the data failed, all the data failed");
        return ACLLITE_ERROR;              
    }

    return ACLLITE_OK;
}

AclLiteError FaceFeatureMask::FaceDetectMsgProcess(
    shared_ptr<FaceRecognitionInfo> recogInfo){
    //No face detected
    if (recogInfo->faceImgs.size() == 0) {
        SendMessageToNext(MSG_FACE_FEATURE_MASK, recogInfo);
        return ACLLITE_OK;
    }

    vector<Mat> processedImgs;
    AclLiteError ret = PreProcess(processedImgs, recogInfo);
    if (ret) {
        return ACLLITE_ERROR;
    }
    // Inference the data
    ret = Inference(processedImgs, recogInfo->faceImgs);
    if (ret) {
        return ACLLITE_ERROR;
    }
    //Send all images feature data to next thread
    ret = SendMessageToNext(MSG_FACE_FEATURE_MASK, recogInfo);
    if (ret) {
        ACLLITE_LOG_ERROR("Send face feature mask to next"
                        " thread failed, error: %d", ret);
    }

    return ret;
}

AclLiteError FaceFeatureMask::Process(int msgId, 
                                    shared_ptr<void> msgData) {
    AclLiteError ret = ACLLITE_OK;
    switch(msgId) {
        case MSG_FACE_DETECT_DATA:
            ret = FaceDetectMsgProcess(
                static_pointer_cast<FaceRecognitionInfo>(msgData));
            break;
        default:
            ACLLITE_LOG_ERROR("Face feature mask thread receive "
                            "unknow msg %d", msgId);
            break;
    }

    return ret;
}

