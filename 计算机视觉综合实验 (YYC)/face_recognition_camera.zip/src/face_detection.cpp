/**
 * ============================================================================
 *
 * Copyright (C) 2018-2020, Hisilicon Technologies Co., Ltd. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   1 Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *
 *   2 Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *
 *   3 Neither the names of the copyright holders nor the names of the
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 * ============================================================================
 */

#include <vector>
#include <sstream>
#include <unistd.h>
#include <fstream>

#include "face_detection.h"

using namespace std;

namespace {
// confidence range [0.0, 1.0]
const float kConfidenceMin = 0.0;
const float kConfidenceMax = 1.0;
const float kConfidenceTh = 0.9;

// coordinate ratio range
const float kMinRatio = 0.0;
const float kMaxRatio = 1.0;

// each result size (8 float)
const int32_t kEachResultSize = 8;
const uint32_t kBBoxDataBufId = 1;
const uint32_t kBoxNumDataBufId = 0;
enum BBoxIndex {EMPTY = 0, LABEL,SCORE,TOPLEFTX,TOPLEFTY, BOTTOMRIGHTX, BOTTOMRIGHTY};
}

FaceDetection::FaceDetection(const string& configFile) :
FacialThreadBase(configFile){
}

FaceDetection::~FaceDetection() {
    model_.DestroyResource();
    dvpp_.DestroyResource();
}

AclLiteError FaceDetection::Init() {
    if (GetBaseConfig()) {
        ACLLITE_LOG_ERROR("Face detection thread init failed "
                        "for get config error"); 
        return ACLLITE_ERROR;
    }

    AclLiteError ret = dvpp_.Init();
    if (ret) {
        ACLLITE_LOG_ERROR("Face detection thread init failed "
                        "for init dvpp error: %d", ret);
        return ACLLITE_ERROR;
    }
    //Load face detection om 
    ret = model_.Init(ModelPath());
    if (ret) {
        ACLLITE_LOG_ERROR("Face detection thread init failed "
                        "for init model error: %d", ret);
        return ACLLITE_ERROR;
    }

    return ACLLITE_OK;
}

float FaceDetection::CorrectionRatio(float ratio) {
    return (ratio <= kMinRatio) ? kMinRatio : 
           ((ratio >= kMaxRatio) ? kMaxRatio : ratio);
}

bool FaceDetection::IsValidResults(float* resultItem) {
    //Face reference confidence must in [kConfidenceTh, 1.0]
    if ((resultItem[SCORE] < kConfidenceTh) || 
        (resultItem[SCORE] > kConfidenceMax)) {
        return false;
    } 

    //Face box left top coordinate must smaller then right bottom 
    if ((resultItem[TOPLEFTX] >= resultItem[BOTTOMRIGHTX]) || 
        (resultItem[TOPLEFTY] >= resultItem[BOTTOMRIGHTY])) {
        return false;
    }

    return true;
}

AclLiteError FaceDetection::PostProcess(
    shared_ptr<FaceRecognitionInfo> recogInfo,
    vector<InferenceOutput>& inferenceResult) {
    float* detectData = (float*)inferenceResult[kBBoxDataBufId].data.get();
    uint32_t* boxNum = (uint32_t *)inferenceResult[kBoxNumDataBufId].data.get();

    uint32_t width = recogInfo->orgImg.width;
    uint32_t height = recogInfo->orgImg.height;
    for (int32_t i = 0; i < boxNum[0]; i++) {
        float *ptr = detectData + i * kEachResultSize;
        if(!IsValidResults(ptr)) {
            break;
        }

        FaceRectangle rectangle;
        rectangle.lt.x = CorrectionRatio(ptr[TOPLEFTX]) * width;
        rectangle.lt.y = CorrectionRatio(ptr[TOPLEFTY]) * height;
        rectangle.rb.x = CorrectionRatio(ptr[BOTTOMRIGHTX]) * width;
        rectangle.rb.y = CorrectionRatio(ptr[BOTTOMRIGHTY]) * height;	
        
        FaceImage faceImage;
        faceImage.rectangle = rectangle;
        recogInfo->faceImgs.emplace_back(faceImage);
    }

    return ACLLITE_OK;
}

AclLiteError FaceDetection::FrameDataMsgProcess(
    shared_ptr<FaceRecognitionInfo> recogInfo) {
    ImageData resizedImage;
    AclLiteError ret = dvpp_.Resize(resizedImage, recogInfo->orgImg, 
                                  ModelWidth(), ModelHeight());
    if (ret == ACLLITE_ERROR) {
        ACLLITE_LOG_ERROR("Resize image failed, error:%d", ret);
        return ACLLITE_ERROR;
    }

    vector<InferenceOutput> inferenceOutput;
    ret = model_.Execute(inferenceOutput, 
                         resizedImage.data.get(), resizedImage.size);
    if (ret != ACLLITE_OK) {
        model_.DestroyInput();
        ACLLITE_LOG_ERROR("Execute model inference failed");
        return ACLLITE_ERROR;
    }

    if (PostProcess(recogInfo, inferenceOutput)) {
        ACLLITE_LOG_ERROR("Face detection post process failed.");
        return ACLLITE_ERROR;
    }
    //Send face box data to next(face feature mask) thread
    return SendMessageToNext(MSG_FACE_DETECT_DATA, recogInfo);
}

AclLiteError FaceDetection::Process(int msgId, shared_ptr<void> msgData) {
    AclLiteError ret = ACLLITE_OK;
    switch(msgId) {
        case MSG_FRAME_DATA:
            ret = FrameDataMsgProcess(
                      static_pointer_cast<FaceRecognitionInfo>(msgData));
            break;
        case MSG_FACE_REG_IMAGE:
            ret = FrameDataMsgProcess(
                      static_pointer_cast<FaceRecognitionInfo>(msgData));
            break; 
        default:
            ACLLITE_LOG_INFO("Face detect thread receive unknow msg %d", msgId);
            break;
    }

    return ret;
}
