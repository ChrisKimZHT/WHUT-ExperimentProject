/**
 * ============================================================================
 *
 * Copyright (C) 2018-2020, Hisilicon Technologies Co., Ltd. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   1 Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *
 *   2 Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *
 *   3 Neither the names of the copyright holders nor the names of the
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 * ============================================================================
 */

#include "face_post_process.h"

#include <memory>
#include <fstream>
#include <sstream>
#include <cstdio>
#include <cstring>
#include <string>

using namespace std;
using namespace google::protobuf;
using namespace ascend::presenter;

FacePostProcess::FacePostProcess(const string& configFile) : 
configFile_(configFile) {    
}

FacePostProcess::~FacePostProcess() {  
    dvpp_.DestroyResource();  
}

AclLiteError FacePostProcess::Init() {
    AclLiteError ret = dvpp_.Init();
    if (ret) {
        ACLLITE_LOG_ERROR("Post process thread init failed "
                        "for init dvpp error: %d", ret);
        return ACLLITE_ERROR;
    }

    return ACLLITE_OK;
}

AclLiteError FacePostProcess::SendMessage(Message& message) {
    Channel *channel = PresenterChannels::GetInstance().GetPresenterChannel();
    if (channel == nullptr) {
        ACLLITE_LOG_ERROR("get channel for send FrameInfo failed.");
        return ACLLITE_ERROR;
    }
    unique_ptr<Message> resp;
    //PresenterErrorCode errCode = channel->SendMessage(message, resp);
    PresenterErrorCode errCode = channel->SendMessage(message);
    if (errCode != PresenterErrorCode::kNone) {
        ACLLITE_LOG_ERROR("Send message to presenter server failed. error:%d", 
                       int(errCode));
        return ACLLITE_ERROR;
    }

    return ACLLITE_OK;
}

AclLiteError FacePostProcess::SendFeature(
    shared_ptr<FaceRecognitionInfo> info) {
    ImageData jpgImage;    
    AclLiteError ret = dvpp_.JpegE(jpgImage, info->orgImg);
    if(ret) {
        ACLLITE_LOG_ERROR("Failed to convert yuv to jpg, skip this frame.");
        return ACLLITE_ERROR;
    }

    facial_recognition::FrameInfo frameInfo;
    frameInfo.set_image(string(reinterpret_cast<char*>(jpgImage.data.get()),
                        jpgImage.size));

    for (int i = 0; i < info->faceImgs.size(); i++) {
        facial_recognition::FaceFeature *feature = frameInfo.add_feature();
        PrepareFaceBoxData(feature, info->faceImgs[i]);
    }

    return SendMessage(frameInfo);
}

void FacePostProcess::PrepareFaceBoxData(
    facial_recognition::FaceFeature* feature, FaceImage& faceImg) {
    feature->mutable_box()->set_lt_x(faceImg.rectangle.lt.x);
    feature->mutable_box()->set_lt_y(faceImg.rectangle.lt.y);
    feature->mutable_box()->set_rb_x(faceImg.rectangle.rb.x);
    feature->mutable_box()->set_rb_y(faceImg.rectangle.rb.y);

    for (int j = 0; j < faceImg.featureVector.size(); j++) {
        feature->add_vector(faceImg.featureVector[j]);
    }  
}

AclLiteError FacePostProcess::ReplyFeature(
    shared_ptr<FaceRecognitionInfo> info) {
    facial_recognition::FaceResult result;
    result.set_id(info->frame.faceId);
    if (info->errInfo.errCode != AppErrorCode::kNone) {
        ACLLITE_LOG_INFO("Register face feature extract failed, error %d", 
                       (int)(info->errInfo.errCode));

        result.mutable_response()->set_ret(facial_recognition::kErrorOther);
        result.mutable_response()->set_message(info->errInfo.errMsg);

        return SendMessage(result);
    }

    result.mutable_response()->set_ret(facial_recognition::kErrorNone);
    for (int i = 0; i < info->faceImgs.size(); i++) {
        facial_recognition::FaceFeature *feature = result.add_feature();
        PrepareFaceBoxData(feature, info->faceImgs[i]);
    }
    ACLLITE_LOG_INFO("Register face feature extract and reply success");

    return SendMessage(result);
}

AclLiteError FacePostProcess::FaceRecognitionMsgProcess(
    std::shared_ptr<FaceRecognitionInfo> imageHandle) {	
    // Data from camera/video
    if (imageHandle->frame.imageSource == 0) {
        return SendFeature(imageHandle);
    }

    // Data from face register
    return ReplyFeature(imageHandle);
}

AclLiteError FacePostProcess::Process(int msgId, shared_ptr<void> msgData) {
    AclLiteError ret = ACLLITE_OK;
    switch(msgId) {
        case MSG_FACE_RECOGNIZE_DATA:
            ret = FaceRecognitionMsgProcess(
                      static_pointer_cast<FaceRecognitionInfo>(msgData));
            break;
        case MSG_FACE_REG_INVALID:
            ret = ReplyFeature(
                      static_pointer_cast<FaceRecognitionInfo>(msgData));
            break;
        default:
            ACLLITE_LOG_ERROR("Face post process thread receive "
                            "unknow msg %d", msgId);
            break;
    }

    return ret;
}
