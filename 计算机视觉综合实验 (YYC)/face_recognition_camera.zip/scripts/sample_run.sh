#!/bin/bash
ScriptPath="$( cd "$(dirname "$BASH_SOURCE")" ; pwd -P )"
ModelPath="${ScriptPath}/../model"
common_script_dir=${ScriptPath}
conf_file_name="param.conf"
. ${THIRDPART_PATH}/common/sample_common.sh

function main()
{
  echo "[INFO] The sample starts to run"

  running_command="./main"
  data_command=" "

  parse_presenter_view_ip
  if [ $? -ne 0 ];then
    return 1
  fi

  running_presenter
  if [ $? -ne 0 ];then
    return 1
  fi
  presenter_server_pid=`ps -ef | grep "presenter_server\.py" | grep "facial_recognition" | awk -F ' ' '{print $2}'`
  if [[ ${presenter_server_pid}"X" != "X" ]];then
    echo -e "\033[33mNow do presenter server configuration, kill existing presenter process: kill -9 ${presenter_server_pid}.\033[0m"
    kill -9 ${presenter_server_pid}
    if [ $? -ne 0 ];then
      echo "ERROR: kill presenter server process failed."
      return 1
    fi
  else
    echo "[ERROR] presenter server process not exists"
    return 1
  fi
}
main
