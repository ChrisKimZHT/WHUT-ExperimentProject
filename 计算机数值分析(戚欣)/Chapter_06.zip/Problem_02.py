n = int(input("输入方程组阶数n: "))
mat = [[0.0 for col in range(n + 1)] for row in range(n)]
for i in range(n):
    row = input(f"方程{i + 1}: 输入x_1,x_2,...,x_n,b: ").split(" ")
    for j in range(n + 1):
        mat[i][j] = float(row[j])

new_mat = [[0.0 for col in range(n + 1)] for row in range(n)]
for i in range(n):
    for j in range(n + 1):
        if i == j:
            continue
        new_mat[i][j] = mat[i][j] / mat[i][i]

N = int(input("输入迭代次数上限N: "))
eps = float(input("输入误差eps: "))
x = [0.0 for i in range(n)]

for k in range(N):
    flag = True
    for i in range(n):
        tmp = new_mat[i][-1]
        for j in range(n):
            tmp -= x[j] * new_mat[i][j]
        if abs(tmp - x[i]) >= eps:
            flag = False
        x[i] = tmp
    if flag:
        for i in range(n):
            print(f"x_{i + 1} = {round(x[i], 5)}")
        print(f"迭代次数: {k}")
        break
else:
    print("达到迭代次数限制，求解失败")

"""
Test Case:
3
10 -1 -2 7.2
-1 10 -2 8.3
-1 -1 5 4.2
10
0.0001
"""
