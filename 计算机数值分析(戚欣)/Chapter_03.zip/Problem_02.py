import math


def f(x: float) -> float:
    if x == 0.0:
        return 1
    else:
        return math.sin(x) / x


[a, b, eps] = map(lambda t: float(t), input("输入积分起点,终点和精度 a, b, eps: ").split(" "))

h = b - a  # 步长
T_1 = h * (f(a) + f(b)) / 2  # 梯形
T_2 = 0.0
S_1 = 0.0  # 辛普生
S_2 = 0.0
C_1 = 0.0  # 柯特斯
C_2 = 0.0
R_1 = 0.0  # 龙贝格
R_2 = 0.0
k = 1
while k <= 3 or abs(R_2 - R_1) >= eps:
    S = 0.0
    i = a + h / 2
    while i < b:
        S += f(i)
        i += h
    T_2 = T_1 / 2 + h * S / 2
    S_2 = T_2 + (T_2 - T_1) / 3
    if k == 1:
        k += 1
        h /= 2
        T_1 = T_2
        S_1 = S_2
        continue
    C_2 = S_2 + (S_2 - S_1) / 15
    if k == 2:
        k += 1
        h /= 2
        T_1 = T_2
        S_1 = S_2
        C_1 = C_2
        continue
    R_2 = C_2 + (C_2 - C_1) / 63
    if k == 3:
        k += 1
        h /= 2
        T_1 = T_2
        S_1 = S_2
        C_1 = C_2
        R_1 = R_2
        continue

print(f"Integral(f(x), {a}, {b}) = {R_2}")
print(f"Iteration Count: {k}")

"""Test Case 1:
Function:

def f(x: float) -> float:
    if x == 0.0:
        return 1
    else:
        return math.sin(x) / x

Input:
0 1 0.00000001
Output:
0.9460830703872225
4
Accurate:
0.9460831
"""

"""Test Case 2:
Function:

def f(x: float) -> float:
    return 1 / x

Input:
1 2 0.00000001
Output:
0.6931474776448322
4
Accurate:
0.6931471806
"""
