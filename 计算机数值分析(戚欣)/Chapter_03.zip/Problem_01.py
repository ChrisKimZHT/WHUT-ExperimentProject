import math


# 待积函数
def f(x: float) -> float:
    if x == 0.0:
        return 1
    else:
        return math.sin(x) / x


[a, b, eps] = map(lambda t: float(t), input("输入积分起点,终点和精度 a, b, eps: ").split(" "))

init = True
h = b - a  # 步长
T_1 = h * (f(a) + f(b)) / 2  # 旧数据
T_2 = 0.0  # 新数据
iter_cnt = 0  # 迭代次数
while init or abs(T_2 - T_1) >= eps:
    iter_cnt += 1
    if not init:
        h /= 2
        T_1 = T_2
    init = False
    S = 0.0
    i = a + h / 2
    while i < b:
        S += f(i)
        i += h
    T_2 = T_1 / 2 + h * S / 2

print(f"Integral(f(x), {a}, {b}) = {T_2}")
print(f"Iteration Count: {iter_cnt}")

"""Test Case 1:
Function:

def f(x: float) -> float:
    if x == 0.0:
        return 1
    else:
        return math.sin(x) / x

Input:
0 1 0.00000001
Output:
0.9460830688712624
12
Accurate:
0.9460831
"""

"""Test Case 2:
Function:

def f(x: float) -> float:
    return 1 / x

Input:
1 2 0.00000001
Output:
0.6931471814912677
13
Accurate:
0.6931471806
"""
