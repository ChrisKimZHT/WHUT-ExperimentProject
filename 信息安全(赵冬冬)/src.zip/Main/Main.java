package Main;

import java.nio.charset.StandardCharsets;
import java.util.Scanner;
import java.math.BigInteger;

public class Main {
    static Scanner sc = new Scanner(System.in);

    private static Key parseKey() {
        StringBuilder keyString = new StringBuilder();
        while (true) {
            String line = sc.nextLine();
            keyString.append(line);
            keyString.append("\n");
            if (line.contains("END")) {
                break;
            }
        }
        return Key.fromString(keyString.toString());
    }

    private static void generateKey() {
        System.out.print("输入需要生成的密钥长度: ");
        int keyLength = sc.nextInt();
        Key[] keys = RSA.GenerateKeys(keyLength);
        System.out.println(keys[0].toString());
        System.out.println(keys[1].toString());
    }

    private static void encrypt() {
        System.out.println("输入明文：");
        String plainTextString;
        do {
            plainTextString = sc.nextLine();
        } while (plainTextString.isEmpty());
        BigInteger plainTextInt = new BigInteger(plainTextString.getBytes(StandardCharsets.UTF_8));
        System.out.println("输入公钥（完整格式）：");
        Key key = parseKey();
        ;
        BigInteger cipherText = RSA.Encrypt(plainTextInt, key);
        System.out.println("密文：");
        System.out.println(cipherText.toString(16));
    }

    private static void decrypt() {
        System.out.println("输入密文（不可空格）：");
        BigInteger cipherText = new BigInteger(sc.next(), 16);
        System.out.println("输入私钥（完整格式）：");
        Key key = parseKey();
        BigInteger plainTextInt = RSA.Decrypt(cipherText, key);
        String plainTextString = new String(plainTextInt.toByteArray(), StandardCharsets.UTF_8);
        System.out.println("明文：");
        System.out.println(plainTextString);
    }

    public static void main(String[] args) {
        while (true) {
            System.out.println("1. 生成密钥");
            System.out.println("2. 加密");
            System.out.println("3. 解密");
            System.out.println("4. 退出");
            System.out.print("输入选项: ");
            int option = sc.nextInt();
            sc.nextLine();
            switch (option) {
                case 1:
                    generateKey();
                    break;
                case 2:
                    encrypt();
                    break;
                case 3:
                    decrypt();
                    break;
                case 4:
                    return;
                default:
                    System.out.println("输入错误");
            }
        }
    }
}
