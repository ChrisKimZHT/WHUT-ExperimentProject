package Main;

import java.math.BigInteger;

public class RSA {
    public static Key[] GenerateKeys(int bitLength) {
        BigInteger p = BigInteger.probablePrime(bitLength, new java.util.Random());
        BigInteger q = BigInteger.probablePrime(bitLength, new java.util.Random());
        BigInteger n = p.multiply(q); // n = p * q
        BigInteger phi = p.subtract(BigInteger.ONE).multiply(q.subtract(BigInteger.ONE)); // phi = (p - 1) * (q - 1)
        BigInteger e = BigInteger.probablePrime(bitLength, new java.util.Random());
        while (!phi.gcd(e).equals(BigInteger.ONE) && e.compareTo(phi) < 0) {
            e.add(BigInteger.ONE); // e must be coprime with phi and less than phi
        }
        BigInteger d = e.modInverse(phi); // e * d = 1 (mod phi)
        Key[] keys = new Key[2];
        keys[0] = new Key(true, e, n);
        keys[1] = new Key(false, d, n);
        return keys;
    }

    public static BigInteger Encrypt(BigInteger message, Key publicKey) {
        return message.modPow(publicKey.getKey(), publicKey.getMod()); // message ^ key % mod
    }

    public static BigInteger Decrypt(BigInteger encryptedMessage, Key privateKey) {
        return encryptedMessage.modPow(privateKey.getKey(), privateKey.getMod()); // encryptedMessage ^ key % mod
    }
}
