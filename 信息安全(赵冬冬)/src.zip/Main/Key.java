package Main;

import java.math.BigInteger;

public class Key {
    private boolean isPublic;
    private BigInteger key;
    private BigInteger mod;

    public Key() {
        this.isPublic = true;
        this.key = BigInteger.ZERO;
        this.mod = BigInteger.ZERO;
    }

    public Key(boolean isPublic, BigInteger key, BigInteger mod) {
        this.isPublic = isPublic;
        this.key = key;
        this.mod = mod;
    }

    public boolean isPublic() {
        return isPublic;
    }

    public void setType(boolean isPublic) {
        this.isPublic = isPublic;
    }

    public BigInteger getKey() {
        return key;
    }

    public void setKey(BigInteger key) {
        this.key = key;
    }

    public BigInteger getMod() {
        return mod;
    }

    public void setMod(BigInteger mod) {
        this.mod = mod;
    }

    public String toString() {
        StringBuilder res = new StringBuilder("-----BEGIN RSA " + (isPublic ? "PUBLIC" : "PRIVATE") + " KEY-----\n");
        for (String line : key.toString(16).split("(?<=\\G.{32})")) {
            res.append(line).append("\n");
        }
        res.append("\n");
        for (String line : mod.toString(16).split("(?<=\\G.{32})")) {
            res.append(line).append("\n");
        }
        res.append("-----END RSA ").append(isPublic ? "PUBLIC" : "PRIVATE").append(" KEY-----\n");
        return res.toString();
    }

    public static Key fromString(String key) {
        String[] lines = key.trim().split("\n");
        boolean isPublic = lines[0].contains("PUBLIC");
        StringBuilder keyString = new StringBuilder();
        int i;
        for (i = 1; i < lines.length; i++) {
            if (lines[i].isEmpty()) {
                break;
            }
            keyString.append(lines[i]);
        }
        i++;
        StringBuilder modString = new StringBuilder();
        for (; i < lines.length; i++) {
            if (lines[i].contains("END")) {
                break;
            }
            modString.append(lines[i]);
        }
        BigInteger keyInt = new BigInteger(keyString.toString(), 16);
        BigInteger modInt = new BigInteger(modString.toString(), 16);
        return new Key(isPublic, keyInt, modInt);
    }
}