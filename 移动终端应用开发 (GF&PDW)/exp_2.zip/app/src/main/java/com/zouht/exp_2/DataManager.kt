package com.zouht.exp_2

import android.annotation.SuppressLint
import android.content.Context

class DataManager(private val context: Context) {
    private val dbHelper = DBHelper(context)

    fun insertUser(user: HashMap<String, Any>) {
        val db = dbHelper.writableDatabase
        db.execSQL(
            "INSERT INTO user (username, password, tel, email, gender) VALUES (?, ?, ?, ?, ?)",
            arrayOf(user["username"], user["password"], user["tel"], user["email"], user["gender"])
        )
        db.close()
    }

    @SuppressLint("Range")
    fun listUser(): List<HashMap<String, Any>> {
        val db = dbHelper.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM user", null)
        val list = mutableListOf<HashMap<String, Any>>()
        while (cursor.moveToNext()) {
            val map = HashMap<String, Any>()
            map["id"] = cursor.getInt(cursor.getColumnIndex("id"))
            map["username"] = cursor.getString(cursor.getColumnIndex("username"))
            map["password"] = cursor.getString(cursor.getColumnIndex("password"))
            map["tel"] = cursor.getString(cursor.getColumnIndex("tel"))
            map["email"] = cursor.getString(cursor.getColumnIndex("email"))
            map["gender"] = cursor.getInt(cursor.getColumnIndex("gender")) == 1
            list.add(map)
        }
        cursor.close()
        db.close()
        return list
    }

    @SuppressLint("Range")
    fun getUser(id: Int): HashMap<String, Any> {
        val db = dbHelper.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM user WHERE id = ?", arrayOf(id.toString()))
        cursor.moveToNext()
        val map = HashMap<String, Any>()
        map["id"] = cursor.getInt(cursor.getColumnIndex("id"))
        map["username"] = cursor.getString(cursor.getColumnIndex("username"))
        map["password"] = cursor.getString(cursor.getColumnIndex("password"))
        map["tel"] = cursor.getString(cursor.getColumnIndex("tel"))
        map["email"] = cursor.getString(cursor.getColumnIndex("email"))
        map["gender"] = cursor.getInt(cursor.getColumnIndex("gender")) == 1
        cursor.close()
        db.close()
        return map
    }

    fun updateUser(user: HashMap<String, Any>, id: Int) {
        val db = dbHelper.writableDatabase
        db.execSQL(
            "UPDATE user SET username = ?, password = ?, tel = ?, email = ?, gender = ? WHERE id = ?",
            arrayOf(
                user["username"], user["password"], user["tel"], user["email"], user["gender"], id
            )
        )
        db.close()
    }

    fun deleteUser(id: Int) {
        val db = dbHelper.writableDatabase
        db.execSQL("DELETE FROM user WHERE id = ?", arrayOf(id))
        db.close()
    }
}