package com.zouht.exp_2

import android.os.Bundle
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.RadioButton
import android.widget.Spinner
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton

class MainActivity : AppCompatActivity() {
    private val dataManager = DataManager(this)

    private fun initSpinner() {
        refreshSpinner()
    }

    private fun initClickListener() {
        findViewById<AppCompatButton>(R.id.createButton).setOnClickListener { onCreateButtonClick() }
        findViewById<AppCompatButton>(R.id.saveButton).setOnClickListener { onUpdateButtonClick() }
        findViewById<AppCompatButton>(R.id.deleteButton).setOnClickListener { onDeleteButtonClick() }
        findViewById<AppCompatButton>(R.id.clearButton).setOnClickListener { onClearButtonClick() }
        findViewById<Spinner>(R.id.userListSpinner).onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: android.view.View?,
                    position: Int,
                    id: Long
                ) {
                    onUserListSpinnerSelected()
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {
                    clearInput()
                }
            }
    }

    private fun initGender() {
        findViewById<RadioButton>(R.id.maleRadioButton).isChecked = true
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initSpinner()
        initClickListener()
        initGender()
    }

    private fun getInput(): HashMap<String, Any> {
        val username = findViewById<EditText>(R.id.usernameEditText).text.toString()
        val password = findViewById<EditText>(R.id.passwordEditText).text.toString()
        val tel = findViewById<EditText>(R.id.telEditText).text.toString()
        val email = findViewById<EditText>(R.id.emailEditText).text.toString()
        // true for male, false for female
        val gender = findViewById<RadioButton>(R.id.maleRadioButton).isChecked
        return hashMapOf(
            "username" to username,
            "password" to password,
            "tel" to tel,
            "email" to email,
            "gender" to gender
        )
    }

    private fun clearInput() {
        findViewById<EditText>(R.id.usernameEditText).setText("")
        findViewById<EditText>(R.id.passwordEditText).setText("")
        findViewById<EditText>(R.id.telEditText).setText("")
        findViewById<EditText>(R.id.emailEditText).setText("")
        findViewById<RadioButton>(R.id.maleRadioButton).isChecked = true
    }

    private fun refreshSpinner(id: Int = -1) {
        val spinner = findViewById<Spinner>(R.id.userListSpinner)
        val userList = dataManager.listUser()
        val userNameList = userList.map { "${it["id"]} - ${it["username"]}" }
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, userNameList)
        spinner.adapter = adapter
        if (id != -1) {
            spinner.setSelection(userNameList.indexOfFirst { it.startsWith("$id -") })
        }
    }

    private fun refreshInput(id: Int) {
        val user = dataManager.getUser(id)
        findViewById<EditText>(R.id.usernameEditText).setText(user["username"].toString())
        findViewById<EditText>(R.id.passwordEditText).setText(user["password"].toString())
        findViewById<EditText>(R.id.telEditText).setText(user["tel"].toString())
        findViewById<EditText>(R.id.emailEditText).setText(user["email"].toString())
        if (user["gender"] as Boolean) {
            findViewById<RadioButton>(R.id.maleRadioButton).isChecked = true
            findViewById<RadioButton>(R.id.femaleRadioButton).isChecked = false
        } else {
            findViewById<RadioButton>(R.id.maleRadioButton).isChecked = false
            findViewById<RadioButton>(R.id.femaleRadioButton).isChecked = true
        }
    }

    private fun onCreateButtonClick() {
        val input = getInput()
        if (!validateInput()) {
            val builder = AlertDialog.Builder(this)
            builder.setTitle("错误")
            builder.setMessage("请填写完整信息")
            builder.setPositiveButton("确定") { dialog, _ -> dialog.dismiss() }
            builder.show()
            return
        }
        dataManager.insertUser(input)
        clearInput()
        refreshSpinner()
    }

    private fun onUpdateButtonClick() {
        val id = findViewById<Spinner>(R.id.userListSpinner).selectedItem.toString()
            .split(" - ")[0].toInt()
        val input = getInput()
        dataManager.updateUser(input, id)
        clearInput()
        refreshSpinner(id)
    }

    private fun onDeleteButtonClick() {
        val id = findViewById<Spinner>(R.id.userListSpinner).selectedItem.toString()
            .split(" - ")[0].toInt()
        dataManager.deleteUser(id)
        clearInput()
        refreshSpinner()
    }

    private fun onClearButtonClick() {
        clearInput()
    }

    private fun validateInput(): Boolean {
        val user = getInput()
        return user["username"].toString().isNotEmpty() &&
                user["password"].toString().isNotEmpty() &&
                user["tel"].toString().isNotEmpty() &&
                user["email"].toString().isNotEmpty()
    }

    private fun onUserListSpinnerSelected() {
        val id = findViewById<Spinner>(R.id.userListSpinner).selectedItem.toString()
            .split(" - ")[0].toInt()
        refreshInput(id)
    }
}