package com.zouht.exp_1

import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.AppCompatButton

class MainActivity : AppCompatActivity() {
    private val genderList = arrayOf("男", "女")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // init gender spinner
        val spinner = findViewById<Spinner>(R.id.genderSpinner)
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, genderList)
        spinner.adapter = adapter

        // set button click listener
        findViewById<AppCompatButton>(R.id.saveButton).setOnClickListener { onSaveButtonClick() }
        findViewById<AppCompatButton>(R.id.loadButton).setOnClickListener { onLoadButtonClick() }
        findViewById<AppCompatButton>(R.id.clearButton).setOnClickListener { onClearButtonClick() }
    }

    override fun onPause() {
        onSaveButtonClick()
        super.onPause()
    }

    private fun validateInput(): Boolean {
        // acquire user input
        val name = findViewById<EditText>(R.id.userNameEditText).text.toString()
        val password = findViewById<EditText>(R.id.passwordEditText).text.toString()
        val phone = findViewById<EditText>(R.id.phoneEditText).text.toString()
        val email = findViewById<EditText>(R.id.emailEditText).text.toString()

        // empty check
        if (name.isEmpty() || password.isEmpty() || phone.isEmpty() || email.isEmpty()) {
            val builder = AlertDialog.Builder(this)
            builder.setTitle("保存失败")
            builder.setMessage("请填写所有信息")
            builder.setPositiveButton("关闭") { dialog, _ ->
                dialog.dismiss()
            }
            val dialog = builder.create()
            dialog.show()
            return false
        }
        // phone number check
        if (!phone.matches(Regex("^1[3-9]\\d{9}$"))) {
            val builder = AlertDialog.Builder(this)
            builder.setTitle("保存失败")
            builder.setMessage("电话号码格式错误")
            builder.setPositiveButton("关闭") { dialog, _ ->
                dialog.dismiss()
            }
            val dialog = builder.create()
            dialog.show()
            return false
        }
        // email check
        if (!email.matches(Regex("^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\\.[a-zA-Z0-9_-]+)+$"))) {
            val builder = AlertDialog.Builder(this)
            builder.setTitle("保存失败")
            builder.setMessage("邮箱格式错误")
            builder.setPositiveButton("关闭") { dialog, _ ->
                dialog.dismiss()
            }
            val dialog = builder.create()
            dialog.show()
            return false
        }
        return true
    }

    private fun onSaveButtonClick() {
        // validate user input
        if (!validateInput()) {
            return
        }

        // acquire user input
        val name = findViewById<EditText>(R.id.userNameEditText).text.toString()
        val password = findViewById<EditText>(R.id.passwordEditText).text.toString()
        val phone = findViewById<EditText>(R.id.phoneEditText).text.toString()
        val email = findViewById<EditText>(R.id.emailEditText).text.toString()
        val gender = findViewById<Spinner>(R.id.genderSpinner).selectedItem.toString()

        // save to shared preferences
        val sharedPreferences: SharedPreferences = getSharedPreferences("userInfo", MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putString("name", name)
        editor.putString("password", password)
        editor.putString("phone", phone)
        editor.putString("email", email)
        editor.putString("gender", gender)
        editor.apply()
    }

    private fun onLoadButtonClick() {
        // load from shared preferences
        val sharedPreferences: SharedPreferences = getSharedPreferences("userInfo", MODE_PRIVATE)
        val name = sharedPreferences.getString("name", "")
        val password = sharedPreferences.getString("password", "")
        val phone = sharedPreferences.getString("phone", "")
        val email = sharedPreferences.getString("email", "")
        val gender = sharedPreferences.getString("gender", "")

        // set user input
        findViewById<EditText>(R.id.userNameEditText).setText(name)
        findViewById<EditText>(R.id.passwordEditText).setText(password)
        findViewById<EditText>(R.id.phoneEditText).setText(phone)
        findViewById<EditText>(R.id.emailEditText).setText(email)
        findViewById<Spinner>(R.id.genderSpinner).setSelection(genderList.indexOf(gender))
    }

    private fun onClearButtonClick() {
        // clear user input
        findViewById<EditText>(R.id.userNameEditText).setText("")
        findViewById<EditText>(R.id.passwordEditText).setText("")
        findViewById<EditText>(R.id.phoneEditText).setText("")
        findViewById<EditText>(R.id.emailEditText).setText("")
        findViewById<Spinner>(R.id.genderSpinner).setSelection(0)
    }
}