//
//  main.m
//  ChrisKim Experiment
//
//  Created by LAB14 on 2024/4/27.
//  Copyright © 2024 LAB14. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
