//
//  ViewController.m
//  ChrisKim Experiment
//
//  Created by LAB14 on 2024/4/27.
//  Copyright © 2024 LAB14. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (IBAction)click:(id)sender {
    /*
    UIAlertController *alertCtrl = [UIAlertController alertControllerWithTitle:@"提示" message:@"点击按钮" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {}];
    [alertCtrl addAction:cancelAction];
    [alertCtrl addAction:okAction];
    [self presentViewController:alertCtrl animated:YES completion:nil];
    _label.text = @"Buttone被点击了";
     */
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    [userDefault setObject:@"chriskim" forKey:@"username"];
    [userDefault setObject:@"123123" forKey:@"password"];
    if ([_username.text isEqualToString:[userDefault stringForKey:@"username"]] &&
        [_password.text isEqualToString:[userDefault stringForKey:@"password"]]) {
        _label.text = @"用户名和密码正确";
    } else {
        _label.text = @"用户名或密码错误";
    }
    
    NSURL *url = [NSURL URLWithString:@"http://t.weather.sojson.com/api/weather/city/101200101"];
    NSData *data = [NSData dataWithContentsOfURL:url];
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
    NSDictionary *cityInfo = dic[@"cityInfo"];
    NSDictionary *weatherInfo = dic[@"data"];
    _detail.text = [NSString stringWithFormat:@"%@ %@ %@ 的\n湿度为 %@\n空气质量为 %@\n当前温度为 %@ 摄氏度", [cityInfo objectForKey:@"parent"], [cityInfo objectForKey:@"city"], [dic objectForKey:@"time"], [weatherInfo objectForKey:@"shidu"], [weatherInfo objectForKey:@"quality"], [weatherInfo objectForKey:@"wendu"]];
//    NSLog(@"weatherInfo 字典里面的内容为--)%@", dic);
}

- (IBAction)add:(id)sender {
    if ([_number1.text isEqualToString:@""] || [_number2.text isEqualToString:@""]) {
        return;
    }
    _oper.text = @"+";
    _res.text = [NSString stringWithFormat:@"= %f", [_number1.text floatValue] + [_number2.text floatValue]];
}

- (IBAction)sub:(id)sender {
    if ([_number1.text isEqualToString:@""] || [_number2.text isEqualToString:@""]) {
        return;
    }
    _oper.text = @"-";
    _res.text = [NSString stringWithFormat:@"= %f", [_number1.text floatValue] - [_number2.text floatValue]];
}

- (IBAction)mul:(id)sender {
    if ([_number1.text isEqualToString:@""] || [_number2.text isEqualToString:@""]) {
        return;
    }
    _oper.text = @"*";
    _res.text = [NSString stringWithFormat:@"= %f", [_number1.text floatValue] * [_number2.text floatValue]];
}

- (IBAction)div:(id)sender {
    if ([_number1.text isEqualToString:@""] || [_number2.text isEqualToString:@""]) {
        return;
    }
    _oper.text = @"/";
    _res.text = [NSString stringWithFormat:@"= %f", [_number1.text floatValue] / [_number2.text floatValue]];
}


@end
