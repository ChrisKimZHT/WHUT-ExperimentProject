//
//  ViewController.h
//  ChrisKim Experiment
//
//  Created by LAB14 on 2024/4/27.
//  Copyright © 2024 LAB14. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (strong, nonatomic) IBOutlet UILabel *label;

@property (strong, nonatomic) IBOutlet UITextField *username;
@property (strong, nonatomic) IBOutlet UITextField *password;

@property (strong, nonatomic) IBOutlet UITextView *detail;

@property (strong, nonatomic) IBOutlet UITextField *number1;
@property (strong, nonatomic) IBOutlet UITextField *number2;
@property (strong, nonatomic) IBOutlet UILabel *oper;
@property (strong, nonatomic) IBOutlet UILabel *res;

@end

