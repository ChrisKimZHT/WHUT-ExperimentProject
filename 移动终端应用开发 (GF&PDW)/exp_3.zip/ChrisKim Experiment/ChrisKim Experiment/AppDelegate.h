//
//  AppDelegate.h
//  ChrisKim Experiment
//
//  Created by LAB14 on 2024/4/27.
//  Copyright © 2024 LAB14. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

