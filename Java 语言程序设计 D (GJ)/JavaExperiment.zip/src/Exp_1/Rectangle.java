package Exp_1;

public class Rectangle extends Shape {
    private double length, width;

    Rectangle(double length, double width) {
        this.length = length;
        this.width = width;
    }

    public double getLength() {
        return this.length;
    }

    public void setLength(double length) {
        if (length > 0) {
            this.length = length;
        } else {
            System.out.println("Invalid value for length!");
        }
    }

    public double getWidth() {
        return this.width;
    }

    public void setWidth(double width) {
        if (width > 0) {
            this.width = width;
        } else {
            System.out.println("Invalid value for width!");
        }
    }

    @Override
    public double calcPerimeter() {
        return (this.length + this.width) * 2;
    }

    @Override
    public double calcArea() {
        return this.length * this.width;
    }

    public String toString() {
        return "Rectangle: length = " + this.length + ", width = " + this.width;
    }
}
