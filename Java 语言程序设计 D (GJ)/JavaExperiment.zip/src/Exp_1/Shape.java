package Exp_1;

public class Shape {
    public double calcPerimeter() {
        return 0;
    }

    public double calcArea() {
        return 0;
    }
}
