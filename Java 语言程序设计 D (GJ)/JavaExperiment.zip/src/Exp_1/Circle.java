package Exp_1;

public class Circle extends Shape {
    private double radius;

    Circle(double radius) {
        this.radius = radius;
    }

    public double getRadius() {
        return this.radius;
    }

    public void setRadius(double radius) {
        if (radius > 0) {
            this.radius = radius;
        } else {
            System.out.println("Invalid value for radius!");
        }
    }

    @Override
    public double calcPerimeter() {
        return 2 * Math.PI * this.radius;
    }

    @Override
    public double calcArea() {
        return Math.PI * this.radius * this.radius;
    }

    public String toString() {
        return "Circle: radius = " + this.radius;
    }
}
