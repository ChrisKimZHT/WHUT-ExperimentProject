package Exp_1;

public class Triangle extends Shape {
    private double a, b, c;

    Triangle(double a, double b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    public double getA() {
        return a;
    }

    public void setA(double a) {
        if (a > 0) {
            this.a = a;
        } else {
            System.out.println("Invalid value for a!");
        }
    }

    public double getB() {
        return b;
    }

    public void setB(double b) {
        if (b > 0) {
            this.b = b;
        } else {
            System.out.println("Invalid value for b!");
        }

    }

    public double getC() {
        return c;
    }

    public void setC(double c) {
        if (c > 0) {
            this.c = c;
        } else {
            System.out.println("Invalid value for c!");
        }
    }

    @Override
    public double calcPerimeter() {
        if (a + b <= c || a + c <= b || b + c <= a) {
            System.out.println("Invalid value for a, b, c!");
            return 0;
        }
        return a + b + c;
    }

    @Override
    public double calcArea() {
        if (a + b <= c || a + c <= b || b + c <= a) {
            System.out.println("Invalid value for a, b, c!");
            return 0;
        }
        double p = calcPerimeter() / 2;
        return Math.sqrt(p * (p - a) * (p - b) * (p - c));
    }

    public String toString() {
        return "Triangle: a = " + a + ", b = " + b + ", c = " + c;
    }
}
