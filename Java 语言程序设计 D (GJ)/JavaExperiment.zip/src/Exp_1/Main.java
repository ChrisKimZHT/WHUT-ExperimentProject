package Exp_1;

import java.util.Scanner;

public class Main {
    private final Scanner scanner = new Scanner(System.in);
    private final Shape[] shapes = new Shape[2];

    private void setTriangle(int x) {
        System.out.print("请输入三角形的三条边: ");
        double a = scanner.nextDouble();
        double b = scanner.nextDouble();
        double c = scanner.nextDouble();
        shapes[x] = new Triangle(a, b, c);
    }

    private void setRectangle(int x) {
        System.out.print("请输入长方形的长和宽: ");
        double a = scanner.nextDouble();
        double b = scanner.nextDouble();
        shapes[x] = new Rectangle(a, b);
    }

    private void setCirle(int x) {
        System.out.print("请输入圆的半径: ");
        double a = scanner.nextDouble();
        shapes[x] = new Circle(a);
    }

    private void initShape() {
        System.out.println("1. Circle");
        System.out.println("2. Rectangle");
        System.out.println("3. Triangle");
        int[] types = new int[2];
        System.out.print("请输入第一个图形的类型: ");
        types[0] = scanner.nextInt();
        System.out.print("请输入第二个图形的类型: ");
        types[1] = scanner.nextInt();
        for (int i = 0; i < 2; i++) {
            switch (types[i]) {
                case 1:
                    setCirle(i);
                    break;
                case 2:
                    setRectangle(i);
                    break;
                case 3:
                    setTriangle(i);
                    break;
                default:
                    System.out.println("无效的类型!");
            }
        }
    }

    private void showShape() {
        System.out.print("请输入要查看的图形(0/1): ");
        int op = scanner.nextInt();
        if (op == 0 || op == 1) {
            System.out.println(shapes[op]);
            System.out.println("周长: " + shapes[op].calcPerimeter());
            System.out.println("面积: " + shapes[op].calcArea());
        } else {
            System.out.println("无效的操作!");
        }
    }

    private void compareShape() {
        System.out.print("请输入要比较的属性(1. 周长 2. 面积): ");
        int attr = scanner.nextInt();
        if (attr == 1) {
            System.out.println("周长比较结果: ");
            System.out.print(shapes[0]);
            switch (cmpPerimeter(shapes[0], shapes[1])) {
                case 0:
                    System.out.print(" = ");
                    break;
                case 1:
                    System.out.print(" > ");
                    break;
                case -1:
                    System.out.print(" < ");
                    break;
            }
            System.out.println(shapes[1]);
        } else if (attr == 2) {
            System.out.println("面积比较结果: ");
            System.out.print(shapes[0]);
            switch (cmpArea(shapes[0], shapes[1])) {
                case 0:
                    System.out.print(" = ");
                    break;
                case 1:
                    System.out.print(" > ");
                    break;
                case -1:
                    System.out.print(" < ");
                    break;
            }
            System.out.println(shapes[1]);
        } else {
            System.out.println("无效的属性!");
        }
    }

    private void program() {
        while (true) {
            System.out.println("1. 初始化图形");
            System.out.println("2. 查看图形");
            System.out.println("3. 比较图形");
            System.out.println("4. 退出");
            System.out.print("请输入操作: ");
            int op = scanner.nextInt();
            switch (op) {
                case 1:
                    initShape();
                    break;
                case 2:
                    showShape();
                    break;
                case 3:
                    compareShape();
                    break;
                case 4:
                    System.exit(0);
                default:
                    System.out.println("无效的操作!");
            }
        }
    }

    public static void main(String[] args) {
        new Main().program();
    }

    public static int cmpPerimeter(Shape a, Shape b) {
        double pereA = a.calcPerimeter();
        double pereB = b.calcPerimeter();
        return Double.compare(pereA, pereB);
    }

    public static int cmpArea(Shape a, Shape b) {
        double areaA = a.calcArea();
        double areaB = b.calcArea();
        return Double.compare(areaA, areaB);
    }
}
