package Exp_2;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class Main extends JFrame {
    public static void main(String[] args) {
        JFrame frame = new JFrame("和与平均值");
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));

        JTextField inputField = new JTextField(30);
        JTextField sumField = new JTextField(30);
        JTextField averageField = new JTextField(30);
        JLabel sumLabel = new JLabel("合计:");
        JLabel averageLabel = new JLabel("均值:");

        panel.add(inputField);
        panel.add(Box.createVerticalStrut(20));
        panel.add(sumLabel);
        panel.add(sumField);
        panel.add(Box.createVerticalStrut(20));
        panel.add(averageLabel);
        panel.add(averageField);

        inputField.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                calculate();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                calculate();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                calculate();
            }

            private void calculate() {
                String input = inputField.getText();
                String[] numbers = input.split("\\s+");
                double sum = 0;
                for (String number : numbers) {
                    try {
                        sum += Double.parseDouble(number);
                    } catch (NumberFormatException ex) {
                        sumField.setText("输入异常");
                        averageField.setText("输入异常");
                        return;
                    }
                }
                double average = sum / numbers.length;
                sumField.setText(String.valueOf(sum));
                averageField.setText(String.valueOf(average));
            }
        });

        frame.setLocation(500, 300);
        frame.add(panel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}


