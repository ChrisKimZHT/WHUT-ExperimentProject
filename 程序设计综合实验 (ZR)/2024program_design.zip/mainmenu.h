#ifndef MAINMENU_H
#define MAINMENU_H

#include <iostream>
#include <vector>
#include"admin.h"
#include<mainmenu.c>
using namespace std;

// Function prototypes
void admin();
void user();
void secure(string op);

#endif // MAINMENU_H
