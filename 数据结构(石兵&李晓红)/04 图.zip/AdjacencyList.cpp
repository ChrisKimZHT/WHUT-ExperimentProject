//
// Created by ChrisKim on 2022/12/2.
//

#include "AdjacencyList.h"
#include <iostream>

AdjacencyList::AdjacencyList(std::vector<std::pair<int, int>> &edge_data)
{
    for (const auto &edge: edge_data)
    {
        int start, end, weight;
        start = edge.first;
        end = edge.second;
        if (start >= MAX_VERTEX_CNT)
        {
            std::cout << "ERROR: Vertex ID Too Lage" << std::endl;
            return;
        }
        edges[start].emplace_back(end);
        vertex_set.insert(start);
        vertex_set.insert(end);
    }
    vertex_cnt = (int) vertex_set.size();
    edge_cnt = (int) edge_data.size();
    calc_degree_in();
}

void AdjacencyList::display()
{
    for (int v: vertex_set)
        for (auto p: edges[v])
            std::cout << v << "------>" << p << std::endl;
}

void AdjacencyList::calc_degree_in()
{
    degree_in.resize(MAX_VERTEX_CNT, 0); // init to 0
    for (int v: vertex_set)
        for (auto p: edges[v])
            degree_in[p]++;
}

std::vector<int> AdjacencyList::topo_order()
{
    std::vector<int> degree_in_cpy(degree_in); // copy data
    std::vector<int> res;
    bool flag = false; // degree_in not zero
    do
    {
        flag = false;
        for (int v: vertex_set)
        {
            if (degree_in_cpy[v] > 0)
            {
                flag = true;
                continue;
            }
            else if (degree_in_cpy[v] == 0)
            {
                res.push_back(v);
                for (auto p: edges[v])
                    degree_in_cpy[p]--;
                degree_in_cpy[v] = -1;
            }
        }
    } while (flag);
    return res;
}




