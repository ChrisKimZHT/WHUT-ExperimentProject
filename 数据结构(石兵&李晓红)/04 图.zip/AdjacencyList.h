//
// Created by ChrisKim on 2022/12/2.
//

#ifndef EXPERIMENT_DSA_04_ADJACENCYLIST_H
#define EXPERIMENT_DSA_04_ADJACENCYLIST_H

#include <vector>
#include <utility>
#include <set>

const int MAX_VERTEX_CNT = 1000;


class AdjacencyList
{
private:
    int vertex_cnt;
    int edge_cnt;
    std::set<int> vertex_set;
    std::vector<int> edges[MAX_VERTEX_CNT];
    std::vector<int> degree_in;
    void calc_degree_in();

public:
    explicit AdjacencyList(std::vector<std::pair<int, int>> &);
    void display();
    std::vector<int> topo_order();
};


#endif //EXPERIMENT_DSA_04_ADJACENCYLIST_H
