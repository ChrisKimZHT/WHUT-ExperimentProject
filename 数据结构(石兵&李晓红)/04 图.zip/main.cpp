#include <iostream>
#include <iomanip>
#include <vector>
#include <string>
#include "Course.h"
#include "AdjacencyList.h"

using namespace std;

void list_course();
void add_course();
void del_course();
void edit_course();
void calc_plan();
void insert_test_case();
Course find_course(int id);

int main()
{
    cout << "����y��ʹ�ò���������ʼ��: ";
    string s;
    cin >> s;
    if (s == "y" || s == "Y")
        insert_test_case();
    while (true)
    {
        cout << "====��ѧ�ƻ�����ϵͳ====" << endl
             << "1. �γ��б�" << endl
             << "2. ���ӿγ�" << endl
             << "3. ɾ���γ�" << endl
             << "4. �޸Ŀγ�" << endl
             << "5. ���Ž�ѧ" << endl
             << "0. �˳�" << endl
             << "ѡ����: ";
        int choice;
        cin >> choice;
        switch (choice)
        {
            case 0:
                return 0;
            case 1:
                list_course();
                break;
            case 2:
                add_course();
                break;
            case 3:
                del_course();
                break;
            case 4:
                edit_course();
                break;
            case 5:
                calc_plan();
                break;
            default:
                cout << "ѡ����������ԡ�" << endl;
        }
    }
}

// ����γ��б�
vector<Course> course_list;

void list_course()
{
    cout << "========�γ��б�========" << endl;
    cout << left << setw(6) << "ID"
         << left << setw(20) << "Name"
         << left << setw(8) << "Points"
         << left << "Pre Courses" << endl;
    for (const Course &course: course_list)
    {
        cout << left << setw(6) << course.id
             << left << setw(20) << course.name
             << left << setw(8) << fixed << setprecision(2) << course.points;
        cout << '[';
        for (int i = 0; i < course.pre_course.size(); i++)
        {
            if (i)
                cout << ", ";
            cout << course.pre_course[i];
        }
        cout << ']' << endl;
    }
}

void add_course()
{
    cout << "========���ӿγ�========" << endl;
    cout << "����γ̱��: ";
    int id;
    cin >> id;
    for (const Course &course: course_list)
    {
        if (course.id == id)
        {
            cout << "����ظ�������ʧ��" << endl;
            return;
        }
    }
    cout << "����γ�����: ";
    string name;
    cin >> name;
    cout << "����γ�ѧ��: ";
    double points;
    cin >> points;
    Course new_course(id, name, points);
    cout << "�������޿γ���Ŀ: ";
    int pre_course_cnt;
    cin >> pre_course_cnt;
    for (int i = 1; i <= pre_course_cnt; i++)
    {
        cout << "�����" << i << "�����޿γ̱��: ";
        int pre_course;
        cin >> pre_course;
        new_course.pre_course.push_back(pre_course);
    }
    course_list.push_back(new_course);
    cout << "�������" << endl;
}

void del_course()
{
    cout << "========ɾ���γ�========" << endl;
    cout << "����Ҫɾ���Ŀγ̱��: ";
    int id;
    cin >> id;
    for (int i = 0; i < course_list.size(); i++)
    {
        if (course_list[i].id == id)
        {
            course_list.erase(course_list.begin() + i);
            cout << "ɾ���ɹ�" << endl;
            return;
        }
    }
    cout << "δ�ҵ���ɾ���Ŀγ�" << endl;
}

void edit_course()
{
    cout << "========�޸Ŀγ�========" << endl;
    cout << "����Ҫ�޸ĵĿγ̱��: ";
    int id;
    cin >> id;
    for (auto &i: course_list)
    {
        if (i.id == id)
        {
            cout << "����γ�����: ";
            string name;
            cin >> name;
            cout << "����γ�ѧ��: ";
            double points;
            cin >> points;
            Course new_course(id, name, points);
            cout << "�������޿γ���Ŀ: ";
            int pre_course_cnt;
            cin >> pre_course_cnt;
            for (int j = 1; j <= pre_course_cnt; j++)
            {
                cout << "�����" << j << "�����޿γ̱��: ";
                int pre_course;
                cin >> pre_course;
                new_course.pre_course.push_back(pre_course);
            }
            i = new_course;
            cout << "�޸����" << endl;
            return;
        }
    }
    cout << "δ�ҵ����޸ĵĿγ�" << endl;
}

void calc_plan()
{
    cout << "========���Ž�ѧ========" << endl;
    vector<pair<int, int>> data;
    for (const Course &course: course_list)
        for (int pre: course.pre_course)
            data.emplace_back(pre, course.id);
    AdjacencyList graph(data);
    vector<int> topo_ans = graph.topo_order();
    double sum_points = 0;
    int term = 1;
    cout << left << setw(6) << "ID"
         << left << setw(20) << "Name"
         << left << setw(8) << "Points" << endl;
    cout << "��" << term << "ѧ��" << endl;
    for (int item: topo_ans)
    {
        Course course = find_course(item);
        if (sum_points + course.points <= 10.0)
        {
            sum_points += course.points;
            cout << left << setw(6) << course.id
                 << left << setw(20) << course.name
                 << left << setw(8) << fixed << setprecision(2) << course.points << endl;
        }
        else if (course.points <= 10.0)
        {
            term++;
            sum_points = course.points;
            cout << "��" << term << "ѧ��" << endl;
            cout << left << setw(6) << course.id
                 << left << setw(20) << course.name
                 << left << setw(8) << fixed << setprecision(2) << course.points << endl;
        }
        else
        {
            cout << "�γ�ѧ�ִ���10�޷�����" << endl;
        }
    }
    if (term > 6)
    {
        cout << "����ѧ��" << endl;
    }
}

Course find_course(int id)
{
    for (const Course &course: course_list)
        if (course.id == id)
            return course;
    return {};
}

// ��ʼ��������������
void insert_test_case(){string s = "cxsjjj";Course a(1, s, 2.0);s = "lssx";Course b(2, s, 3.0);b.pre_course.push_back(1);s = "sjjg";Course c(3, s, 4.0);c.pre_course.push_back(1);c.pre_course.push_back(2);s = "hbyy";Course d(4, s, 3.0);d.pre_course.push_back(1);s = "cxssyfx";Course e(5, s, 2.0);e.pre_course.push_back(3);e.pre_course.push_back(4);s = "jsjyl";Course f(6, s, 3.0);f.pre_course.push_back(11);s = "byyl";Course g(7, s, 4.0);g.pre_course.push_back(3);g.pre_course.push_back(5);s = "czxt";Course h(8, s, 4.0);h.pre_course.push_back(3);h.pre_course.push_back(6);s = "gdss";Course i(9, s, 7.0);s = "xxds";Course j(10, s, 5.0);j.pre_course.push_back(9);s = "ptwl";Course k(11, s, 2.0);k.pre_course.push_back(9);s = "szfx";Course l(12, s, 3.0);l.pre_course.push_back(1);l.pre_course.push_back(9);l.pre_course.push_back(10);s = "rjgc";Course m(13, s, 3.0);m.pre_course.push_back(5);s = "sjkyl";Course n(14, s, 3.0);n.pre_course.push_back(7);n.pre_course.push_back(8);course_list.push_back(a);course_list.push_back(b);course_list.push_back(c);course_list.push_back(d);course_list.push_back(e);course_list.push_back(f);course_list.push_back(g);course_list.push_back(h);course_list.push_back(i);course_list.push_back(j);course_list.push_back(k);course_list.push_back(l);course_list.push_back(m);course_list.push_back(n);}