//
// Created by ChrisKim on 2022/12/2.
//

#ifndef EXPERIMENT_DSA_04_COURSE_H
#define EXPERIMENT_DSA_04_COURSE_H

#include <string>
#include <vector>

struct Course
{
    int id;
    std::string name;
    double points;
    std::vector<int> pre_course;

    Course()
    {
        id = -1;
        name = "NULL";
        points = 0.0;
    }

    Course(int id, std::string &name, double points)
    {
        this->id = id;
        this->name = name;
        this->points = points;
    }
};


#endif //EXPERIMENT_DSA_04_COURSE_H
