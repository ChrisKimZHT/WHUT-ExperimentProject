#include <bits/stdc++.h>

using namespace std;

const map<string, int> operator_to_id{
    {"+", 13},
    {"-", 14},
    {"*", 15},
    {"/", 16},
    {";", 17},
    {"=", 18},
    {"<", 19},
    {"<>", 20},
    {"<=", 21},
    {">", 22},
    {">=", 23},
    {"(", 24},
    {")", 25},
    {"#", 0},
};

pair<int, int> check_type(const string &str, int start_pos) // ret {type, len}
{
    // #-2 space
    if (str[start_pos] == ' ')
    {
        return {-2, 1};
    }
    int len = str.size() - start_pos;
    // symbol
    if (isalpha(str[start_pos]))
    {
        int i = start_pos + 1;
        while (i < str.size() && isalnum(str[i]))
        {
            i++;
        }
        int symbol_len = i - start_pos;
        string symbol = str.substr(start_pos, symbol_len);
        // #1 begin
        if (symbol == "begin")
        {
            return {1, symbol_len};
        }
        // #2 end
        if (symbol == "end")
        {
            return {2, symbol_len};
        }
        // #10 letter(letter|digit)*
        return {10, symbol_len};
    }
    // #11 digit(digit)*
    if (isdigit(str[start_pos]))
    {
        int i = start_pos + 1;
        while (i < str.size() && isdigit(str[i]))
        {
            i++;
        }
        return {11, i - start_pos};
    }
    // operator
    if (!isalnum(str[start_pos]))
    {
        int i = start_pos + 1;
        while (i < str.size() && !isalnum(str[i]) && str[i] != ' ')
        {
            i++;
        }
        int operator_len = i - start_pos;
        string op = str.substr(start_pos, operator_len);
        if (operator_to_id.find(op) != operator_to_id.end())
        {
            return {operator_to_id.at(op), operator_len};
        }
    }
    // #-1 error
    return {-1, 1};
}

int main()
{
    ifstream fin("input_2.txt");
    ofstream fout("output_2.txt");
    string line;
    getline(fin, line);
    for (int i = 0; i < line.size();)
    {
        auto [type, len] = check_type(line, i);
        if (type == -1)
        {
            fout << "error" << endl;
        }
        else if (type != -2)
        {
            fout << type << " " << line.substr(i, len) << endl;
        }
        i += len;
    }
    return 0;
}