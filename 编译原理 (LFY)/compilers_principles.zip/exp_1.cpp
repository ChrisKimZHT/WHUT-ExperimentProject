#include <bits/stdc++.h>

const int MaxSize = 1000;

using namespace std;

ifstream fin("input_1.txt");
ofstream fout("output_1.txt");

map<char, int> pr = {{'*', 3}, {'|', 2}, {'+', 1}};

struct Edge
{
    int begin, end;
    char chr;
    Edge(int b, int e, char c) : begin(b), end(e), chr(c) {}
    void print() const { fout << this->begin << "-" << this->chr << "->" << this->end << " "; }
};

struct NFAGraph
{
    int begin, end;
    vector<Edge> edges;
    NFAGraph() : begin(-1), end(0) {}
    void add_edge(Edge e) { edges.push_back(e); }
};

string insert_concat(const string &str)
{
    string res;
    for (int i = 0; i < str.size(); i++)
    {
        res += str[i];
        if (str[i] == '(' || str[i] == '|')
            continue;
        if (i == str.size() - 1)
            continue;
        if (str[i + 1] != '*' && str[i + 1] != '|' && str[i + 1] != ')')
            res += '+';
        if (str[i + 1] == '(')
            res += '+';
    }
    return res;
}

string to_rpn(const string &str)
{
    string res;
    stack<char> st;
    for (int i = 0; i < str.size(); i++)
    {
        if (str[i] == '(')
            st.push('(');
        else if (str[i] == ')')
        {
            while (st.top() != '(')
            {
                res += st.top();
                st.pop();
            }
            st.pop();
        }
        else if (str[i] == '*' || str[i] == '+' || str[i] == '|')
        {
            while (!st.empty() && pr[st.top()] >= pr[str[i]])
            {
                res += st.top();
                st.pop();
            }
            st.push(str[i]);
        }
        else
            res += str[i];
    }
    res += "+";
    return res;
}

NFAGraph regex_to_nfa(const string &reg)
{
    NFAGraph nfa;
    vector<Edge> tmp;
    for (int i = 0; i < reg.size(); i++)
    {
        if (i == 0 || (isalnum(reg[i]) && isalnum(reg[i - 1])))
        {
            tmp.push_back({nfa.begin, nfa.end, reg[i]});
        }
        else if (isalnum(reg[i]) && (reg[i - 1] == '|' || reg[i - 1] == '*' || reg[i - 1] == '+'))
        {
            for (auto &edge : tmp)
            {
                nfa.edges.push_back(edge);
            }
            tmp.clear();
            tmp.push_back({nfa.begin, nfa.end, reg[i]});
        }
        else if (reg[i] == '+')
        {
            nfa.begin++;
            nfa.end++;
            if (isalnum(reg[i - 1]))
            {
                tmp.back().begin = nfa.begin;
                tmp.back().end = nfa.end;
            }
        }
        else if (reg[i] == '|')
        {
            nfa.edges.push_back({nfa.begin, nfa.end, '~'});
            nfa.begin++;
            nfa.end++;
            nfa.edges.push_back({nfa.begin, nfa.end, '~'});
            tmp.front().begin = nfa.begin;
            tmp.front().end = nfa.end;
            tmp.back().begin = nfa.begin;
            tmp.back().end = nfa.end;
        }
        else if (reg[i] == '*')
        {
            if (reg[i - 1] == '+')
            {
                int begin = tmp.front().begin;
                int end = tmp.back().end;
                nfa.add_edge({begin, end, '~'});
                nfa.add_edge({end, begin, '~'});
            }
            else if (reg[i - 1] == '|')
            {
                tmp.front().end = tmp.front().begin;
                tmp.back().end = tmp.back().begin;
            }
            else if (isalnum(reg[i - 1]))
            {
                nfa.begin++;
                nfa.end++;
                tmp.back().begin = nfa.begin;
                tmp.back().end = nfa.end;
                int begin = tmp.back().begin;
                int end = tmp.back().end;
                nfa.add_edge({begin, end, '~'});
                nfa.add_edge({begin + 1, end + 1, '~'});
                tmp.back().begin = tmp.back().end;
            }
        }
    }
    for (auto &edge : tmp)
    {
        nfa.edges.push_back(edge);
    }
    return nfa;
}

void print_nfa(const NFAGraph &nfa)
{
    for (auto &e : nfa.edges)
    {
        if (e.begin == -1)
        {
            fout << "X X-" << e.chr << "->" << e.end << endl;
            fout << "Y" << endl;
        }
    }
    for (int i = 0; i < nfa.end - 1; i++)
    {
        fout << i << " ";
        for (auto &e : nfa.edges)
        {
            if (e.begin == i)
            {
                e.print();
            }
        }
        fout << endl;
    }
    bool flag = false;
    for (auto &e : nfa.edges)
    {
        if (e.begin == nfa.end - 1)
        {
            if (e.end == nfa.end)
            {
                if (!flag)
                {
                    fout << e.begin << " ";
                    flag = true;
                }
                fout << e.begin << "-" << e.chr << "->Y" << " ";
            }
            else
            {
                e.print();
            }
        }
    }
}

int main()
{
    string str;
    getline(fin, str);
    // cout << str << endl; // (a|b)*abb
    str = insert_concat(str);
    // cout << str << endl; // (a|b)*+a+b+b
    string rpn = to_rpn(str);
    // cout << rpn << endl; // ab|*a+b+b
    NFAGraph nfa = regex_to_nfa(rpn);
    print_nfa(nfa);
    return 0;
}
