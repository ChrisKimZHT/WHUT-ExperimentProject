#include <bits/stdc++.h>

using namespace std;

ifstream fin("input_3.txt");
ofstream fout("output_3.txt");

// 关键字
map<string, string> keywords{
    {"const", "CONSTTK"},
    {"int", "INTTK"},
    {"char", "CHARTK"},
    {"void", "VOIDTK"},
    {"main", "MAINTK"},
    {"getint", "GETINTTK"},
    {"if", "IFTK"},
    {"else", "ELSETK"},
    {"switch", "SWITCHTK"},
    {"case", "CASETK"},
    {"default", "DEFAULTTK"},
    {"while", "WHILETK"},
    {"for", "FORTK"},
    {"scanf", "SCANFTK"},
    {"printf", "PRINTFTK"},
    {"return", "RETURNTK"},
    {"auto", "AUTOTK"},
    {"short", "SHORTTK"},
    {"long", "LONGTK"},
    {"float", "FLOATTK"},
    {"double", "DOUBLETK"},
    {"struct", "STRUCTTK"},
    {"union", "UNIONTK"},
    {"enum", "ENUMTK"},
    {"typedef", "TYPEDEFTK"},
    {"unsigned", "UNSIGNEDTK"},
    {"signed", "SIGNEDTK"},
    {"extern", "EXTERNTK"},
    {"register", "REGISTERTK"},
    {"static", "STATICTK"},
    {"volatile", "VOLATILETK"},
    {"do", "DOTK"},
    {"goto", "GOTOTK"},
    {"continue", "CONTINUETK"},
    {"break", "BREAKTK"},
    {"sizeof", "SIZEOFTK"}};

// 运算符
map<string, string> operations{
    {"+", "PLUS"},
    {"-", "MINU"},
    {"*", "MULT"},
    {"/", "DIV"},
    {"<", "LSS"},
    {"<=", "LEQ"},
    {">", "GRE"},
    {">=", "GEQ"},
    {"==", "EQL"},
    {"!=", "NEQ"},
    {"=", "ASSIGN"}};

// 界符
map<string, string> symbols{
    {":", "COLON"},
    {";", "SEMICN"},
    {",", "COMMA"},
    {"(", "LPARENT"},
    {")", "RPARENT"},
    {"{", "LBRACE"},
    {"}", "RBRACE"},
    {"[", "LBRACK"},
    {"]", "RBRACK"}};

// 语法分析当前单词的种别码
vector<string> tokens;
// 语法分析当前单词
vector<string> vals;
// 函数的方法名, 值为1表示该方法是有返回值的方法
map<string, int> NVoidFunction;

// 指向当前所读到字符串的位置的指针, 语法分析当前单词位置
int p, q;

// parser的声明
void parse0();
void parse1();
void parse2();
void parse3();
void parse4();
void parse5();
void parse6();
void parse7();
void parse8();
void parse9();
void parse10();
void parse11();
void parse12();
void parse13();
void parse14();
void parse15();
void parse16();
void parse17();
void parse18();
void parse19();
void parse20();
void parse21();
void parse22();
void parse23_24();
void parse25();
void parse26();
void parse27();
void parse28();
void parse29();

void match_token(string expected)
{
    if (tokens[q] == expected)
    {
        fout << tokens[q] << " " << vals[q] << endl;
        q++;
    }
}

void check_digit(const string &str)
{
    string token;
    token.push_back(str[p++]);
    int flag = 0;
    bool err = false;
    char ch;
    for (; p < str.length(); p++)
    {
        ch = str[p];
        if (ch == ' ' || (!isalnum(ch) && ch != '.'))
        {
            break;
        }
        else if (err)
        {
            token += ch;
        }
        else
        {
            token += ch;
            if (ch == '.')
            {
                if (flag == 1)
                {
                    err = true;
                }
                else
                {
                    flag++;
                }
            }
            else if (isalpha(ch))
            {
                err = true;
            }
        }
    }
    if (token[token.length() - 1] == '.')
    {
        err = true;
    }
    tokens.emplace_back("INTCON");
    vals.push_back(token);
    if (p != str.length() - 1 || (p == str.length() - 1 && !isdigit(str[p])))
    {
        p--;
    }
}

void check_letter(const string &str)
{
    string token;
    token.push_back(str[p++]);
    char ch;
    for (; p < str.length(); p++)
    {
        ch = str[p];
        if (!isalnum(ch) && ch != '_')
        {
            break;
        }
        else
        {
            token += ch;
        }
    }
    if (keywords.count(token))
    {
        tokens.push_back(keywords[token]);
        vals.push_back(token);
    }
    else
    {
        tokens.emplace_back("IDENFR");
        vals.push_back(token);
    }
    if (p != str.length() - 1 || (p == str.length() - 1 && (!isalnum(str[p]) && str[p] != '_')))
    {
        p--;
    }
}

void check_string(const string &str)
{
    string token;
    token.push_back(str[p++]);
    char ch;
    for (; p < str.length(); p++)
    {
        ch = str[p];
        token += ch;
        if (ch == '"')
        {
            break;
        }
    }
    token.erase(remove(token.begin(), token.end(), '\"'), token.end());
    tokens.emplace_back("STRCON");
    vals.emplace_back(token);
}

void check_char(const string &str)
{
    string token;
    token.push_back(str[p++]);
    char ch;
    for (; p < str.length(); p++)
    {
        ch = str[p];
        token += ch;
        if (ch == '\'')
        {
            break;
        }
    }
    token.erase(remove(token.begin(), token.end(), '\''), token.end());
    tokens.emplace_back("CHARCON");
    vals.push_back(token);
}

void check_symbol(const string &str)
{
    string token;
    token.push_back(str[p++]);
    char ch;
    if (symbols.count(token))
    {
        tokens.push_back(symbols[token]);
        vals.push_back(token);
        p--;
    }
    else
    {
        if (operations.count(token) || token == "!")
        {
            if (p < str.length())
            {
                ch = str[p];
                if (operations.count(token + ch))
                {
                    token += ch;
                    p++;
                    if (p < str.length())
                    {
                        ch = str[p];
                        if (operations.count(token + ch))
                        {
                            token += ch;
                            tokens.push_back(operations[token]);
                            vals.push_back(token);
                        }
                        else
                        {
                            p--;
                            tokens.push_back(operations[token]);
                            vals.push_back(token);
                        }
                    }
                    else
                    {
                        tokens.push_back(operations[token]);
                        vals.push_back(token);
                    }
                }
                else
                {
                    p--;
                    tokens.push_back(operations[token]);
                    vals.push_back(token);
                }
            }
        }
        else
        {
            p--;
        }
    }
}

void lex_analysis(string str)
{
    p = 0;
    char ch;
    str.erase(0, str.find_first_not_of(' '));
    str.erase(str.find_last_not_of(' ') + 1);
    for (; p < str.length(); p++)
    {
        ch = str[p];
        if (isdigit(ch))
            check_digit(str);
        else if (isalpha(ch) || ch == '_')
            check_letter(str);
        else if (ch == '"')
            check_string(str);
        else if (ch == '\'')
            check_char(str);
        else if (ch == ' ')
            continue;
        else
            check_symbol(str);
    }
}

void parse0()
{
    // ＜字符串＞ ::=  "｛十进制编码为32,33,35-126的ASCII字符｝"
    match_token("STRCON");
    fout << "<字符串>" << endl;
}

void parse1()
{
    // ＜程序＞ ::= ［＜常量说明＞］［＜变量说明＞］{＜有返回值函数定义＞|＜无返回值函数定义＞}＜主函数＞
    if (tokens[q] == "CONSTTK")
    {
        parse2(); // ＜常量说明＞
    }
    if ((tokens[q] == "INTTK" || tokens[q] == "CHARTK") && tokens[q + 1] == "IDENFR" && tokens[q + 2] != "LPARENT")
    {
        parse7(); // ＜变量说明＞
    }
    while ((tokens[q] == "INTTK" || tokens[q] == "CHARTK" || tokens[q] == "VOIDTK") &&
           tokens[q + 1] == "IDENFR" && tokens[q + 2] == "LPARENT")
    {
        if (tokens[q] == "VOIDTK")
        {
            parse10(); // ＜无返回值函数定义＞
        }
        else
        {
            parse9(); // ＜有返回值函数定义＞
        }
    }
    if (tokens[q] == "VOIDTK" && tokens[q + 1] == "MAINTK")
    {
        parse13(); // ＜主函数＞
    }
    if (q == tokens.size())
    {
        fout << "<程序>" << endl;
    }
}

void parse2()
{
    // ＜常量说明＞ ::=  const＜常量定义＞;{ const＜常量定义＞;}
    do
    {
        match_token("CONSTTK");
        parse3(); // ＜常量定义＞
        match_token("SEMICN");
    } while (tokens[q] == "CONSTTK");
    fout << "<常量说明>" << endl;
}

void parse3()
{
    // ＜常量定义＞   ::=   int＜标识符＞＝＜整数＞{,＜标识符＞＝＜整数＞}| char＜标识符＞＝＜字符＞{,＜标识符＞＝＜字符＞}
    if (tokens[q] == "INTTK")
    {
        match_token("INTTK");
        match_token("IDENFR");
        match_token("ASSIGN");
        parse5(); // ＜整数＞
        while (tokens[q] == "COMMA")
        {
            match_token("COMMA");
            match_token("IDENFR");
            match_token("ASSIGN");
            parse5();
        }
    }
    if (tokens[q] == "CHARTK")
    {
        match_token("CHARTK");
        match_token("IDENFR");
        match_token("ASSIGN");
        match_token("CHARCON");
        while (tokens[q] == "COMMA")
        {
            match_token("COMMA");
            match_token("IDENFR");
            match_token("ASSIGN");
            match_token("CHARCON");
        }
    }
    fout << ("<常量定义>") << endl;
}

void parse4()
{
    //<无符号整数>
    match_token("INTCON");
    fout << ("<无符号整数>") << endl;
}

void parse5()
{
    // ＜整数＞ ::= ［＋｜－］＜无符号整数＞
    if (tokens[q] == "PLUS")
        match_token("PLUS");
    else if (tokens[q] == "MINU")
        match_token("MINU");
    parse4(); //<无符号整数>
    fout << ("<整数>") << endl;
}

void parse6()
{
    // ＜声明头部＞ ::=  int＜标识符＞ |char＜标识符＞
    if (tokens[q] == "INTTK")
        match_token("INTTK");
    else if (tokens[q] == "CHARTK")
        match_token("CHARTK");
    match_token("IDENFR");
    fout << ("<声明头部>") << endl;
}

void parse7()
{
    // ＜变量说明＞ ::= ＜变量定义＞;{＜变量定义＞;}
    do
    {
        parse8(); // ＜变量定义＞
        match_token("SEMICN");
    } while ((tokens[q] == "INTTK" || tokens[q] == "CHARTK") &&
             tokens[q + 1] == "IDENFR" && tokens[q + 2] != "LPARENT");
    fout << ("<变量说明>") << endl;
}

void parse8()
{
    // ＜变量定义＞ ::= ＜类型标识符＞(＜标识符＞|＜标识符＞'['＜无符号整数＞']'){,(＜标识符＞|＜标识符＞'['＜无符号整数＞']')}
    if (tokens[q] == "INTTK")
        match_token("INTTK");
    else if (tokens[q] == "CHARTK")
        match_token("CHARTK");
    match_token("IDENFR");
    if (tokens[q] == "LBRACK")
    {
        match_token("LBRACK");
        parse4(); //<无符号整数>
        match_token("RBRACK");
    }
    while (tokens[q] == "COMMA")
    {
        match_token("COMMA");
        match_token("IDENFR");
        if (tokens[q] == "LBRACK")
        {
            match_token("LBRACK");
            parse4(); //<无符号整数>
            match_token("RBRACK");
        }
    }
    fout << ("<变量定义>") << endl;
}

void parse9()
{
    // ＜有返回值函数定义＞ ::=  ＜声明头部＞'('＜参数表＞')' '{'＜复合语句＞'}'
    parse6(); // ＜声明头部＞
    NVoidFunction.insert({vals[q - 1], 1});
    match_token("LPARENT");
    parse12(); // ＜参数表＞
    match_token("RPARENT");
    match_token("LBRACE");
    parse11(); // ＜复合语句＞
    match_token("RBRACE");
    fout << ("<有返回值函数定义>") << endl;
}

void parse10()
{
    // ＜无返回值函数定义＞ ::= void＜标识符＞'('＜参数表＞')''{'＜复合语句＞'}'
    match_token("VOIDTK");
    match_token("IDENFR");
    match_token("LPARENT");
    parse12(); // ＜参数表＞
    match_token("RPARENT");
    match_token("LBRACE");
    parse11(); // ＜复合语句＞
    match_token("RBRACE");
    fout << ("<无返回值函数定义>") << endl;
}

void parse11()
{
    // ＜复合语句＞ ::=  ［＜常量说明＞］［＜变量说明＞］＜语句列＞
    if (tokens[q] == "CONSTTK")
    {
        parse2(); // ＜常量说明＞
    }
    if ((tokens[q] == "INTTK" || tokens[q] == "CHARTK") &&
        tokens[q + 1] == "IDENFR" && tokens[q + 2] != "LPARENT")
    {
        parse7(); // ＜变量说明＞
    }
    parse26(); // ＜语句列＞
    fout << ("<复合语句>") << endl;
}

void parse12()
{
    // ＜参数表＞ ::=  ＜类型标识符＞＜标识符＞{,＜类型标识符＞＜标识符＞}| ＜空＞
    if (tokens[q] != "RPARENT") // 如果下一个token为右小括号，则为空
    {
        if (tokens[q] == "INTTK")
            match_token("INTTK");
        else if (tokens[q] == "CHARTK")
            match_token("CHARTK");
        match_token("IDENFR");
        while (tokens[q] == "COMMA")
        {
            match_token("COMMA");
            if (tokens[q] == "INTTK")
                match_token("INTTK");
            else if (tokens[q] == "CHARTK")
                match_token("CHARTK");
            match_token("IDENFR");
        }
    }
    fout << ("<参数表>") << endl;
}

void parse13()
{
    // ＜主函数＞ ::= void main‘(’‘)’ ‘{’＜复合语句＞‘}’
    match_token("VOIDTK");
    match_token("MAINTK");
    match_token("LPARENT");
    match_token("RPARENT");
    match_token("LBRACE");
    parse11(); // ＜复合语句＞
    match_token("RBRACE");
    fout << ("<主函数>") << endl;
}

void parse14()
{
    // ＜表达式＞ ::= ［＋｜－］＜项＞{＜加法运算符＞＜项＞}
    if (tokens[q] == "PLUS")
        match_token("PLUS");
    else if (tokens[q] == "MINU")
        match_token("MINU");
    parse15(); // ＜项＞
    while (tokens[q] == "PLUS" || tokens[q] == "MINU")
    {
        if (tokens[q] == "PLUS")
            match_token("PLUS");
        else if (tokens[q] == "MINU")
            match_token("MINU");
        parse15(); // ＜项＞
    }
    fout << ("<表达式>") << endl;
}

void parse15()
{
    // ＜项＞ ::= ＜因子＞{＜乘法运算符＞＜因子＞}
    parse16(); // ＜因子＞
    while (tokens[q] == "MULT" || tokens[q] == "DIV")
    {
        if (tokens[q] == "MULT")
            match_token("MULT");
        else if (tokens[q] == "DIV")
            match_token("DIV");
        parse16(); // ＜因子＞
    }
    fout << ("<项>") << endl;
}

void parse16()
{
    // ＜因子＞ ::= ＜标识符＞｜＜标识符＞'['＜表达式＞']'|'('＜表达式＞')'｜＜整数＞|＜字符＞｜＜有返回值函数调用语句＞
    if (tokens[q] == "IDENFR")
    {
        if (tokens[q + 1] == "LBRACK")
        {
            match_token("IDENFR");
            match_token("LBRACK");
            parse14(); // ＜表达式＞
            match_token("RBRACK");
        }
        else if (tokens[q + 1] == "LPARENT")
            parse23_24(); // ＜有返回值函数调用语句＞
        else
            match_token("IDENFR");
    }
    else if (tokens[q] == "LPARENT")
    {
        match_token("LPARENT");
        parse14(); // ＜表达式＞
        match_token("RPARENT");
    }
    else if (tokens[q] == "INTCON" || tokens[q] == "PLUS" || tokens[q] == "MINU")
        parse5(); // ＜整数＞
    else if (tokens[q] == "CHARCON")
        match_token("CHARCON");
    fout << ("<因子>") << endl;
}

void parse17()
{
    /*＜语句＞ ::= ＜条件语句＞｜＜循环语句＞| '{'＜语句列＞'}'
        | ＜有返回值函数调用语句＞; |＜无返回值函数调用语句＞;｜＜赋值语句＞;
        ｜＜读语句＞;｜＜写语句＞;｜＜空＞;|＜返回语句＞;*/
    if (tokens[q] == "IFTK")
        parse19(); // ＜条件语句＞
    else if (tokens[q] == "WHILETK" || tokens[q] == "DOTK" || tokens[q] == "FORTK")
        parse21(); // ＜循环语句＞
    else if (tokens[q] == "LBRACE")
    {
        match_token("LBRACE");
        parse26(); // ＜语句列＞
        match_token("RBRACE");
    }
    else if (tokens[q] == "IDENFR")
    {
        if (tokens[q + 1] == "LPARENT")
        {
            parse23_24(); // ＜有无返回值函数调用语句＞
            match_token("SEMICN");
        }
        else
        {
            parse18(); // ＜赋值语句＞
            match_token("SEMICN");
        }
    }
    else if (tokens[q] == "SCANFTK")
    {
        parse27(); // ＜读语句＞
        match_token("SEMICN");
    }
    else if (tokens[q] == "PRINTFTK")
    {
        parse28(); // ＜写语句＞
        match_token("SEMICN");
    }
    else if (tokens[q] == "RETURNTK")
    {
        parse29(); // ＜返回语句＞
        match_token("SEMICN");
    }
    else if (tokens[q] == "SEMICN")
        match_token("SEMICN");
    fout << ("<语句>") << endl;
}

void parse18()
{
    // ＜赋值语句＞ ::=  ＜标识符＞＝＜表达式＞|＜标识符＞'['＜表达式＞']'=＜表达式＞
    match_token("IDENFR");
    if (tokens[q] == "LBRACK")
    {
        match_token("LBRACK");
        parse14(); // ＜表达式＞
        match_token("RBRACK");
    }
    match_token("ASSIGN");
    parse14(); // ＜表达式＞
    fout << ("<赋值语句>") << endl;
}

void parse19()
{
    // ＜条件语句＞ ::= if '('＜条件＞')'＜语句＞［else＜语句＞］
    match_token("IFTK");
    match_token("LPARENT");
    parse20(); // ＜条件＞
    match_token("RPARENT");
    parse17(); // ＜语句＞
    if (tokens[q] == "ELSETK")
    {
        match_token("ELSETK");
        parse17(); // ＜语句＞
    }
    fout << ("<条件语句>") << endl;
}

void parse20()
{
    // ＜条件＞    ::=  ＜表达式＞＜关系运算符＞＜表达式＞ //整型表达式之间才能进行关系运算｜＜表达式＞
    //  表达式为整型，其值为0条件为假，值不为0时条件为真
    parse14(); // ＜表达式＞
    if (tokens[q] == "LSS" || tokens[q] == "LEQ" || tokens[q] == "GRE" || tokens[q] == "GEQ" || tokens[q] == "EQL" || tokens[q] == "NEQ")
    {
        match_token((string)tokens[q]);
        parse14(); // ＜表达式＞
    }
    fout << ("<条件>") << endl;
}

void parse21()
{
    // ＜循环语句＞ ::=  while '('＜条件＞')'＜语句＞
    //           |do＜语句＞while '('＜条件＞')'
    //           |for'('＜标识符＞＝＜表达式＞;＜条件＞;＜标识符＞＝＜标识符＞(+|-)＜步长＞')'＜语句＞
    if (tokens[q] == "WHILETK")
    {
        match_token("WHILETK");
        match_token("LPARENT");
        parse20(); // ＜条件＞
        match_token("RPARENT");
        parse17(); // ＜语句＞
    }
    else if (tokens[q] == "DOTK")
    {
        match_token("DOTK");
        parse17(); // ＜语句＞
        match_token("WHILETK");
        match_token("LPARENT");
        parse20(); // ＜条件＞
        match_token("RPARENT");
    }
    else if (tokens[q] == "FORTK")
    {
        match_token("FORTK");
        match_token("LPARENT");
        match_token("IDENFR");
        match_token("ASSIGN");
        parse14(); // ＜表达式＞
        match_token("SEMICN");
        parse20(); // ＜条件＞
        match_token("SEMICN");
        match_token("IDENFR");
        match_token("ASSIGN");
        match_token("IDENFR");
        if (tokens[q] == "PLUS")
            match_token("PLUS");
        else if (tokens[q] == "MINU")
            match_token("MINU");
        parse22(); // ＜步长＞
        match_token("RPARENT");
        parse17(); // ＜语句＞
    }
    fout << ("<循环语句>") << endl;
}

void parse22()
{
    // ＜步长＞::= ＜无符号整数＞
    parse4(); // ＜无符号整数＞
    fout << ("<步长>") << endl;
}

void parse23_24()
{
    // ＜有无返回值函数调用语句＞ ::= ＜标识符＞'('＜值参数表＞')'
    int FunctionType = 0;
    if (NVoidFunction.count(vals[q]))
    {
        FunctionType = NVoidFunction[vals[q]];
    }
    match_token("IDENFR");
    match_token("LPARENT");
    parse25(); // ＜值参数表＞
    match_token("RPARENT");
    if (FunctionType == 1)
    {
        fout << ("<有返回值函数调用语句>") << endl;
    }
    else
    {
        fout << ("<无返回值函数调用语句>") << endl;
    }
}

void parse25()
{
    // ＜值参数表＞ ::= ＜表达式＞{,＜表达式＞}｜＜空＞
    if (tokens[q] != "RPARENT")
    {
        parse14(); // ＜表达式＞
        while (tokens[q] == "COMMA")
        {
            match_token("COMMA");
            parse14();
        }
    }
    fout << ("<值参数表>") << endl;
}

void parse26()
{
    // ＜语句列＞ ::= ｛＜语句＞｝
    while (tokens[q] != "RBRACE")
        parse17(); // ＜语句＞
    fout << ("<语句列>") << endl;
}

void parse27()
{
    // ＜读语句＞ ::=  scanf '('＜标识符＞{,＜标识符＞}')'
    match_token("SCANFTK");
    match_token("LPARENT");
    match_token("IDENFR");
    while (tokens[q] == "COMMA")
    {
        match_token("COMMA");
        match_token("IDENFR");
    }
    match_token("RPARENT");
    fout << ("<读语句>") << endl;
}

void parse28()
{
    // ＜写语句＞ ::= printf '(' ＜字符串＞,＜表达式＞ ')'
    //           | printf '('＜字符串＞ ')'
    //           | printf '('＜表达式＞')'
    match_token("PRINTFTK");
    match_token("LPARENT");
    if (tokens[q] == "STRCON")
        parse0(); // ＜字符串＞
    else
        parse14(); // ＜表达式＞
    if (tokens[q] == "COMMA")
    {
        match_token("COMMA");
        parse14(); // ＜表达式＞
    }
    match_token("RPARENT");
    fout << ("<写语句>") << endl;
}

void parse29()
{
    // ＜返回语句＞ ::=  return['('＜表达式＞')']
    match_token("RETURNTK");
    if (tokens[q] == "LPARENT")
    {
        match_token("LPARENT");
        parse14(); // ＜表达式＞
        match_token("RPARENT");
    }
    fout << ("<返回语句>") << endl;
}

int main()
{
    string line;
    while (getline(fin, line))
        lex_analysis(line);
    parse1();
    return 0;
}