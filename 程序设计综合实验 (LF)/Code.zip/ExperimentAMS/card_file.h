#ifndef EXPERIMENTAMS_CARD_FILE_H
#define EXPERIMENTAMS_CARD_FILE_H

#include "class.h"

int CardFileSave(std::map<std::string, Card> &); // �ļ�����
int CardFileLoad(std::map<std::string, Card> &); // �ļ���ȡ

#endif //EXPERIMENTAMS_CARD_FILE_H
