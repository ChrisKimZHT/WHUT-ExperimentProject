#include "global_var.h"

int CARD_NAME_MAX = 16, CARD_NAME_MIN = 6;
int CARD_PWD_MAX = 16, CARD_PWD_MIN = 6;
bool ADMIN_LOGIN = false;