import matplotlib.pyplot as plt

# 数据
categories = ['S', 'M', 'L']
before = [20.93, 321.13, 510.21]
after = [0.27, 3.42, 5.48]

# 绘制柱状图
x = range(len(categories))
width = 0.35

fig, ax = plt.subplots()
rects1 = ax.bar(x, before, width, label='Before Acceleration')
rects2 = ax.bar([i + width for i in x], after, width, label='After Acceleration')

# 添加标签
ax.set_ylabel('Time (seconds)')
ax.set_title('Comparison of Time Before and After Acceleration')
ax.set_xticks([i + width / 2 for i in x])
ax.set_xticklabels(categories)
ax.legend()

# 添加数值标签
for rect in rects1:
    height = rect.get_height()
    ax.annotate('{}'.format(height),
                xy=(rect.get_x() + rect.get_width() / 2, height),
                xytext=(0, 3),  # 3 points vertical offset
                textcoords="offset points",
                ha='center', va='bottom')

for rect in rects2:
    height = rect.get_height()
    ax.annotate('{}'.format(height),
                xy=(rect.get_x() + rect.get_width() / 2, height),
                xytext=(0, 3),  # 3 points vertical offset
                textcoords="offset points",
                ha='center', va='bottom')

plt.show()

# 加速幅度计算
acceleration = [b / a for b, a in zip(before, after)]

# 加速方案标签
labels = ['S', 'M', 'L']

# 绘制柱状图
plt.bar(labels, acceleration)

# 添加标题和坐标轴标签
plt.title('Acceleration Amplitude')
plt.xlabel('Scheme')
plt.ylabel('Acceleration Ratio')

# 在每个柱子上添加数值标签
for i, v in enumerate(acceleration):
    plt.text(i, v, f'{v:.2f}x', ha='center', va='bottom')

# 显示图形
plt.show()
