from PIL import Image
import matplotlib.pyplot as plt


def img2mat(input_image: str, output_file: str) -> None:
    img = Image.open(input_image)
    width, height = img.size
    with open(output_file, "w") as f:
        f.write(f"{width} {height}\n")
        for y in range(height):
            for x in range(width):
                r, g, b = img.getpixel((x, y))
                f.write(f"{r:02x}{g:02x}{b:02x} ")
            f.write("\n")


def show_result(result_file: str) -> None:
    with open(result_file, "r") as f:
        width, height = map(int, f.readline().split())
        result_image = []
        for i in range(height):
            result_image.append(list(map(int, f.readline().split())))
    plt.imshow(result_image)
    plt.show()


if __name__ == "__main__":
    # img2mat("nahida.jpg", "nahida.txt")
    show_result("result.txt")
