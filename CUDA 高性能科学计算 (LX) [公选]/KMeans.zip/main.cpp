// Author: GitHub@ChrisKimZHT

#include <iostream>
#include <fstream>
#include <cassert>
#include <random>
#include <algorithm>
#include <cstring>
#include <iomanip>
#include <ctime>
#include <string>
#include <numeric>

#define INF 2147483647


void load_image(const std::string &image_file, int *&image, int &width, int &height)
{
    std::ifstream file(image_file);
    assert(file.is_open());
    file >> width >> height;
    assert(width > 0 && height > 0);
    image = new int[width * height * 3];
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            std::string buf;
            file >> buf;
            image[(i * width + j) * 3 + 0] = std::stoi(buf.substr(0, 2), nullptr, 16);
            image[(i * width + j) * 3 + 1] = std::stoi(buf.substr(2, 2), nullptr, 16);
            image[(i * width + j) * 3 + 2] = std::stoi(buf.substr(4, 2), nullptr, 16);
        }
    }
    file.close();
}

void init_center(int *&center, int k, const int *image, int size)
{
    std::random_device rd;
    std::mt19937 gen(rd());
    std::vector<int> range(size);
    std::iota(range.begin(), range.end(), 0);
    std::shuffle(range.begin(), range.end(), rd);

    center = new int[k * 3]; // r, g, b
    for (int i = 0; i < k; i++)
    {
        center[i * 3 + 0] = image[range[i] * 3 + 0];
        center[i * 3 + 1] = image[range[i] * 3 + 1];
        center[i * 3 + 2] = image[range[i] * 3 + 2];
    }
}

void k_means(const int *image, int *center, int *&result, int size, int k, int round)
{
    result = new int[size];
    int *count = new int[k];
    for (int round_id = 1; round_id <= round; round_id++)
    {
        std::cout << "\rRound: "
                  << std::right << std::setw(4) << round_id << "/"
                  << std::left << std::setw(4) << round;
        clock_t start = clock();
        for (int pixel_id = 0; pixel_id < size; pixel_id++)
        {
            int min_distance = INF;
            for (int center_id = 0; center_id < k; center_id++)
            {
                int distance = 0;
                for (int channel_id = 0; channel_id < 3; channel_id++)
                {
                    int diff = image[pixel_id * 3 + channel_id] - center[center_id * 3 + channel_id];
                    distance += diff * diff;
                }
                if (distance < min_distance)
                {
                    min_distance = distance;
                    result[pixel_id] = center_id;
                }
            }
        }
        memset(center, 0, sizeof(int) * k * 3);
        memset(count, 0, sizeof(int) * k);
        for (int pixel_id = 0; pixel_id < size; pixel_id++)
        {
            int center_id = result[pixel_id];
            for (int channel_id = 0; channel_id < 3; channel_id++)
            {
                center[center_id * 3 + channel_id] += image[pixel_id * 3 + channel_id];
            }
            count[center_id]++;
        }
        for (int center_id = 0; center_id < k; center_id++)
        {
            for (int channel_id = 0; channel_id < 3; channel_id++)
            {
                if (count[center_id])
                {
                    center[center_id * 3 + channel_id] /= count[center_id];
                }
            }
        }
        std::cout << "Execution time: " << std::setw(5) << std::right << clock() - start << "ms";
    }
    delete[] count;
    std::cout << std::endl;
}

void save_result(const std::string &file_name, const int *result, int width, int height)
{
    std::ofstream file(file_name);
    assert(file.is_open());
    file << width << " " << height << std::endl;
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            file << result[i * width + j] << " ";
        }
        file << std::endl;
    }
    file.close();
}

int main()
{
    std::string image_file;
    std::cout << "Enter image file name: ";
    std::cin >> image_file;

    int k;
    std::cout << "Enter number of clusters: ";
    std::cin >> k;
    assert(k > 0);

    int round;
    std::cout << "Enter number of rounds: ";
    std::cin >> round;
    assert(round > 0);

    clock_t last_time;
    last_time = clock();
    int width, height;
    int *image; // 1D array of RGB pixels
    std::cout << "Loading image" << std::endl;
    load_image(image_file, image, width, height);
    int size = width * height;
    std::cout << "Finished! Image size: " << width << "x" << height << std::endl
              << "Execution time: " << std::fixed << std::setprecision(2)
              << 1.0 * (clock() - last_time) / 1000 << "s" << std::endl;
    last_time = clock();

    std::cout << "Init center" << std::endl;
    int *center;
    init_center(center, k, image, size);
    std::cout << "Finished! Execution time: " << std::fixed << std::setprecision(2)
              << 1.0 * (clock() - last_time) / 1000 << "s" << std::endl;
    last_time = clock();

    std::cout << "Running K-means" << std::endl;
    int *result;
    k_means(image, center, result, size, k, round);
    std::cout << "Finished! Execution time: " << std::fixed << std::setprecision(2)
              << 1.0 * (clock() - last_time) / 1000 << "s" << std::endl;
    last_time = clock();

    std::cout << "Saving result to result.txt" << std::endl;
    save_result("result.txt", result, width, height);
    std::cout << "Finished! Execution time: " << std::fixed << std::setprecision(2)
              << 1.0 * (clock() - last_time) / 1000 << "s" << std::endl;

    delete[] image;
    delete[] center;
    delete[] result;
    return 0;
}

// Author: GitHub@ChrisKimZHT