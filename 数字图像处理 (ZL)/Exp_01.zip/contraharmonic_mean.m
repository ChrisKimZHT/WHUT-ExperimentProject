clear; clc;
image_name_list = ls('noised/'); % 图片列表
filter_para = [3, 9]; % 参数列表

for i = 3 : length(image_name_list)
    image_name = strtrim(image_name_list(i, :));
    image = imread(strcat('noised/', image_name));
    r = image(:, :, 1);
    g = image(:, :, 2);
    b = image(:, :, 3);
    for para = filter_para
        fr = spfilt(r, 'chmean', para, para, -1.5);
        fg = spfilt(g, 'chmean', para, para, -1.5);
        fb = spfilt(b, 'chmean', para, para, -1.5);
        filtered_image = cat(3, fr, fg, fb);
        imwrite(filtered_image, strcat('filtered/', image_name, '-chmean-', int2str(para), '.png'));
    end
end