clear; clc;
image_name_list = ls('original/'); % 图片列表
para_x = [0.05, 0.1, 0.5]; % 参数列表（噪声均值）
para_y = [0.05, 0.1, 0.5]; % 参数列表（噪声方差）

for i = 3 : length(image_name_list)
    image_name = strtrim(image_name_list(i, :));
    image = imread(strcat('original/', image_name));
    for x = para_x
        for y = para_y
            noised_image = imnoise(image, 'gaussian', x, y);
            imwrite(noised_image, strcat('noised/', image_name, '-gaussian-', num2str(x), '-', num2str(y),'.png'));
        end
    end
end