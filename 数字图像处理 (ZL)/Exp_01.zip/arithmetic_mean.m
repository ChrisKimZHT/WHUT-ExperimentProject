clear; clc;
image_name_list = ls('noised/'); % 图片列表
filter_para = [3, 9]; % 参数列表

for i = 3 : length(image_name_list)
    image_name = strtrim(image_name_list(i, :));
    image = imread(strcat('noised/', image_name));
    r = image(:, :, 1);
    g = image(:, :, 2);
    b = image(:, :, 3);
    for para = filter_para
        avg_filter = ones(para, para) / para^2;
        fr = imfilter(r, avg_filter);
        fg = imfilter(g, avg_filter);
        fb = imfilter(b, avg_filter);
        filtered_image = cat(3, fr, fg, fb);
        imwrite(filtered_image, strcat('filtered/', image_name, '-amean-', int2str(para), '.png'));
    end
end