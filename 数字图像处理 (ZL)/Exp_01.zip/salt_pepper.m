clear; clc;
image_name_list = ls('original/'); % 图片列表
noise_para = [0.02, 0.04, 0.08, 0.16, 0.32]; % 参数列表（噪声密度）

for i = 3 : length(image_name_list)
    image_name = strtrim(image_name_list(i, :));
    image = imread(strcat('original/', image_name));
    for para = noise_para
        noised_image = imnoise(image, 'salt & pepper', para);
        imwrite(noised_image, strcat('noised/', image_name, '-salt-pepper-', num2str(para),'.png'));
    end
end