clear; clc;
image_name_list = ls('noised/'); % 图片列表
filter_para = ["zeros", "symmetric", "indexed"]; % 参数列表

for i = 3 : length(image_name_list)
    image_name = strtrim(image_name_list(i, :));
    image = imread(strcat('noised/', image_name));
    r = image(:, :, 1);
    g = image(:, :, 2);
    b = image(:, :, 3);
    for para = filter_para
        fr = medfilt2(r, para);
        fg = medfilt2(g, para);
        fb = medfilt2(b, para);
        filtered_image = cat(3, fr, fg, fb);
        imwrite(filtered_image, strcat('filtered/', image_name, '-median-', para,'.png'));
    end
end