clear; clc;
image_name_list = ls('original/'); % 图片列表
noise_para = [0.1, 0.2, 0.4, 0.8, 1.0]; % 参数列表（噪声强度）

for i = 3 : length(image_name_list)
    image_name = strtrim(image_name_list(i, :));
    image = imread(strcat('original/', image_name));
    % 分离RGB通道
    r = double(image(:, :, 1));
    g = double(image(:, :, 2));
    b = double(image(:, :, 3));
    % 归一化到 [0, 1]
    r = r - min(r(:));
    r = r / max(r(:));
    g = g - min(g(:));
    g = g / max(g(:));
    b = b - min(b(:));
    b = b / max(b(:));
    % 提取长宽
    length = size(image, 1);
    width = size(image, 2);
    % 生成均匀分布随机数 [0, 1]
    rand = imnoise2('uniform', length, width);

    for para = noise_para
        nr = r + para * rand;
        ng = g + para * rand;
        nb = b + para * rand;
        noised_image = cat(3, nr, ng, nb);
        imwrite(noised_image, strcat('noised/', image_name, '-uniform-', num2str(para), '.png'));
    end
end