import numpy as np
import matplotlib.pyplot as plt
import idx2numpy
from tqdm import tqdm

"""
数字图像处理 实验二
2. 使用K-means算法在图像数据集上实现对不同类别图像的聚类。
"""


def k_means(img: np.ndarray, k: int, it: int = 8, pp: bool = False) -> np.ndarray:
    """
    K-means算法
    :param img: 数据集
    :param k: 聚类中心个数
    :param it: 最大迭代次数
    :param pp: 是否使用kmeans++初始化
    :return: 聚类结果
    """
    img = img / 255
    c, h, w = img.shape
    # 初始化
    print("init center...")
    if not pp:
        center = img[np.random.choice(c, size=k, replace=False), :]
    else:
        center = [img[np.random.randint(c)]]
        for _ in tqdm(range(k - 1)):
            dists = []
            for i in range(c):
                dist = min([np.linalg.norm(img[i] - ct) for ct in center])
                dists.append(dist)
            probs = np.array(dists) / sum(dists)
            cumulative_probs = np.cumsum(probs)
            r = np.random.random()
            for i, p in enumerate(cumulative_probs):
                if r < p:
                    center.append(img[i])
                    break
    print("iterating...")
    center = np.array(center)
    result = np.zeros(c, dtype=np.uint8)
    last_result = result.copy()
    # 迭代
    for _ in tqdm(range(it)):
        # 计算每个样例到聚类中心的距离
        for i in range(c):
            dist = np.zeros(k)
            for m in range(k):
                dist[m] = np.linalg.norm(img[i] - center[m])
            result[i] = np.argmin(dist)
        if np.all(result == last_result):
            print("converged!")
            break
        last_result = result.copy()
        # 更新聚类中心
        for m in range(k):
            if img[result == m].shape[0] == 0:
                continue
            center[m] = np.mean(img[result == m], axis=0)
    return result


def run_kmeans() -> dict:
    train_images = idx2numpy.convert_from_file("t10k-images.idx3-ubyte")
    train_lables = idx2numpy.convert_from_file("t10k-labels.idx1-ubyte")
    result = k_means(train_images, 10, 64, False)
    ans = {x: [0, 0] for x in range(10)}
    for i in range(10):
        real_cnt = {x: 0 for x in range(10)}
        for j in range(result.shape[0]):
            if result[j] == i:
                real_cnt[train_lables[j]] += 1
        max_key = max(real_cnt, key=real_cnt.get)
        ans[max_key][0] += real_cnt[max_key]
        ans[max_key][1] += sum(real_cnt.values())
    print(f"accuracy: {round(sum([ans[x][0] for x in range(10)]) / sum([ans[x][1] for x in range(10)]) * 100, 2)}%")
    return ans


def get_plot(ans: dict):
    correct, incorrect, accuracies = [], [], []
    for i in range(10):
        correct.append(ans[i][0])
        incorrect.append(ans[i][1] - ans[i][0])
        accuracy = 0 if ans[i][1] == 0 else round(ans[i][0] / ans[i][1], 2)
        accuracies.append(accuracy)
    x = range(10)
    fig, ax = plt.subplots()
    ax.set_xticks(x)
    rects1 = ax.bar(x, correct, label="Correct")
    rects2 = ax.bar(x, incorrect, bottom=correct, label="Incorrect")
    accuracies_str = [f"{acc * 100:.0f}%" for acc in accuracies]
    for i, rect in enumerate(rects1):
        ax.text(rect.get_x() + rect.get_width() / 2, rect.get_height(), accuracies_str[i], ha="center", va="bottom")
    plt.xlabel("Category")
    plt.ylabel("Number of instances")
    plt.title("Accuracy by category")
    plt.legend()
    plt.show()


if __name__ == "__main__":
    sum_rr = {}
    for _ in range(10):
        rr = run_kmeans()
        for key in set(rr.keys()) | set(sum_rr.keys()):
            if key in rr and key in sum_rr:
                sum_rr[key] = [sum_rr[key][0] + rr[key][0], sum_rr[key][1] + rr[key][1]]
            elif key in rr:
                sum_rr[key] = rr[key]
            else:
                sum_rr[key] = sum_rr[key]
    print(f"acc: {round(sum([sum_rr[x][0] for x in range(10)]) / sum([sum_rr[x][1] for x in range(10)]) * 100, 2)}%")
    get_plot(sum_rr)
