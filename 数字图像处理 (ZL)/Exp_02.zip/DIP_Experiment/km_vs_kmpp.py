import matplotlib.pyplot as plt

# 数据
k_means = [50.74, 56.75, 58.12, 59.52, 59.25]
k_means_pp = [52.73, 56.48, 58.54, 59.97, 59.95]
iterations = [4, 8, 16, 32, 64]

# 绘图
plt.plot(iterations, k_means, label='K-means')
plt.plot(iterations, k_means_pp, label='K-means++')

# 图形设置
plt.title('K-means vs K-means++ Clustering Accuracy')
plt.xlabel('Iterations')
plt.ylabel('Accuracy (%)')
plt.legend()

# 图形展示
plt.show()
