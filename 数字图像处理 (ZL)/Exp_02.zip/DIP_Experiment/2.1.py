import numpy as np
import matplotlib.pyplot as plt
from tqdm import tqdm

"""
数字图像处理 实验二
1. 使用K-means算法在单张图像上实现对图像的聚类分割。
"""


def k_means(img: np.ndarray, k: int, it: int = 8, rgbxy: bool = False, pp: bool = False) -> np.ndarray:
    """
    K-means算法
    :param img: 图像
    :param k: 聚类中心个数
    :param it: 最大迭代次数
    :param rgbxy: 是否使用RGB+XY五维度
    :param pp: 是否使用kmeans++初始化
    :return: 聚类结果
    """
    img = img / 255
    h, w, c = img.shape
    # 给图片新增xy两维
    if rgbxy:
        x_coords = np.tile(np.arange(w), (h, 1)) / w * 0.1
        y_coords = np.tile(np.arange(h).reshape(-1, 1), (1, w)) / h * 0.1
        img = np.dstack((x_coords, y_coords, img))
    # 初始化
    print("init center...")
    if not pp:
        center = img[np.random.choice(h, size=k, replace=False), np.random.choice(w, size=k, replace=False), :]
    else:
        center = [img[np.random.randint(h), np.random.randint(w)]]
        for _ in tqdm(range(k - 1)):
            dists = []
            for i in range(h):
                for j in range(w):
                    dist = min([np.linalg.norm(img[i, j] - ct) for ct in center])
                    dists.append(dist)
            probs = np.array(dists) / sum(dists)
            cumulative_probs = np.cumsum(probs)
            r = np.random.random()
            for i, p in enumerate(cumulative_probs):
                if r < p:
                    center.append(img[i // w, i % w])
                    break
    print("iterating...")
    result = np.zeros((h, w), dtype=np.uint8)
    last_result = result.copy()
    # 迭代
    for _ in tqdm(range(it)):
        # 计算每个像素点到聚类中心的距离
        for i in range(h):
            for j in range(w):
                dist = np.zeros(k)
                for m in range(k):
                    dist[m] = np.linalg.norm(img[i, j] - center[m])
                result[i, j] = np.argmin(dist)
        if np.all(result == last_result):
            print("converged!")
            break
        last_result = result.copy()
        # 更新聚类中心
        for m in range(k):
            if img[result == m].shape[0] == 0:
                continue
            center[m] = np.mean(img[result == m], axis=0)
    # 用不同灰度代表类别
    gray_levels = np.linspace(0.2, 0.8, k)
    gray_rgb = np.stack((gray_levels, gray_levels, gray_levels), axis=1)
    return gray_rgb[result]
    # return center[result]


def run():
    # 读取图像
    image = plt.imread("image_02.jpg")
    # 聚类计算
    result = k_means(image, 8, 32, False, True)
    # 显示图像
    plt.imshow(result)
    plt.show()


if __name__ == '__main__':
    run()
