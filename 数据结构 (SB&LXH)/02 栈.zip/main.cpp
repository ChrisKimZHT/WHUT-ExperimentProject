#include <iostream>
#include <unordered_map>
#include "seq_stack.h"
#include "list_stack.h"

using namespace std;

unordered_map<char, int> priority{
        {'(', 0},
        {')', 0},
        {'+', 1},
        {'-', 1},
        {'*', 2},
        {'/', 2}
};

void convert()
{
    ListStack<char> operator_stk;
    string str;
    cout << "��׺����ʽ(��ֹ�ո�): ";
    cin >> str;
    cout << "��׺����ʽ: ";
    for (int i = 0; i < str.size(); i++)
    {
        if (isdigit(str[i]))
        {
            int num = 0, j;
            for (j = 0; i + j < str.size(); j++)
            {
                if (isdigit(str[i + j]))
                    num = num * 10 + str[i + j] - '0';
                else
                    break;
            }
            i += j - 1;
            cout << num << ' ';
        }
        else if (str[i] == '(')
        {
            operator_stk.push(str[i]);
        }
        else if (str[i] == ')')
        {
            while (operator_stk.top() != '(')
            {
                cout << operator_stk.top() << ' ';
                operator_stk.pop();
            }
            operator_stk.pop();
        }
        else
        {
            while (operator_stk.size() && priority[operator_stk.top()] >= priority[str[i]])
            {
                cout << operator_stk.top() << ' ';
                operator_stk.pop();
            }
            operator_stk.push(str[i]);
        }
    }
    while (operator_stk.size())
    {
        cout << operator_stk.top() << ' ';
        operator_stk.pop();
    }
    cout << endl;
}

void base_calc(ListStack<int> &ns, char oper)
{
    int a = ns.top();
    ns.pop();
    int b = ns.top();
    ns.pop();
    int ans = 0;
    if (oper == '+')
        ans = b + a;
    else if (oper == '-')
        ans = b - a;
    else if (oper == '*')
        ans = b * a;
    else if (oper == '/')
        ans = b / a;
    ns.push(ans);
}

void calculate()
{
    ListStack<int> number_stk;
    cout << "��׺����ʽ(�ո�ָ�,�ȺŽ�β): ";
    string str;
    while (cin >> str)
    {
        if (str[0] == '=')
            break;
        if (isdigit(str[0]))
        {
            int num = 0;
            for (char i: str)
                num = num * 10 + i - '0';
            number_stk.push(num);
        }
        else
        {
            base_calc(number_stk, str[0]);
        }
    }
    cout << "��: " << number_stk.top() << endl;
}

/*
 * Test Case:
 * 01 | 2*(9+6/3-5)+4
 *    | 2 9 6 3 / + 5 - * 4 +
 *    | 16
 * 02 | 6*(5+(2+3)*8+3)
 *    | 6 5 2 3 + 8 * + 3 + *
 *    | 288
 * 03 | (3+4)*5-6
 *    | 3 4 + 5 * 6 -
 *    | 29
 * 04 | 21*(19+66/11-5)+400
 *    | 21 19 66 11 / + 5 - * 400 +
 *    | 820
 */

int main()
{
    while (true)
    {
        int typ;
        cout << "ת��/����/�˳�: (0/1/2)";
        cin >> typ;
        if (typ == 0)
            convert();
        else if (typ == 1)
            calculate();
        else
            break;
    }
    return 0;
}
