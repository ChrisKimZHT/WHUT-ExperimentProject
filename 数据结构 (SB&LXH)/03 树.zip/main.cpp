#include <iostream>
#include "binary_tree.h"

using namespace std;

int main()
{
    /*
     * string s = "A(B(C(E,F),D(G(M,N),H)),)";
     * // "A(B(C,D(,E)),)"
     * BinaryTree<string> test(s);
     * cout << test.preorderTraversal() << endl;
     * cout << test.preorderTraversalNotRecursion() << endl;
     * cout << test.inorderTraversal() << endl;
     * cout << test.inorderTraversalNotRecursion() << endl;
     * cout << test.postorderTraversal() << endl;
     * cout << test.postorderTraversalNotRecursion() << endl;
     * cout << test.getAncestor("M") << endl;
     * cout << test.getAncestor("N") << endl;
     */
    cout << "������������ű�ʾ��: ";
    string str;
    cin >> str;
    BinaryTree<string> bi_tree(str);
    cout << "1. �������" << endl
         << "2. �������" << endl
         << "3. ��ѯ����" << endl
         << "0. �˳�" << endl;
    while (true)
    {
        cout << "ѡ����: ";
        int choice;
        cin >> choice;
        if (choice == 1)
            cout << "�������: " << bi_tree.postorderTraversal() << endl;
        else if (choice == 2)
            cout << "�������: " << bi_tree.preorderTraversalNotRecursion() << endl;
        else if (choice == 3)
        {
            string node;
            cout << "��������Ա: ";
            cin >> node;
            cout << node << "�ĳ���: " << bi_tree.getAncestor(node) << endl;
        }
        else
            break;
    }
    return 0;
}
