#include <pthread.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>

#define MAX_LINE_LENGTH 132
#define NUM_THREADS 8

int TotalEvenWords = 0, TotalOddWords = 0, TotalWords = 0;

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

struct ThreadData
{
    int thread_id;
    FILE *file;
};

int GetWordAndLetterCount(char *Line)
{
    int Word_Count = 0, Letter_Count = 0;
    for (int i = 0; i < 132; i++)
    {
        if ((Line[i] != ' ') && (Line[i] != 0) && (Line[i] != '\n'))
            Letter_Count++;
        else
        {
            if (Letter_Count % 2)
            {
                TotalOddWords++;
                Word_Count++;
                Letter_Count = 0;
            }
            else
            {
                TotalEvenWords++;
                Word_Count++;
                Letter_Count = 0;
            }
            if (Line[i] == 0)
                break;
        }
    }
    return Word_Count; // encode two return values
}

void *CountWordsThread(void *arg)
{
    struct ThreadData *data = (struct ThreadData *)arg;
    char inLine[MAX_LINE_LENGTH];
    while (fgets(inLine, MAX_LINE_LENGTH, data->file) != NULL)
    {
        pthread_mutex_lock(&mutex);
        TotalWords += GetWordAndLetterCount(inLine);
        pthread_mutex_unlock(&mutex);
    }
    pthread_exit(NULL);
}

int main()
{
    struct timeval TimeStampStart, TimeStampStop;
    double ExeTime;
    gettimeofday(&TimeStampStart, NULL);

    pthread_t threads[NUM_THREADS];
    struct ThreadData thread_data[NUM_THREADS];
    FILE *fd[NUM_THREADS];

    char filename[20];
    for (int i = 0; i < NUM_THREADS; ++i)
    {
        sprintf(filename, "./InFile%d.txt", i);
        fd[i] = fopen(filename, "r");
    }

    for (int i = 0; i < NUM_THREADS; ++i)
    {
        thread_data[i].thread_id = i;
        thread_data[i].file = fd[i];
        pthread_create(&threads[i], NULL, CountWordsThread, (void *)&thread_data[i]);
    }

    for (int i = 0; i < NUM_THREADS; ++i)
    {
        pthread_join(threads[i], NULL);
    }

    gettimeofday(&TimeStampStop, NULL);
    ExeTime = (double)(TimeStampStop.tv_sec - TimeStampStart.tv_sec) +
              (double)(TimeStampStop.tv_usec - TimeStampStart.tv_usec) * 1e-6;

    for (int i = 0; i < NUM_THREADS; ++i)
    {
        fclose(fd[i]);
    }

    printf("Total Words = %8d\n", TotalWords);
    printf("Total Even Words = %7d\nTotal Odd Words = %7d\n", TotalEvenWords, TotalOddWords);
    printf("The time to calculate word cound was %f seconds\n", (ExeTime));

    return 0;
}
