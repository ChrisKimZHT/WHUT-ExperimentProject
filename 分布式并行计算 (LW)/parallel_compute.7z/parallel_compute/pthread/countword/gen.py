import random
from tqdm import tqdm

def random_word():
    length = random.randint(1, 10)
    word = ""
    for i in range(length):
        word += chr(random.randint(97, 122))
    return word


def main():
    cnt = int(input("word count: "))
    with open("InFile.txt", "w") as f:
        for _ in tqdm(range(cnt)):
            f.write(random_word() + " ")


if __name__ == "__main__":
    main()
