#!/bin/bash
mpirun -np 6 -f /root/code/mpi/hello/config /root/code/mpi/hello/mpi_hello_world
