#!/bin/bash
mpirun -np 6 -f /root/code/mpi/pi/config /root/code/mpi/pi/pi-mpi
