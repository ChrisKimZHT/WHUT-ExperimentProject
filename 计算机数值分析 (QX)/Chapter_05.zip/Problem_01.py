def f(x: float) -> float:
    return x * x - 2


[a, b] = map(lambda x: float(x), input("输入a,b: ").split(" "))
TOL = float(input("输入精度TOL: "))
N = int(input("输入最大迭代次数N: "))

mid = 0.0
fmid = 0.0
for i in range(N):
    mid = (a + b) / 2
    fa = f(a)
    fmid = f(mid)
    if fmid == 0 or (b - a) / 2 < TOL:
        print(f"f({mid})={fmid}")
        print(f"迭代次数: {i}")
        break
    if fa * fmid > 0:
        a = mid
    else:
        b = mid
else:
    print(f"f({mid})={fmid}")
    print(f"迭代次数: {i}")

'''
Test Case:
1 2
0.000001
30
'''
