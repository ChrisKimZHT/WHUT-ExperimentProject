import math


def f(x: float) -> float:
    return x - math.pow(math.e, -x)


def df(x: float) -> float:
    return 1 + x


x_0 = float(input("输入x_0: "))
eps = float(input("输入eps: "))
N = int(input("输入N: "))

for i in range(N):
    if df(x_0) == 0:
        print("奇异")
        break
    x_1 = x_0 - f(x_0) / df(x_0)
    if abs(x_1 - x_0) < eps:
        print(f"f({round(x_1, 5)})={round(f(x_1), 5)}")
        print(f"迭代次数: {i}")
        break
    print(f"f({round(x_1, 5)})={round(f(x_1), 5)}")
    x_0 = x_1
else:
    print("达到迭代次数限制，求解失败")

"""
Test Case:
1
0.001
10
"""
