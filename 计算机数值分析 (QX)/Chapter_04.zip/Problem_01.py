def f(x: float, y: float) -> float:
    return y - 2 * x / y


[x_0, y_0, h] = map(lambda x: float(x), input("输入x_0,y_0,h: ").split(" "))
N = int(input("输入步数N: "))

print(f"x_0={round(x_0, 4)}, y_0={round(y_0, 4)}")
for i in range(N):
    x_1 = x_0 + h
    y_p = y_0 + h * f(x_0, y_0)
    y_c = y_0 + h * f(x_1, y_p)
    y_1 = (y_p + y_c) / 2
    print(f"x_{i}={round(x_1, 4)}, y_{i}={round(y_1, 4)}")
    x_0 = x_1
    y_0 = y_1

'''
Test Case:
0 1 0.1
10
'''
