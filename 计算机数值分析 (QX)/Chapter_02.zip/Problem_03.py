m = int(input("输入数据数量 m: "))
data_x = []
data_y = []
for i in range(m):
    [x, y] = input(f"输入 x_{i}, y_{i}: ").split(" ")
    data_x.append(float(x))
    data_y.append(float(y))

sx = sum(data_x)
sy = sum(data_y)
sxx = sum(ix * ix for ix in data_x)
sxy = sum(ix * iy for ix, iy in zip(data_x, data_y))

# a * m  + b * sx  = sy
# a * sx + b * sxx = sxy
# a * sx + b * sx * (sx / m) = sy * (sx / m)
# b * (sx * (sx / m) - sxx) = sy * (sx / m) - sxy
b = (sy * (sx / m) - sxy) / (sx * (sx / m) - sxx)
a = (sy - b * sx) / m

print(f"拟合结果 p(x) = {a} + {b} x")

"""Test Case:
Input:
5
165 187
123 126
150 172
123 125
141 148
Output:
p(x) = -60.9392 + 1.5138 x
"""
