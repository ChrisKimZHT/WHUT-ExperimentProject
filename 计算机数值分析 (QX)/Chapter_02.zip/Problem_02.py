x = float(input("输入插值点 x: "))
n = int(input("输入插值节点数目 n: "))

node_x = []
node_y = []
for i in range(0, n):
    [nx, ny] = input(f"输入 x_{i}, y_{i}: ").split(" ")
    node_x.append(float(nx))
    node_y.append(float(ny))

y = 0.0
df_mat = [[0.0 for col in range(n + 1)] for row in range(n)]  # n行n+1列的商差表
for i in range(0, n):
    df_mat[i][0] = node_x[i]  # 第0列为x
    df_mat[i][1] = node_y[i]  # 第1列为f(x)

# 生成商差表
for i in range(1, n):
    for j in range(2, i + 2):
        df_mat[i][j] = (df_mat[i][j - 1] - df_mat[i - 1][j - 1]) / (df_mat[i][0] - df_mat[i - j + 1][0])

# 计算最终答案
tmp = 1.0
for i in range(0, n):
    y += tmp * df_mat[i][i + 1]
    tmp *= (x - node_x[i])

print(f"f({x}) 的近似值为: {y}")

"""Test Case:
Input:
115
3
100 10
121 11
144 12
Output:
10.72275551
Accurate:
10.72380529
"""
