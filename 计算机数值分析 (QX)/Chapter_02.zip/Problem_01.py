x = float(input("输入插值点 x: "))
n = int(input("输入插值节点数目 n: "))

node_x = []
node_y = []
for i in range(0, n):
    [nx, ny] = input(f"输入 x_{i}, y_{i}: ").split(" ")
    node_x.append(float(nx))
    node_y.append(float(ny))

y = 0.0
for i in range(0, n):
    t = 1.0  # 插值基函数 l(x)
    for j in range(0, n):
        if i == j:
            continue
        t *= (x - node_x[j]) / (node_x[i] - node_x[j])
    y += t * node_y[i]

print(f"f({x}) 的近似值为: {y}")

"""Test Case:
Input:
115
3
100 10
121 11
144 12
Output:
10.72275551
Accurate:
10.72380529
"""
