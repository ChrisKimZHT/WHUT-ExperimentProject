//
// Created by ChrisKim on 2023/12/12.
//

#include "DiskScheduling.h"

std::vector<int> ScheduleResult::getTrackSequence()
{
    return track_sequence;
}

int ScheduleResult::getInitialHeadPosition() const
{
    return initial_head_position;
}

int ScheduleResult::getTotalHeadMovement() const
{
    return total_head_movement;
}

double ScheduleResult::getAverageHeadMovement() const
{
    return average_head_movement;
}

void ScheduleResult::print()
{
    std::cout << "Order\tID\tTrack\tMove" << std::endl;
    std::cout << "#0\tinit\t" << initial_head_position << "\t0" << std::endl;
    for (int i = 0; i < track_sequence.size(); i++)
    {
        std::cout << "#" << i + 1 << "\t"
                  << i + 1 << "\t"
                  << track_sequence[i] << "\t"
                  << abs(track_sequence[i] - ((i - 1 >= 0) ? track_sequence[i - 1] : initial_head_position))
                  << std::endl;
    }
    std::cout << "Total head movement: " << total_head_movement << std::endl;
    std::cout << "Average head movement: " << average_head_movement << std::endl;
}

ScheduleResult Scheduler::FCFS(std::vector<int> track_sequence, int initial_head_position)
{
    int total_head_movement = abs(track_sequence[0] - initial_head_position);
    for (int i = 1; i < track_sequence.size(); i++)
    {
        total_head_movement += abs(track_sequence[i] - track_sequence[i - 1]);
    }
    double average_head_movement = (double) total_head_movement / ((int) track_sequence.size());
    return {track_sequence, initial_head_position, total_head_movement, average_head_movement};
}

ScheduleResult Scheduler::SSTF(std::vector<int> track_sequence, int initial_head_position)
{
    int total_head_movement = 0, current_head_position = initial_head_position;
    track_sequence.insert(track_sequence.begin(), initial_head_position);
    std::vector<bool> visited(track_sequence.size(), false);
    std::vector<int> result;
    visited[0] = true;
    for (int i = 1; i < track_sequence.size(); i++)
    {
        int min_distance = INT_MAX, min_index = -1;
        for (int j = 1; j < track_sequence.size(); j++)
        {
            if (!visited[j] && abs(track_sequence[j] - current_head_position) < min_distance)
            {
                min_distance = abs(track_sequence[j] - current_head_position);
                min_index = j;
            }
        }
        visited[min_index] = true;
        result.push_back(track_sequence[min_index]);
        total_head_movement += min_distance;
        current_head_position = track_sequence[min_index];
    }
    double average_head_movement = (double) total_head_movement / (int) result.size();
    return {result, initial_head_position, total_head_movement, average_head_movement};
}

ScheduleResult Scheduler::SCAN(std::vector<int> track_sequence, int initial_head_position, bool head_direction)
{
    track_sequence.insert(track_sequence.begin(), initial_head_position);
    std::sort(track_sequence.begin(), track_sequence.end());
    std::vector<int> result;
    int init_pos = -1;
    for (int i = 0; i < track_sequence.size(); i++)
    {
        if (track_sequence[i] == initial_head_position)
        {
            init_pos = i;
            break;
        }
    }
    if (head_direction)
    {
        for (int i = init_pos + 1; i < track_sequence.size(); i++)
        {
            result.push_back(track_sequence[i]);
        }
        for (int i = init_pos - 1; i >= 0; i--)
        {
            result.push_back(track_sequence[i]);
        }
    }
    else
    {
        for (int i = init_pos - 1; i >= 0; i--)
        {
            result.push_back(track_sequence[i]);
        }
        for (int i = init_pos + 1; i < track_sequence.size(); i++)
        {
            result.push_back(track_sequence[i]);
        }
    }
    int total_head_movement = abs(result[0] - initial_head_position);
    for (int i = 1; i < result.size(); i++)
    {
        total_head_movement += abs(result[i] - result[i - 1]);
    }
    double average_head_movement = (double) total_head_movement / (int) result.size();
    return {result, initial_head_position, total_head_movement, average_head_movement};
}

ScheduleResult
Scheduler::schedule(const std::vector<int> &track_sequence, int initial_head_position, bool head_direction,
                    const std::string &algorithm)
{
    if (algorithm == "FCFS")
    {
        return FCFS(track_sequence, initial_head_position);
    }
    else if (algorithm == "SSTF")
    {
        return SSTF(track_sequence, initial_head_position);
    }
    else if (algorithm == "SCAN")
    {
        return SCAN(track_sequence, initial_head_position, head_direction);
    }
    else
    {
        std::cout << "Invalid algorithm name!" << std::endl;
        return {{}, 0, 0, 0};
    }
}


