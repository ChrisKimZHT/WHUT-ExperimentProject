#include <iostream>
#include "DiskScheduling.h"

int main()
{
    std::cout << "Input initial head position: ";
    int initial_head_position;
    std::cin >> initial_head_position;
    std::cout << "Input track sequence (-1 to end): " << std::endl;
    std::vector<int> track_sequence;
    int track;
    while (std::cin >> track && track >= 0)
    {
        track_sequence.push_back(track);
    }
    std::cout << "Input algorithm name (FCFS, SSTF, SCAN): ";
    std::string algorithm;
    std::cin >> algorithm;
    bool head_direction = false;
    if (algorithm == "SCAN")
    {
        std::cout << "Input head direction (0 for low, 1 for high): ";
        std::cin >> head_direction;
    }
    Scheduler::schedule(track_sequence, initial_head_position, head_direction, algorithm).print();
    /* Sample: 53(init) 98 183 37 122 14 124 65 67 -1 */
}
