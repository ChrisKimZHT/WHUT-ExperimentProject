//
// Created by ChrisKim on 2023/12/12.
//

#ifndef EXP_OS_02_DISKSCHEDULING_H
#define EXP_OS_02_DISKSCHEDULING_H

#include <vector>
#include <iostream>
#include <string>
#include <algorithm>

class ScheduleResult
{
private:
    std::vector<int> track_sequence;
    int initial_head_position;
    int total_head_movement;
    double average_head_movement;
public:
    ScheduleResult(const std::vector<int> &track_sequence,
                   int initial_head_position,
                   int total_head_movement,
                   double average_head_movement) :
            track_sequence(track_sequence),
            initial_head_position(initial_head_position),
            total_head_movement(total_head_movement),
            average_head_movement(average_head_movement) {};

    std::vector<int> getTrackSequence();

    [[nodiscard]] int getInitialHeadPosition() const;

    [[nodiscard]] int getTotalHeadMovement() const;

    [[nodiscard]] double getAverageHeadMovement() const;

    void print();
};

class Scheduler
{
private:
    static ScheduleResult FCFS(std::vector<int> track_sequence, int initial_head_position);

    static ScheduleResult SSTF(std::vector<int> track_sequence, int initial_head_position);

    static ScheduleResult SCAN(std::vector<int> track_sequence, int initial_head_position, bool head_direction);

public:
    static ScheduleResult
    schedule(const std::vector<int> &track_sequence, int initial_head_position, bool head_direction,
             const std::string &algorithm);
};

#endif //EXP_OS_02_DISKSCHEDULING_H
