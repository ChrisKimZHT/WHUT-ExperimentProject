//
// Created by ChrisKim on 2023/12/6.
//

#ifndef EXP_OS_01_MEMORY_H
#define EXP_OS_01_MEMORY_H

#include <algorithm>
#include <iostream>
#include <vector>
#include <utility>
#include "AllocateAlgo.h"
#include "Process.h"


class Memory
{
private:
    int memory_size; // in MiB
    std::vector<Process> processes;
    std::vector<std::pair<int, int>> free_blocks; // <start, size>

    bool allocateFirstFit(const Process &process);

    bool allocateBestFit(const Process &process);

    bool allocateWorstFit(const Process &process);

    void mergeFreeBlocks();

public:
    Memory(int memory_size) : memory_size(memory_size)
    {
        free_blocks.emplace_back(0, memory_size);
    };

    [[nodiscard]] int getMemorySize() const;

    [[nodiscard]] const std::vector<Process> &getProcesses() const;

    [[nodiscard]] const std::vector<std::pair<int, int>> &getFreeBlocks() const;

    bool allocate(const Process &process, const AllocateAlgo &allocate_algo);

    bool deallocate(int process_id);

    void printMemory();
};


#endif //EXP_OS_01_MEMORY_H
