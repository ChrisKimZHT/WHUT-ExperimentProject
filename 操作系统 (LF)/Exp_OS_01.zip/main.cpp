#include <iostream>

#include "Memory.h"
#include "Process.h"
#include "AllocateAlgo.h"

int cur_process_id = 0;

void allocate_page(Memory &memory)
{
    system("cls");
    int process_id, memory_size;
//    std::cout << "Please input the process id: ";
//    std::cin >> process_id;
    process_id = cur_process_id++;
    std::cout << "Please input the memory size (MiB): ";
    std::cin >> memory_size;
    Process process(process_id, memory_size);
    std::cout << "Please input the allocate algorithm (1. First Fit, 2. Best Fit, 3. Worst Fit): ";
    int choice;
    std::cin >> choice;
    AllocateAlgo allocate_algo;
    switch (choice)
    {
        case 1:
            allocate_algo = FIRST_FIT;
            break;
        case 2:
            allocate_algo = BEST_FIT;
            break;
        case 3:
            allocate_algo = WORST_FIT;
            break;
        default:
            std::cout << "Invalid choice!" << std::endl;
            return;
    }
    if (memory.allocate(process, allocate_algo))
    {
        std::cout << "Allocate successfully!" << std::endl;
    }
    else
    {
        std::cout << "Allocate failed!" << std::endl;
    }
    std::cout << "Memory size: " << memory.getMemorySize() << " MiB" << std::endl;
    std::cout << "========================" << std::endl;
    memory.printMemory();
    std::cout << "========================" << std::endl;
    system("pause");
}

void deallocate_page(Memory &memory)
{
    system("cls");
    int process_id;
    std::cout << "Please input the process id: ";
    std::cin >> process_id;
    if (memory.deallocate(process_id))
    {
        std::cout << "Deallocate successfully!" << std::endl;
    }
    else
    {
        std::cout << "Deallocate failed!" << std::endl;
    }
    std::cout << "Memory size: " << memory.getMemorySize() << " MiB" << std::endl;
    std::cout << "========================" << std::endl;
    memory.printMemory();
    std::cout << "========================" << std::endl;
    system("pause");
}

void memory_usage_page(Memory &memory)
{
    system("cls");
    std::cout << "Memory size: " << memory.getMemorySize() << " MiB" << std::endl;
    std::cout << "========================" << std::endl;
    memory.printMemory();
    std::cout << "========================" << std::endl;
    system("pause");
}

int main()
{
    int memory_size;
    std::cout << "Please input the memory size (MiB): ";
    std::cin >> memory_size;
    Memory memory(memory_size);
    while (true)
    {
        system("cls");
        std::cout << "1. Allocate a process" << std::endl
                  << "2. Deallocate a process" << std::endl
                  << "3. Print memory" << std::endl
                  << "4. Exit" << std::endl
                  << "Please input your choice: ";
        int choice;
        std::cin >> choice;
        switch (choice)
        {
            case 1:
                allocate_page(memory);
                break;
            case 2:
                deallocate_page(memory);
                break;
            case 3:
                memory_usage_page(memory);
                break;
            case 4:
                return 0;
            default:
                std::cout << "Invalid choice!" << std::endl;
        }
    }
}
