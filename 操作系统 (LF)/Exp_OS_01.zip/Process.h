//
// Created by ChrisKim on 2023/12/6.
//

#ifndef EXP_OS_01_PROCESS_H
#define EXP_OS_01_PROCESS_H


class Process
{
private:
    int process_id;
    int memory_size; // in MiB
    bool allocated = false;
    int address = -1;
public:
    Process(int process_id, int memory_size) :
            process_id(process_id), memory_size(memory_size) {};

    [[nodiscard]] int getProcessId() const;

    [[nodiscard]] int getMemorySize() const;

    [[nodiscard]] bool isAllocated() const;

    [[nodiscard]] int getAddress() const;

    void allocate(int address);

    void deallocate();

    bool operator<(const Process &rhs) const
    {
        if (address != -1 && rhs.address != -1)
        {
            return address < rhs.address;
        }
        return process_id < rhs.process_id;
    }
};


#endif //EXP_OS_01_PROCESS_H
