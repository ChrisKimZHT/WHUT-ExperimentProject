//
// Created by ChrisKim on 2023/12/6.
//

#include <cstdint>
#include "Memory.h"

int Memory::getMemorySize() const
{
    return memory_size;
}

const std::vector<Process> &Memory::getProcesses() const
{
    return processes;
}

const std::vector<std::pair<int, int>> &Memory::getFreeBlocks() const
{
    return free_blocks;
}

bool Memory::allocate(const Process &process, const AllocateAlgo &allocate_algo)
{
    switch (allocate_algo)
    {
        case FIRST_FIT:
            return allocateFirstFit(process);
        case BEST_FIT:
            return allocateBestFit(process);
        case WORST_FIT:
            return allocateWorstFit(process);
    }
}

bool Memory::allocateFirstFit(const Process &process)
{
    for (int i = 0; i < free_blocks.size(); ++i)
    {
        auto &[start, size] = free_blocks[i];
        if (size >= process.getMemorySize())
        {
            processes.emplace_back(process);
            processes.back().allocate(start);
            if (size == process.getMemorySize())
            {
                free_blocks.erase(free_blocks.begin() + i);
            }
            else
            {
                free_blocks[i].first += process.getMemorySize();
                free_blocks[i].second -= process.getMemorySize();
            }
            return true;
        }
    }
    return false;
}

bool Memory::allocateBestFit(const Process &process)
{
    int best_index = -1, best_size = INT32_MAX;
    for (int i = 0; i < free_blocks.size(); ++i)
    {
        auto &[start, size] = free_blocks[i];
        if (size >= process.getMemorySize() && size < best_size)
        {
            best_index = i;
            best_size = size;
        }
    }
    if (best_index == -1)
    {
        return false;
    }
    processes.emplace_back(process);
    auto &[start, size] = free_blocks[best_index];
    processes.back().allocate(start);
    if (size == process.getMemorySize())
    {
        free_blocks.erase(free_blocks.begin() + best_index);
    }
    else
    {
        free_blocks[best_index].first += process.getMemorySize();
        free_blocks[best_index].second -= process.getMemorySize();
    }
    return true;
}

bool Memory::allocateWorstFit(const Process &process)
{
    int worst_index = -1, worst_size = -1;
    for (int i = 0; i < free_blocks.size(); ++i)
    {
        auto &[start, size] = free_blocks[i];
        if (size >= process.getMemorySize() && size > worst_size)
        {
            worst_index = i;
            worst_size = size;
        }
    }
    if (worst_index == -1)
    {
        return false;
    }
    processes.emplace_back(process);
    auto &[start, size] = free_blocks[worst_index];
    processes.back().allocate(start);
    if (size == process.getMemorySize())
    {
        free_blocks.erase(free_blocks.begin() + worst_index);
    }
    else
    {
        free_blocks[worst_index].first += process.getMemorySize();
        free_blocks[worst_index].second -= process.getMemorySize();
    }
    return true;
}

bool Memory::deallocate(int process_id)
{
    for (int i = 0; i < processes.size(); ++i)
    {
        if (processes[i].getProcessId() == process_id)
        {
            free_blocks.emplace_back(processes[i].getAddress(), processes[i].getMemorySize());
            processes.erase(processes.begin() + i);
            mergeFreeBlocks();
            return true;
        }
    }
    return false;
}

void Memory::mergeFreeBlocks()
{
    std::sort(free_blocks.begin(), free_blocks.end());
    for (int i = 0; i < free_blocks.size() - 1; ++i)
    {
        if (free_blocks[i].first + free_blocks[i].second == free_blocks[i + 1].first)
        {
            free_blocks[i].second += free_blocks[i + 1].second;
            free_blocks.erase(free_blocks.begin() + i + 1);
            --i;
        }
    }
}

void Memory::printMemory()
{
    std::sort(processes.begin(), processes.end(), [](const Process &lhs, const Process &rhs)
    {
        return lhs.getAddress() < rhs.getAddress();
    });
    std::cout << "Address\tSize\tState" << std::endl;
    int pos_process = 0, pos_free = 0;
    while (pos_process < processes.size() && pos_free < free_blocks.size())
    {
        if (processes[pos_process].getAddress() < free_blocks[pos_free].first)
        {
            std::cout << processes[pos_process].getAddress() << '\t'
                      << processes[pos_process].getMemorySize() << '\t'
                      << "Proc #" << processes[pos_process].getProcessId() << std::endl;
            ++pos_process;
        }
        else
        {
            std::cout << free_blocks[pos_free].first << '\t'
                      << free_blocks[pos_free].second << '\t'
                      << "Free" << std::endl;
            ++pos_free;
        }
    }
    while (pos_process < processes.size())
    {
        std::cout << processes[pos_process].getAddress() << '\t'
                  << processes[pos_process].getMemorySize() << '\t'
                  << "Proc #" << processes[pos_process].getProcessId() << std::endl;
        ++pos_process;
    }
    while (pos_free < free_blocks.size())
    {
        std::cout << free_blocks[pos_free].first << '\t'
                  << free_blocks[pos_free].second << '\t'
                  << "Free" << std::endl;
        ++pos_free;
    }
}
