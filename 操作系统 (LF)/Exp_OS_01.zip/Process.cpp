//
// Created by ChrisKim on 2023/12/6.
//

#include "Process.h"

int Process::getProcessId() const
{
    return process_id;
}

int Process::getMemorySize() const
{
    return memory_size;
}

bool Process::isAllocated() const
{
    return allocated;
}

int Process::getAddress() const
{
    return address;
}

void Process::allocate(int _address)
{
    address = _address;
    allocated = true;
}

void Process::deallocate()
{
    address = -1;
    allocated = false;
}
