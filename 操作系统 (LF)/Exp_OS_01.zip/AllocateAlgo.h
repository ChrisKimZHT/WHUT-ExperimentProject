//
// Created by ChrisKim on 2023/12/6.
//

#ifndef EXP_OS_01_ALLOCATEALGO_H
#define EXP_OS_01_ALLOCATEALGO_H


enum AllocateAlgo
{
    FIRST_FIT,
    BEST_FIT,
    WORST_FIT
};


#endif //EXP_OS_01_ALLOCATEALGO_H
